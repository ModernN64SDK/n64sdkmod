/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxdmem.h
	Coded    by	Yoshitaka Yasumoto.	Nov  7, 1997.
	
	$Id: gxdmem.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/
	#---------------------------------------------------------------------
	#  DMEM 領域の設定
	#---------------------------------------------------------------------
	#                
	#	+----------+ +          +        
	#	|  GSTATE  | |UCODE     |Yield   
	#	+----------+ |起動時に  |前後で  +
	#	|  LSTATE  | |初期化    |保存    |LOAD-
	#	+----------+ |          |        |UCODEで  +
	#	|  SUBMOD  | |          |        |初期化   |SUBMODで
	#	+----------+ +          |        +         +初期化
	#	|   SAVE   |            |
	#	+----------+            +
	#	|   WORK   |            
	#	+----------+ +            
	#	|  OSTask  | |OSで設定
	#	+----------+ +
	#
	#---------------------------------------------------------------------
		#----------------------------
		#  グローバルステート
		#----------------------------
RSP_GSTAT_OFFSET:
#include	"gxdmem_gstat.h"
		#----------------------------
		#  ローカルステート
		#----------------------------
RSP_LSTAT_OFFSET:
#include	"gxdmem_lstat.h"
		#----------------------------
		#  Yield セーブ領域
		#----------------------------
RSP_SAVE_OFFSET:
#include	"gxdmem_save.h"
		.dmax	0xc00+1
		#----------------------------
		#  一時ワーク領域
		#----------------------------
RSP_WORK_OFFSET:
#include	"gxdmem_work.h"
		.dmax	0xfc0+1
RSP_WORKEND_OFFSET:

		#----------------------------
		#  タスクデータ領域
		#----------------------------
#include	"gxdmem_task.h"

		#----------------------------
		#   DMEM の使用状況の出力
		#----------------------------
		.print	"|\n"
		.print	"| DMEM Usage:\n"
		.print	"|   GSTAT   = 0x%03x\n", RSP_GSTAT_OFFSET
		.print	"|   LSTAT   = 0x%03x\n", RSP_LSTAT_OFFSET
		.print	"|   SUBMOD  = 0x%03x\n", RSP_SUBMOD_OFFSET
		.print	"|   SAVE    = 0x%03x\n", RSP_SAVE_OFFSET
		.print	"|   WORK    = 0x%03x\n", RSP_WORK_OFFSET
		.print	"|   WORKEND = 0x%03x\n", RSP_WORKEND_OFFSET
		.print	"|\n"
	
/*======== End of gxdmem.h ========*/
