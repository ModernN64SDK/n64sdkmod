/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.

	File		gxdmem_lstat.h
	Coded	 by	Yoshitaka Yasumoto.	Oct 17,	1997.

	$Id: gxdmem_lstat.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 *  ローカルステート
 *	マイクロコードにおいて固有に使用するステータス領域
 *	TASK 起動時および gSPLoadUcode で初期化される.
 *---------------------------------------------------------------------------*/
	#---------------------------------------------------------------------
	#  Clip Ratio の値
	#	ldv でアクセスする.
	#	(ldv でアクセス可能な位置 -0x200 〜 +0x1f8)
	#---------------------------------------------------------------------
RSP_LSTAT_CLIPSELECT:
	.bound	4
	.word	0x00010000	.word	0x00000002
	.word	0x00000001	.word	0x00000002
	.word	0x00010000	.word	0x0000fffe
	.word	0x00000001	.word	0x0000fffe
	.word	0x00000000	.word	0x0001ffff
#ifdef	NEARCLIP_OFF
	.word	0x00000000	.word	0x00000001
#else
	.word	0x00000000	.word	0x00010001
#endif
	.symbol	oRSP_LSTAT_CLIPSELECT, RSP_LSTAT_CLIPSELECT-RSP_LSTAT_OFFSET

	#---------------------------------------------------------------------
	# ベクトルレジスタ定数 (lqv でアクセス可能な位置 -0x400 〜 +0x3f0)
	#---------------------------------------------------------------------
	.bound	16
#define	______		0x0000	
	.symbol	POINTS, RSP_SAVE_POINTS&0xfff

RSP_LSTAT_VCONST0:
	#---- vconst0 = $v30 の値 ----
	#
	# lighting 処理の都合により
	#   vconst0[0],[4] は負,
	#   vconst0[1],[5] は正にする必要あり
	# vtx 処理の都合により
	#   vconst0[3],[7] は vconst0 の要素
	#   の内の最大の 2 つをセットする vconst0[7] が最大
	#
	_half4	(0xffff, 0x0004, 0x0008, 0x7f00)
	_half4	(0xfffc, 0x4000, POINTS, 0x7fff)
RSP_LSTAT_VCONST1:
	#---- vconst1 = $v29 の値 ----
	#
	#  setup_ex 処理の都合により
	#  [4..6]<[7]<[0..3] とする
	#
	_half4	(0x7ffc, 0x1400, 0x1000, 0x0100)
	_half4	(0xfff0, 0xfff8, 0x0010, 0x0020)
	
RSP_LSTAT_VCONST_TMP:
	#---- light/clip 用の一時使用 const 値 ----
	_half4	(0xc000, 0x44d3, 0x6cb3, 0x0002)

	#---- ベクトル演算に使用する ----#
#define	_0x0000		  vzero[0]
#define	_0x0001		   vone[0]
#define	_0xffff		vconst0[0]
#define	_0x0004		vconst0[1]
#define	_0x0008		vconst0[2]
#define	_0x7f00		vconst0[3]
#define	_0xfffc		vconst0[4]
#define	_0x4000		vconst0[5]
#define	_TopOfPoints	vconst0[6]
#define	_0x7fff		vconst0[7]
#define	_0x7ffc		vconst1[0]
#define	_0x1400		vconst1[1]
#define	_0x1000		vconst1[2]
#define	_0x0100		vconst1[3]
#define	_0xfff0		vconst1[4]
#define	_0xfff8		vconst1[5]
#define	_0x0010		vconst1[6]
#define	_0x0020		vconst1[7]
#define	_0xc000		vconstTmp[0]
#define	_0x44d3		vconstTmp[1]
#define	_0x6cb3		vconstTmp[2]
#define	_0x0002		vconstTmp[3]	# gxclip_ex.s で使用する
	
	#---------------------------------------------------------------------
	#  MxP Matrix の計算要求フラグ / Light の計算要求フラグ / Light 数
	#	0 なら計算を行なう必要あり. 0 以外なら書換えない.
	#	G_MTX/G_POPMTX で MULMP と LIGHT の両フラグ(2Bytes)を 0
	#	に書換える. ForceMatrix では, MULMP のみ 1 にする.
	#	gSPNumLights で FLAG と NUM の双方(4Bytes)を書換える.
	#	書き込みアドレスの変更により, それぞれのフラグを操作する.
	#	以上から LIGHT が 1 のときに MULMP が 0 であることはない.
	#	(= MULMP のみが計算要求されることはない)
	#	PMtx のみが書換えられたときは Light はそのままで MPMtx を
	#	再計算する必要があるがそういったケースは少ないと判断し,
	#	このケースでも双方とも再計算する.
	#---------------------------------------------------------------------
		.byte	0	# Padding 必要
RSP_LSTAT_MULMP_FLAG:
		.byte	1
		.half	0	# Padding 必要
RSP_LSTAT_LIGHT_FLAG:
		.byte	1
RSP_LSTAT_LIGHT_NUM:
		.byte	0

		.symbol	RSP_LSTAT_FORCEMTX_FLAG, RSP_LSTAT_MULMP_FLAG-1
		.symbol	RSP_LSTAT_SETMTX_FLAG,   RSP_LSTAT_MULMP_FLAG
		.symbol	RSP_LSTAT_NUMLIGHT_FLAG, RSP_LSTAT_MULMP_FLAG+1

	#---------------------------------------------------------------------
	#  DRAM	FIFO への RDP コマンドを転送するための一時保存領域のポインタ
	#---------------------------------------------------------------------
RSP_LSTAT_DMA2BUF:
		.half	RSP_WORK_OUTPUT_0

	#---------------------------------------------------------------------
	#  Fog パラメータ
	#---------------------------------------------------------------------
RSP_LSTAT_FOG_FACTOR:
		.word	0
		.symbol	oRSP_LSTAT_FOG_FACTOR, \
				RSP_LSTAT_FOG_FACTOR-RSP_LSTAT_OFFSET

	#---------------------------------------------------------------------
	#  Texture 設定パラメータ (gSPTexture で設定)
	#---------------------------------------------------------------------
		.bound	4
RSP_LSTAT_TEX_CMD:
		.byte	0	# =G_TEXTURE
RSP_LSTAT_TEX_XPARAM:
		.byte	0	# =XPARAM (Normally 0)
RSP_LSTAT_TEX_TILE:
		.byte	0	# =TILE/LEVEL
RSP_LSTAT_TEX_ENABLE:
		.byte	0	# =G_ON(1)/G_OFF(0)
RSP_LSTAT_TEX_SCALE:
		.half	0	# S
		.half	0	# T
		.symbol	oRSP_LSTAT_TEX_SCALE, \
				RSP_LSTAT_TEX_SCALE-RSP_LSTAT_OFFSET

	#---------------------------------------------------------------------
	#  Geometry Mode
	#---------------------------------------------------------------------
RSP_LSTAT_RENDER:
		.half	G_CLIPPING_H
RSP_LSTAT_RENDER_CULL:	
		.byte	0	# G_CULL_FRONT=0x02 BACK=0x04 BOTH=0x06
RSP_LSTAT_RENDER_TRI:	
		.byte	0
			
	#---------------------------------------------------------------------
	#  Light データ
	#---------------------------------------------------------------------
			.bound	8
RSP_LSTAT_LOOKATX:	.space	24
RSP_LSTAT_LOOKATY:	.space	24
RSP_LSTAT_L_0:		.space	24
RSP_LSTAT_L_1:		.space	24
RSP_LSTAT_L_2:		.space	24
RSP_LSTAT_L_3:		.space	24
#ifndef	ALPHA_LIGHTING
RSP_LSTAT_L_4:		.space	24
RSP_LSTAT_L_5:		.space	24
RSP_LSTAT_L_6:		.space	24
RSP_LSTAT_L_7:		.space	24
#endif
	.symbol	oRSP_LSTAT_L_0, RSP_LSTAT_L_0-RSP_LSTAT_OFFSET
	.symbol	oRSP_LSTAT_LIGHT_COLOR,  0+oRSP_LSTAT_L_0
	.symbol	oRSP_LSTAT_LIGHT_DIR_W,  8+oRSP_LSTAT_L_0
	.symbol	oRSP_LSTAT_LIGHT_PAD,   12+oRSP_LSTAT_L_0
	.symbol	oRSP_LSTAT_LIGHT_DIR_M, 16+oRSP_LSTAT_L_0

	#---------------------------------------------------------------------
	#  Overlay テーブル
	#---------------------------------------------------------------------
RSP_LSTAT_OVERLAY_TOP:	
		.bound	4				
RSP_LSTAT_OVERLAY_TASKDONE:		# TaskDone/RSPyield/LoadUcode 処理
		.word	CODE_OFS_TASKDONE
		.half	CODE_SIZ_TASKDONE-1
		.half	0x1000		# Top of IMEM
RSP_LSTAT_OVERLAY_RSPBOOT:		# rspboot,doInit 上のコード
		.word	CODE_OFS_RSPBOOT
		.half	CODE_SIZ_RSPBOOT-1
		.half	0x1000		# Top of IMEM
RSP_LSTAT_OVERLAY_BOTTOM:
		.bound	4
		.symbol	RSP_LSTAT_OVERLAY_SIZE, \
			RSP_LSTAT_OVERLAY_BOTTOM-RSP_LSTAT_OVERLAY_TOP
		
	#---------------------------------------------------------------------
	#  MOVEMEM  の index に対応するオフセット値
	#---------------------------------------------------------------------
RSP_LSTAT_MOVEMEM_OFFSET:
		#------- G_MTX/POPMTX 用 -------
		.half	RSP_WORK_DMABUF			# MMTX + MUL
		.half	RSP_GSTAT_MMTX			# MMTX + LOAD
		.half	RSP_WORK_DMABUF			# PMTX + MUL
		.half	RSP_GSTAT_PMTX			# PMTX + LOAD
		#------- G_MOVEMEM 用 -------
		.half	RSP_GSTAT_VIEWPORT_SC		# ViewPort
		.half	RSP_LSTAT_LOOKATX		# Light 系
		#------- G_VTX 用 -------
		.half	RSP_SAVE_POINTS			# G_VTX
 #		.half	RSP_GSTAT_MPMTX			# MOVEWORD と共用する.

	#---------------------------------------------------------------------
	#  MOVEWORD の index に対応するオフセット値
	#---------------------------------------------------------------------
RSP_LSTAT_MOVEWORD_OFFSET:	
		.half	RSP_GSTAT_MPMTX			# MOVEMEM と共用
		.half	RSP_LSTAT_NUMLIGHT_FLAG		# NumLight   GBI 用
		.half	RSP_LSTAT_CLIPSELECT		# ClipRatio  GBI 用
		.half	RSP_GSTAT_SEG_OFFSET		# Segment    GBI 用
		.half	RSP_LSTAT_FOG_FACTOR		# SetFog     GBI 用
		.half	RSP_LSTAT_L_0			# LightColor GBI 用
		.half	RSP_LSTAT_FORCEMTX_FLAG		# ForceMtx   GBI 用
		.half	RSP_GSTAT_PERSPNORM		# PerspNorm  GBI 用
		
	#---------------------------------------------------------------------
	#  DMA 系命令用 Jump テーブル (Gfx の ID から Jump 先を求める)
	#	Gfx の ID が偶数で無ければならない.
	#---------------------------------------------------------------------
RSP_LSTAT_JUMPTBL_DMA:
		.half	case_G_MOVEMEM		# 0xd8  G_POPMTX
		.half	case_G_MTX_Mul		# 0xda  G_MTX+MUL
		.half	case_G_MOVEMEM		# 0xdc  G_MOVEMEM/G_MTX+LOAD

	#---------------------------------------------------------------------
	#  モジュール間共通 Jump テーブル
	#	Gfx の ID から Jump 先を求める)
	#---------------------------------------------------------------------
		.bound	2
		.half	case_G_SPECIAL_3	# 0xd3  G_SPECIAL_3
		.half	case_G_SPECIAL_2	# 0xd4  G_SPECIAL_2
		.half	case_G_SPECIAL_1	# 0xd5  G_SPECIAL_1
		.half	case_G_DMA_IO		# 0xd6	G_DMA_IO
		.half	case_G_TEXTURE		# 0xd7	G_TEXTURE
		.half	case_G_POPMTX		# 0xd8	G_POPMTX
		.half	case_G_GEOMETRYMODE	# 0xd9	G_GEOMETRYMODE
		.half	case_G_MTX		# 0xda	G_MTX
		.half	case_G_MOVEWORD		# 0xdb	G_MOVEWORD
		.half	case_G_DMA_General	# 0xdc	G_MOVEMEM
		.half	case_G_LOAD_UCODE	# 0xdd	G_LOAD_UCODE
		.half	case_G_DL		# 0xde	G_DL
		.half	case_G_ENDDL		# 0xdf	G_ENDDL
		.half	GfxDone			# 0xe0	G_SPNOOP
		.half	case_G_RDPHALF_1	# 0xe1	G_RDPHALF_1
		.half	case_G_SETOTHERMODE_L	# 0xe2	G_SETOTHERMODE_L
		.half	case_G_SETOTHERMODE_H	# 0xe3	G_SETOTHERMODE_H
		.half	case_G_RDPHALF_0	# 0xe4	G_TEXRECT
		.half	case_G_RDPHALF_0	# 0xe5	G_TEXRECTFLIP
		.half	case_G_RDP_General_Half	# 0xe6	G_RDPLOADSYNC
		.half	case_G_RDP_General_Half	# 0xe7	G_RDPPIPESYNC
		.half	case_G_RDP_General_Half	# 0xe8	G_RDPTILESYNC
		.half	case_G_RDP_General_Half	# 0xe9	G_RDPFULLSYNC
		.half	case_G_RDP_General	# 0xea	G_SETKEYGB
		.half	case_G_RDP_General	# 0xeb	G_SETKEYR
		.half	case_G_RDP_General	# 0xec	G_SETCONVERT
		.half	case_G_SETSCISSOR	# 0xed	G_SETSCISSOR
		.half	case_G_RDP_General	# 0xee	G_SETPRIMDEPTH
		.half	case_G_RDPSETOTHERMODE	# 0xef	G_RDPSETOTHERMODE
		.half	case_G_RDP_General	# 0xf0	G_LOADTLUT
		.half	case_G_TEXRECT_DONE	# 0xf1	G_RDPHALF_2
		.half	case_G_RDP_General	# 0xf2	G_SETTILESIZE
		.half	case_G_RDP_General	# 0xf3	G_LOADBLOCK
		.half	case_G_RDP_General	# 0xf4	G_LOADTILE
		.half	case_G_RDP_General	# 0xf5	G_SETTILE
		.half	case_G_RDP_General	# 0xf6	G_FILLRECT
		.half	case_G_RDP_General	# 0xf7	G_SETFILLCOLOR
		.half	case_G_RDP_General	# 0xf8	G_SETFOGCOLOR
		.half	case_G_RDP_General	# 0xf9	G_SETBLENDCOLOR
		.half	case_G_RDP_General	# 0xfa	G_SETPRIMCOLOR
		.half	case_G_RDP_General	# 0xfb	G_SETENVCOLOR
		.half	case_G_RDP_General	# 0xfc	G_SETCOMBINE
		.half	case_G_RDP_AdrsFixup	# 0xfd	G_SETTIMG 要 AdrsFixup
		.half	case_G_RDP_AdrsFixup	# 0xfe	G_SETZIMG 要 AdrsFixup
		.half	case_G_RDP_AdrsFixup	# 0xff	G_SETCIMG 要 AdrsFixup
RSP_LSTAT_JUMPTBL:
		.half	case_G_RDP_General_Half	# 0x00	G_NOOP

	#---------------------------------------------------------------------
	# これ以降は各モジュールに依存した GBI が並ぶので
	# 他の領域を追加してはいけない.
	#---------------------------------------------------------------------
		#----------------------------
		#  SUB MODULE 領域
		#----------------------------
RSP_SUBMOD_OFFSET:
#include	"gxdmem_submod.h"
		.dmax	0x800+1

/*======== End of gxdmem_lstat.h ========*/
