/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxdmem_gstat.h
	Coded    by	Yoshitaka Yasumoto.	Oct 15, 1997.
	
	$Id: gxdmem_gstat.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 *  グローバルステート
 *	LOADABLE なマイクロコード間で共通に使用するステータス領域
 *	F3DEX, S2DEX, ZSort の Release 2.00 以上のものが対応
 *	TASK 起動時に初期化されるが, gSPLoadUcode の前後で値を保持する.
 *	
 *	ベクトルレジスタへの Load, Store 命令は以下の範囲で有効なので注意する
 *		lqv/sqv		-0x400 〜 +0x3f0 
 *		ldv/sdv		-0x200 〜 +0x1f8
 *		llv/slv		-0x100 〜 +0x0fc
 *		lsv/ssv		-0x080 〜 +0x07e
 *		lbv/sbv		-0x040 〜 +0x03f
 *---------------------------------------------------------------------------*/
	#---------------------------------------------------------------------
	# 4x4 Matrix データ領域
	#  3D 系のマイクロコードで M,P,MP の各行列に使用する.
	#---------------------------------------------------------------------
			.bound	16	
RSP_GSTAT_MMTX:		.space	64	# M  行列
RSP_GSTAT_PMTX:		.space	64	# P  行列
RSP_GSTAT_MPMTX:	.space	64	# MP 行列

	#---------------------------------------------------------------------
	# シザリングパラメータ保存エリア (ldv でアクセス可能な位置)
	#      Line/Sprite のときにデコードして使用する.
	#---------------------------------------------------------------------
			.bound	8
RSP_GSTAT_SCISSOR:	.word	(0xed<<24)|(  0<<14)|(  0<<2)
			.word	(0x00<<24)|(320<<14)|(240<<2)
	
	#---------------------------------------------------------------------
	#  SetOtherMode パラメータ保存領域
	#   初期値
	#	0xef:	G_RDPSETOTHERMODE
	#	0x08	テクスチャパース補正 ON
	#	0x0c	Cycle0,1 のテクスチャ Bilerp ON
	#	0xff	rgb dither = no dither / alpha_dither = no dither
	#---------------------------------------------------------------------
			.bound	8
RSP_GSTAT_OTHER_H:	.word	0xef080cff
RSP_GSTAT_OTHER_L:	.word	0x00000000

	#---------------------------------------------------------------------
	# RDPHALF_0, RDPHALF_1 コマンドの保存領域
	#---------------------------------------------------------------------
	#	RSP_GSTATE_RDPHALF_0L と RSP_GSTATE_RDPHALF_1L のアドレス
	#	の差が 4Bytes = 1inst であることを利用して, g*rdp.s で命令
	#	を節約している. このためここに手を加えるときは, その部分を
	#	修正する必要がある. (case_G_RDPHALF_0/case_G_RDPHALF_1 の
	#	実装部)
	#	RSP_GSTAT_RDPHALF_1 の後半部は PERSPNORM の MOVEWORD のた
	#	めのダミー領域としても使用する. このため PERSPNORM の設定
	#	によって RDPHALF_1 の後半部が破壊されるが, 通常 RDPHALF 系
	#	命令の直後にそのデータを使用する命令が続くので問題はない.
	#---------------------------------------------------------------------
RSP_GSTAT_RDPHALF_0H:	.word	0x0
RSP_GSTAT_RDPHALF_0L:	.word	0x0
RSP_GSTAT_RDPHALF_1L:	.half	0x0
	
	#---------------------------------------------------------------------
	#  PerspNormalize の値
	#	lsv ではアクセスできないので llv でアクセスする.
	#	(llv でアクセス可能な位置 -0x100 〜 +0x0fc)
	#---------------------------------------------------------------------
RSP_GSTAT_PERSPNORM:	.half	0	# MOVEWORD の為の Padding
			.bound	4
			.dmax	0x0fc+1
RSP_GSTAT_VPERSPNORM:	.half	0xffff	# 有効なのは下位 16 bitのみ

	#---------------------------------------------------------------------
	# セーブした DL の数
	#	F3DEX/S2DEX では MainDL のみを参照.
	#	SubDL は ZSort のみで参照される.
	#---------------------------------------------------------------------
RSP_GSTAT_DL_N:		.byte	0		# Main DL
			.byte	18*4		# Sub  DL

	#---------------------------------------------------------------------
	# View Port パラメータ (ldv でアクセス可能な位置 -0x200 〜 +0x1f8)
	#---------------------------------------------------------------------
			.bound	8
RSP_GSTAT_VIEWPORT_SC:	.word	0
			.word	0
			.dmax	0x1f8+1
RSP_GSTAT_VIEWPORT_TX:	.word	0
			.word	0	
	
	#---------------------------------------------------------------------
	# 現在の FIFO 空き領域の先頭
	#---------------------------------------------------------------------
RSP_GSTAT_FIFO_OUTP:		.word	0x0

	#---------------------------------------------------------------------
	# 現在の DRAM STACK 空き領域の先頭
	#---------------------------------------------------------------------
RSP_GSTAT_DRAM_STACK:		.word	0x0

	#---------------------------------------------------------------------
	# セグメントテーブル
	#   Segment 0 のみ 0 に初期化しておく
	#   Assert 処理のために未初期化データには AID を代入しておく.
	#---------------------------------------------------------------------
RSP_GSTAT_SEG_OFFSET:		_word4	(0x0, AID, AID, AID)
				_word4	(AID, AID, AID, AID)
				_word4	(AID, AID, AID, AID)
				_word4	(AID, AID, AID, AID)

	#---------------------------------------------------------------------
	# DISPLAY LIST スタック (F3DEX と同じで 18 段)
	#   通常は .space 18*4 とするのだが, この位置にバージョン記述子
	#   を入れておく. これによって strings コマンドで rom ファイル
	#   からマイクロコードのバージョン番号を取得することが可能となる.
	#   バージョンが変更になるたびにここを修正する必要がある.
	#
	# [バージョン記述子の文字列]
	#     0 1 2 3 4 5 6 7 8 9 A B C D E F
	#  0 '\nR S P _ G f x _ u c o d e _ F '
	#  1 '3 D E X . N o N _ _ _ f i f o _ '
	#  2 '2 . 0 8 _ _ Y o s h i t a k a _ '
	#  3 'Y a s u m o t o _ 1 9 9 9 _ N i '
	#  4 'n t e n d o . \n'
	#---------------------------------------------------------------------
RSP_GSTAT_DLSTACK_OFFSET:
	#-----------------------------------------------
	# マイクロコード名称
	#-----------------------------------------------
#if	defined(SAFE_MODE)
					.byte	"RSP Gfx[Safe] "
#else
					.byte	"RSP Gfx ucode "
#endif
#if	defined(UCODE_ID)
					.byte	UCODE_ID
#elif	defined(UCODE_F3DEX2)
					.byte	"F3DEX       "
#elif	defined(UCODE_F3DEX2_NoN)
					.byte	"F3DEX.NoN   "
#elif	defined(UCODE_F3DEX2_Rej)
					.byte	"F3DEX.Rej   "
#elif	defined(UCODE_F3DLX2_Rej)
					.byte	"F3DLX.Rej   "
#elif	defined(UCODE_L3DEX2)
					.byte	"L3DEX       "
#elif	defined(UCODE_S2DEX2)
					.byte	"S2DEX       "
#else	
					ERROR:	$UCODE is not defined!!!!
#endif
#undef	_uc_id
	#-----------------------------------------------
	# RDP コマンドの転送形式
	#-----------------------------------------------
#if	defined(OUT_fifo)
					.byte	"fifo "
#elif	defined(OUT_xbus)
					.byte	"xbus "
#else
					ERROR:	$OUTTYPE is not defined!!!!
#endif
	
	#-----------------------------------------------
	# バージョン番号
	#   パッケージ毎に管理. 変更するのを忘れずに
	#-----------------------------------------------
#if	defined(UCPKG_S2DEX2)
					.byte	"2.08"
#elif	defined(UCPKG_F3DEX2)
					.byte	"2.08"
#elif	defined(UCPKG_ZSort)
					.byte	"x.xx"
#else
					ERROR:	$UCPKG is not defined!!!!
#endif	

	#-----------------------------------------------
	# サブバージョン番号
	#   亜流のマイクロコード用の番号 (ZELDA 用 etc)
	#-----------------------------------------------
#ifdef	SUBVER
					.byte	SUBVER
#else
					.byte	0x20
#endif
	#-----------------------------------------------
	# 著作表示
	#   年度が変更になったときに修正する必要がある
	#-----------------------------------------------
	.byte	" Yoshitaka Yasumoto 1999 Nintendo.\n"
	.byte	0

/*======== End of gxdmem_gstat.h ========*/
