/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxmacros.h
	Coded    by	Yoshitaka Yasumoto.	Oct 20, 1997.
	
	$Id: gxmacros.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

#define	_li(r, x)	addi	r, $0, x
#define	_liu(r, x)	addiu	r, $0, x
#define	_mov(r, s)	ori	r,  s, 0

#define	_byte4(b0,b1,b2,b3)	.byte b0 .byte b1 .byte b2 .byte b3
#define	_byte8(b0,b1,b2,b3,b4,b5,b6,b7)	_byte4(b0,b1,b2,b3) _byte4(b4,b5,b6,b7)
#define	_half4(h0,h1,h2,h3)	.half h0 .half h1 .half h2 .half h3
#define	_half8(h0,h1,h2,h3,h4,h5,h6,h7)	_half4(h0,h1,h2,h3) _half4(h4,h5,h6,h7)
#define	_word4(w0,w1,w2,w3)	.word w0 .word w1 .word w2 .word w3
#define	_word8(w0,w1,w2,w3,w4,w5,w6,w7)	_word4(w0,w1,w2,w3) _word4(w4,w5,w6,w7)

#define	dram_adrs		gfx1
#define	AssignForDMAproc	Assign(dma_len,   19)	\
				Assign(dmem_adrs, 20)
#define	EndAssignForDMAproc	EndAssign(dma_len,   19)	\
				EndAssign(dmem_adrs, 20)
#ifdef	ASSERT
#define	Assert_geI(reg,  imm)	addi	sys0, reg, -(imm)	\
				bgezal	sys0, AssertHandler
#define	Assert_geR(reg1, reg2)	sub	sys0, reg1, reg2	\
				bgezal	sys0, AssertHandler
#define	Assert_ltI(reg,  imm)	addi	sys0, reg, -(imm)	\
				bltzal	sys0, AssertHandler
#define	Assert_ltR(reg1, reg2)	sub	sys0, reg1, reg2	\
				bltzal	sys0, AssertHandler
#define	AID			0x12345678
#else
#define	Assert_geI(reg,  imm)
#define	Assert_geR(reg1, reg2)
#define	Assert_ltI(reg,  imm)
#define	Assert_ltR(reg1, reg2)	
#define	AID			0x00000000
#endif

#define	UCODE_START		TASKBASELO
#define	UCODE_ADRS(n)		((TASKBASELO & 0xffff0000)+(n))
#define	_begin_ISEG(t)	ISEG_##t##_BEGIN:	.bound	4
#define	_end_ISEG(t)	ISEG_##t##_END:					\
	.symbol	ISEG_##t##_OFFSET,    ISEG_##t##_BEGIN-UCODE_START	\
	.symbol	ISEG_##t##_SIZE,      ISEG_##t##_END-ISEG_##t##_BEGIN	\
	.symbol	ISEG_##t##_DMASIZE,   (ISEG_##t##_SIZE+7)&~7		\
	.symbol	ISEG_##t##_DMASIZE_1, ISEG_##t##_DMASIZE-1

#define	UCODE_AFTER(t)	SEG_##t##_DMAOFFSET+SEG_##t##_DMASIZE

/*======== End of gxmacros.h ========*/
