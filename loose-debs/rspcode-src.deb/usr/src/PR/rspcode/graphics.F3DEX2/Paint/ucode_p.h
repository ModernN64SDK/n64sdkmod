/*---------------------------------------------------------------------*
	Copyright (C) 1998, Nintendo.
	
	File		ucode_p.h
	Coded    by	Yoshitaka Yasumoto.	Apr  1, 1998.
	
	$Id: ucode_p.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/
#ifndef _UCODE_P_H_
#define	_UCODE_P_H_

#ifdef _LANGUAGE_C_PLUS_PLUS
extern "C" {
#endif

#if defined(_LANGUAGE_C) || defined(_LANGUAGE_C_PLUS_PLUS)

#ifndef		G_SPECIAL_1
# define	G_SPECIAL_1	0xd5
# define	G_MV_MMTX	2
#endif

#define	gSPForceMMtx(pkt, mptr)					\
{								\
  gDma0p((pkt), G_SPECIAL_1, 0, 1);				\
  gDma2p((pkt), G_MOVEMEM, (mptr), sizeof(Mtx), G_MV_MMTX, 0);	\
}

#define	gsSPForceMMtx(mptr)					\
{								\
  gsDma0p(G_SPECIAL_1, 0, 1),					\
  gsDma2p(G_MOVEMEM, (mptr), sizeof(Mtx), G_MV_MMTX, 0),	\
}

/*========== F3DZEX2/L3DZEX2 ==========*/
/* FIFO version */
extern long long int gspF3DPEX2_fifoTextStart[],
                     gspF3DPEX2_fifoTextEnd[];
extern long long int gspF3DPEX2_fifoDataStart[],
                     gspF3DPEX2_fifoDataEnd[];
extern long long int gspF3DPEX2_NoN_fifoTextStart[],
                     gspF3DPEX2_NoN_fifoTextEnd[];
extern long long int gspF3DPEX2_NoN_fifoDataStart[],
                     gspF3DPEX2_NoN_fifoDataEnd[];
extern long long int gspF3DPEX2_Rej_fifoTextStart[],
                     gspF3DPEX2_Rej_fifoTextEnd[];
extern long long int gspF3DPEX2_Rej_fifoDataStart[],
                     gspF3DPEX2_Rej_fifoDataEnd[];
extern long long int gspF3DPLX2_Rej_fifoTextStart[],
                     gspF3DPLX2_Rej_fifoTextEnd[];
extern long long int gspF3DPLX2_Rej_fifoDataStart[],
                     gspF3DPLX2_Rej_fifoDataEnd[];
extern long long int gspL3DPEX2_fifoTextStart[],
                     gspL3DPEX2_fifoTextEnd[];
extern long long int gspL3DPEX2_fifoDataStart[],
                     gspL3DPEX2_fifoDataEnd[];
/* XBUS version */
extern long long int gspF3DPEX2_xbusTextStart[],
                     gspF3DPEX2_xbusTextEnd[];
extern long long int gspF3DPEX2_xbusDataStart[],
                     gspF3DPEX2_xbusDataEnd[];
extern long long int gspF3DPEX2_NoN_xbusTextStart[],
                     gspF3DPEX2_NoN_xbusTextEnd[];
extern long long int gspF3DPEX2_NoN_xbusDataStart[],
                     gspF3DPEX2_NoN_xbusDataEnd[];
extern long long int gspF3DPEX2_Rej_xbusTextStart[],
                     gspF3DPEX2_Rej_xbusTextEnd[];
extern long long int gspF3DPEX2_Rej_xbusDataStart[],
                     gspF3DPEX2_Rej_xbusDataEnd[];
extern long long int gspF3DPLX2_Rej_xbusTextStart[],
                     gspF3DPLX2_Rej_xbusTextEnd[];
extern long long int gspF3DPLX2_Rej_xbusDataStart[],
                     gspF3DPLX2_Rej_xbusDataEnd[];
extern long long int gspL3DPEX2_xbusTextStart[],
                     gspL3DPEX2_xbusTextEnd[];
extern long long int gspL3DPEX2_xbusDataStart[],
                     gspL3DPEX2_xbusDataEnd[];
#endif /* _LANGUAGE_C */
#ifdef _LANGUAGE_C_PLUS_PLUS
}
#endif
#endif /* !_UCODE_P_H */

/*======== End of ucode_p.h ========*/
