/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxdmem_task.h
	Coded    by	Yoshitaka Yasumoto.	Oct 15, 1997.
	Modified by	
	
	$Id: gxdmem_task.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 *	Task 構造体領域
 *	
 *	OSTask のデータが CPU から渡される. 0x0fc0 から 0x0fff まで
 *---------------------------------------------------------------------------*/
	.symbol  RSP_TASK_OFFSET,	0x1000-OS_TASK_SIZE
	.symbol  GTASK_TYPE,		RSP_TASK_OFFSET+OS_TASK_OFF_TYPE
	.symbol  GTASK_FLAGS,		RSP_TASK_OFFSET+OS_TASK_OFF_FLAGS
	.symbol  GTASK_UCODE,		RSP_TASK_OFFSET+OS_TASK_OFF_UCODE
	.symbol  GTASK_STACK,		RSP_TASK_OFFSET+OS_TASK_OFF_STACK
	.symbol  GTASK_STACK_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_STACK_SZ
	.symbol  GTASK_OUTBUFF,		RSP_TASK_OFFSET+OS_TASK_OFF_OUTBUFF
	.symbol  GTASK_OUTBUFF_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_OUTBUFF_SZ
	.symbol  GTASK_DATA,		RSP_TASK_OFFSET+OS_TASK_OFF_DATA
	.symbol  GTASK_DATA_SZ,		RSP_TASK_OFFSET+OS_TASK_OFF_DATA_SZ
	.symbol  GTASK_YIELD,		RSP_TASK_OFFSET+OS_TASK_OFF_YIELD
	.symbol  GTASK_YIELD_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_YIELD_SZ
	
/*---------------------------------------------------------------------------*
 *	DEBUG 情報領域
 *	
 *	RSP 側で DEBUG 情報を CPU に渡す時に使う TMP 領域
 *---------------------------------------------------------------------------*/
	.symbol  ASSERT_WORKAREA,	RSP_TASK_OFFSET-0x10
	.symbol  ASSERT_DEBUG0,		ASSERT_WORKAREA+0x00
	.symbol  ASSERT_DEBUG1,		ASSERT_WORKAREA+0x04
	.symbol  ASSERT_DEBUG2,		ASSERT_WORKAREA+0x08
	.symbol  ASSERT_DEBUG3,		ASSERT_WORKAREA+0x0c
	.symbol  ASSERT_LOG_PTR,	GTASK_DATA_SZ

/*======== End of gxdmem_task.h ========*/
