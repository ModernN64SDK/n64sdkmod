/*---------------------------------------------------------------------*
	Copyright (C) 1998, Nintendo.
	
	File		ucode_f.h
	Coded    by	Yoshitaka Yasumoto.	Mar 30, 1998.
	
	$Id: ucode_f.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

#ifndef _UCODE_F_H_
#define	_UCODE_F_H_
#ifdef _LANGUAGE_C_PLUS_PLUS
extern "C" {
#endif
#if  (defined(_LANGUAGE_C)||defined(_LANGUAGE_C_PLUS_PLUS))

/*========== F3DFEX2/L3DFEX2 ==========*/
/* FIFO version */
extern	long long int	gspF3DFLX2_Rej_fifoTextStart[];
extern	long long int	gspF3DFLX2_Rej_fifoTextEnd[];
extern	long long int	gspF3DFLX2_Rej_fifoDataStart[];
extern	long long int	gspF3DFLX2_Rej_fifoDataEnd[];
/* XBUS version */
extern	long long int	gspF3DFLX2_Rej_xbusTextStart[];
extern	long long int	gspF3DFLX2_Rej_xbusTextEnd[];
extern	long long int	gspF3DFLX2_Rej_xbusDataStart[];
extern	long long int	gspF3DFLX2_Rej_xbusDataEnd[];

#define G_FZ_ADRS_ALTBL 0x000008b0

#define	gSPSetALTable(pkt, tbl)	\
	gSPDmaRead((pkt), G_FZ_ADRS_ALTBL, (tbl), 256)
#define	gsSPSetALTable(tbl)	\
	gsSPDmaRead(G_FZ_ADRS_ALTBL, (tbl), 256)

typedef	struct {
  signed	short	offset;
  signed	short	slope;
  unsigned	short	amax;
  unsigned	short	pad1;
  signed	short	dir[3];
  signed	short	pad2;
} AlphaLight_t;

typedef union {
  AlphaLight_t		a;
  long long int		force_alignment[2];
} AlphaLight;

typedef union {
  unsigned	char	t[256];
  long long int		force_alignment;
} AlphaTable;

#endif
#ifdef _LANGUAGE_C_PLUS_PLUS
}
#endif
#endif

/*======== End of ucode_f.h ========*/
