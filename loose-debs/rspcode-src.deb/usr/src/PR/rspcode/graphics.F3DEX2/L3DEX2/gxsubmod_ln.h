/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxsubmod_l3dex.h
	Coded    by	Yoshitaka Yasumoto.	Oct 31, 1997.
	
	$Id: gxsubmod_ln.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

RSP_SUBMOD_TOP_L3DEX2:	
	#---------------------------------------------------------------------
	#  RSP_LSTAT_DMEMSUBMOD
	#	モジュール依存 Jump テーブル			14 Bytes
	#---------------------------------------------------------------------
		.half	caseEX_G_VTX		# 0x01	G_VTX
		.half	caseEX_G_MODIFYVTX	# 0x02	G_MODIFYVTX
		.half	caseEX_G_CULLDL		# 0x03	G_CULLDL
		.half	caseEX_G_BRANCH_Z	# 0x04	G_BRANCH_Z
		.half	caseLN_G_TRI1		# 0x05	G_TRI1
		.half	caseLN_G_TRI2		# 0x06	G_TRI2
		.half	caseLN_G_TRI2		# 0x07	G_QUAD
		.half	caseLN_G_LINE3D		# 0x08	G_LINE3D

	#---------------------------------------------------------------------
	#  RSP_SUBMOD_POINTS:
	#	F3DEX/LX/LP/L3DEX それぞれに固有のパラメータ
	#						(0-32)  33x2 Bytes
	#---------------------------------------------------------------------
#define	_vtx(n)	.half	RSP_SAVE_POINTS+((n)*40)
RSP_SUBMOD_POINTS:	
		_vtx(0)  _vtx(1)  _vtx(2)  _vtx(3)  _vtx(4)
		_vtx(5)  _vtx(6)  _vtx(7)  _vtx(8)  _vtx(9)
		_vtx(10) _vtx(11) _vtx(12) _vtx(13) _vtx(14)
		_vtx(15) _vtx(16) _vtx(17) _vtx(18) _vtx(19)
		_vtx(20) _vtx(21) _vtx(22) _vtx(23) _vtx(24)
		_vtx(25) _vtx(26) _vtx(27) _vtx(28) _vtx(29)
		_vtx(30) _vtx(31) _vtx(32)
#undef	_vtx
	#---------------------------------------------------------------------
	#  RSP_SUBMOD_LN_RETURN
	#	WORK 用として使用する (gxline_ln.s/gxsetup_ln.s)
	#						(33)	1x2 Bytes
	#---------------------------------------------------------------------
RSP_SUBMOD_LN_RETURN:
		.half	0
	
	#---------------------------------------------------------------------
	#  Clip 処理判定用フラグマスク値
	#	0x30304040/80 gxsetup_ln.s で使用	(34-35)  2x2 Bytes
	#---------------------------------------------------------------------
		.bound	4
RSP_SUBMOD_LN_CLIPTEST:
#ifdef	NEARCLIP_OFF
		.word	0x30304080
#else
		.word	0x30304040
#endif		

	#---------------------------------------------------------------------
	#  Clip 用判定式係数				(36-47)	 12x2 Bytes
	#---------------------------------------------------------------------
		.bound	4
RSP_SUBMOD_LN_CLIPMASK:
		.word	0x00100000	# +X
		.word	0x00200000	# +Y
		.word	0x10000000	# -X
		.word	0x20000000	# -Y
		.word	0x00004000	# -Z
#ifdef	NEARCLIP_OFF
		.word	0x00000080	# +W
#else
		.word	0x00000040	# +Z
#endif
	#---------------------------------------------------------------------
	#  Scissor Box Decode 値			(48-51)	  4x2 Bytes
	#	RSP_GSTAT_SCISSOR の値をデコードして u16 x 4 のパラメータに
	#	しておく
	#---------------------------------------------------------------------
			.bound	8
RSP_SUBMOD_LN_SCIS_XL:	.half	0
RSP_SUBMOD_LN_SCIS_YL:	.half	0
RSP_SUBMOD_LN_SCIS_XH:	.half	320<<2
RSP_SUBMOD_LN_SCIS_YH:	.half	240<<2

			.bound	8
RSP_SUBMOD_BTM_L3DEX2:
	
	#---------------------------------------------------------------------
	#  RSP_POINTS のオフセット
	#	CC のフォーマットは  [-nW|0000|+nW|0000|-W|0000|+W|0000]
	#---------------------------------------------------------------------
		.symbol	oRSP_POINT_XI,	   0
		.symbol oRSP_POINT_WI,     6
		.symbol	oRSP_POINT_XF,     8
		.symbol	oRSP_POINT_R,     16
		.symbol	oRSP_POINT_A,     19
		.symbol	oRSP_POINT_S,     20
		.symbol	oRSP_POINT_XS,    24
		.symbol	oRSP_POINT_YS,    26
		.symbol	oRSP_POINT_ZS,    28
		.symbol	oRSP_POINT_ZSF,   30
		.symbol	oRSP_POINT_INVWI, 32
		.symbol	oRSP_POINT_CC,	  36
		.symbol	RSP_POINT_LEN,    40
		
/*======== End of gxsubmod_ln.h ========*/
