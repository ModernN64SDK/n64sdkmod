/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxsubmod_ex.h
	Coded    by	Yoshitaka Yasumoto.	Oct 31, 1997.
	
	$Id: gxsubmod_ex.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

RSP_SUBMOD_TOP_F3DEX2:
	#---------------------------------------------------------------------
	#  RSP_LSTAT_DMEMSUBMOD
	#	モジュール依存 Jump テーブル			16 Bytes
	#---------------------------------------------------------------------
		.half	caseEX_G_VTX		# 0x01	G_VTX
		.half	caseEX_G_MODIFYVTX	# 0x02	G_MODIFYVTX
		.half	caseEX_G_CULLDL		# 0x03	G_CULLDL
		.half	caseEX_G_BRANCH_Z	# 0x04	G_BRANCH_Z
		.half	caseEX_G_TRI1		# 0x05	G_TRI1
		.half	caseEX_G_TRI2		# 0x06	G_TRI2
		.half	caseEX_G_QUAD		# 0x07	G_QUAD
		.half	caseEX_G_LINE3D		# 0x08	G_LINE3D
				
	#---------------------------------------------------------------------
	#  RSP_SUBMOD_POINTS:
	#	F3DEX/LX/LP/L3DEX それぞれに固有のパラメータ
	#						(0-32)	33x2 Bytes
	#---------------------------------------------------------------------
#define	_vtx(n)	.half	RSP_SAVE_POINTS+((n)*40)
RSP_SUBMOD_POINTS:
		_vtx(0)  _vtx(1)  _vtx(2)  _vtx(3)  _vtx(4)
		_vtx(5)  _vtx(6)  _vtx(7)  _vtx(8)  _vtx(9)
		_vtx(10) _vtx(11) _vtx(12) _vtx(13) _vtx(14)
		_vtx(15) _vtx(16) _vtx(17) _vtx(18) _vtx(19)
		_vtx(20) _vtx(21) _vtx(22) _vtx(23) _vtx(24)
		_vtx(25) _vtx(26) _vtx(27) _vtx(28) _vtx(29)
		_vtx(30) _vtx(31) _vtx(32)
#undef	_vtx

	#---------------------------------------------------------------------
	#  CULL 判定用パラメータ (gxsetup で使用)
	#	2 Byte 毎に以下のパラメータを取得できる
	#	CULL なし	0xffff8000
	#	CULL_FRONT	0x80000000
	#	CULL_BACK	0x00000000
	#	CULL_BOTH	0x00008000		(33-37)	 5x2 Bytes
	#---------------------------------------------------------------------
RSP_SUBMOD_EX_CULL:
		.half	0xffff
		.half	0x8000
		.half	0x0000
		.half	0x0000
		.half	0x8000

	#---------------------------------------------------------------------
	#  Clip 処理判定用フラグマスク値
	#	0x30304040/80 gxsetup_ex.s で使用	(38-39)  2x2 Bytes
	#---------------------------------------------------------------------
RSP_SUBMOD_EX_CLIPTEST:
#ifdef	NEARCLIP_OFF
		.word	0x30304080
#else
		.word	0x30304040
#endif		

	#---------------------------------------------------------------------
	#  Clip 処理用ポインタバッファ			(40-59)  20x2 Bytes
	#---------------------------------------------------------------------
		.symbol	RSP_SUBMOD_EX_CLIPBUF_SZ, 2*10
RSP_SUBMOD_EX_CLIPBUF:
		.space	RSP_SUBMOD_EX_CLIPBUF_SZ*2

	#---------------------------------------------------------------------
	#  Clip 用判定式係数				(60-71)	 12x2 Bytes
	#---------------------------------------------------------------------
RSP_SUBMOD_EX_CLIPMASK:
		.word	0x00100000	# +X
		.word	0x00200000	# +Y
		.word	0x10000000	# -X
		.word	0x20000000	# -Y
		.word	0x00004000	# -Z
#ifdef	NEARCLIP_OFF
		.word	0x00000080	# +W
#else
		.word	0x00000040	# +Z
#endif
	#---------------------------------------------------------------------
	#  RSP_SUBMOD_OVERLAY
	#	Overlay テーブル			(72-79)	 8x2 Bytes
	#---------------------------------------------------------------------
		.bound	4
RSP_SUBMOD_OVERLAY_LIGHTING:			# Lighting コード
		.word	CODE_OFS_LIGHTING
		.half	CODE_SIZ_LIGHTING-1
		.half	CODE_TOP_CLIPPING
RSP_SUBMOD_OVERLAY_CLIPPING:			# Clipping コード
		.word	CODE_OFS_CLIPPING
		.half	CODE_SIZ_CLIPPING-1
		.half	CODE_TOP_CLIPPING
RSP_SUBMOD_BTM_F3DEX2:
	#---------------------------------------------------------------------
	#  RSP_POINTS のオフセット
	#	CC のフォーマットは  [-nW|0000|+nW|0000|-W|0000|+W|0000]
	#---------------------------------------------------------------------
		.symbol	oRSP_POINT_XI,	   0
		.symbol	oRSP_POINT_XF,     8
		.symbol	oRSP_POINT_WI,     6
		.symbol	oRSP_POINT_R,     16
		.symbol	oRSP_POINT_A,     19
		.symbol	oRSP_POINT_S,     20
		.symbol	oRSP_POINT_XS,    24
		.symbol	oRSP_POINT_YS,    26
		.symbol	oRSP_POINT_ZS,    28
		.symbol	oRSP_POINT_ZSF,   30
		.symbol	oRSP_POINT_INVWI, 32
		.symbol	oRSP_POINT_CC,	  36

/*======== End of gxsubmod_ex.h ========*/
