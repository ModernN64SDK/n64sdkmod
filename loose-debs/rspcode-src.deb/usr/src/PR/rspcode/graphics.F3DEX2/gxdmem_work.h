/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxdmem_work.h
	Coded    by	Yoshitaka Yasumoto.	Oct 17, 1997.
	
	$Id: gxdmem_work.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 *  一時ワーク領域
 *      Yield および SPLoadUcode の前後で保持されない領域.
 *---------------------------------------------------------------------------*/
	#---------------------------------------------------------------------
	#  G_MTX 用 DMA エリア
	#    Clipping 可能なマイクロコードの場合
	#	クリッピング用ワークエリアを使用する.
	#    Fifo マイクロコードの場合
	#	OUTPUT バッファの領域の最後の 176 バイト分は, DMA による
	#	転送をする分には空いている(時系列的に)ので, そこを DMA バッ
	#	ファとして使う. 16 バイト境界に一致させるため, 実際に使用可
	#	能なサイズは 168 バイトとなる.
	#    その他(F3DLX2.Rej)の場合
	#	gxsubmod_lxrej.h で 32 バイト確保しているので残り 32 バイト
	#	を確保する.
	#---------------------------------------------------------------------
#if	(defined(UCODE_F3DEX2)||     \
	 defined(UCODE_F3DEX2_NoN)|| \
	 defined(UCODE_L3DEX2))
			.symbol	RSP_WORK_DMABUF, (RSP_WORK_CLIPVTX+8)&~15
#elif	(defined(UCODE_F3DEX2_Rej)|| \
	 defined(UCODE_F3DLX2_Rej))
#  if	defined(OUT_fifo)
			.symbol	RSP_WORK_DMABUF, (RSP_WORK_OUTPUT_THD_1+8)&~15
#  else
			.bound	16
RSP_WORK_DMABUF:	.space	64
#  endif
#else		/*S2DEX2*/
#endif	

	#---------------------------------------------------------------------
        # DISPLAY LIST キャッシュ (DRAM から何個かの DL を DMA 転送する領域)
	#	一度にまとめてロードしておき, それを順に使用する.
	#	このあとのワーク領域の 16 Byte 整列のために奇数個を設定する
        #---------------------------------------------------------------------
RSP_DLINPUT_OFFSET:	.bound  8			# 8 バイト整列が必要
		        .symbol GX_MAX_DL, 21		# 一度に転送する DL 数
			.space  GX_MAX_DL*8		# 領域確保
	        .symbol RSP_DLINPUT_BOTTOM, RSP_DLINPUT_OFFSET+GX_MAX_DL*8
							# 最後尾の取得

	#---------------------------------------------------------------------
	# クリッピング用ワークエリア
	#
	#  F3DEX2 の場合
	#      12 頂点分のデータ領域を持つ
	#	1 クリップ面につき 2 頂点が新たに生成される可能性がある.
	#  L3DEX2 の場合
	#	6 頂点分のデータ領域を持つ
	#	1 クリップ面につき 1 頂点が新たに生成される可能性がある.
	#  Rejection マイクロコードの場合
	#	必要ない.
	#	その分 Output FIFO を増やす.
	#---------------------------------------------------------------------
#if	(defined(UCODE_F3DEX2)||defined(UCODE_F3DEX2_NoN))
RSP_WORK_CLIPVTX:	.bound	8
			.space	40*12
#elif	(defined(UCODE_L3DEX2))
RSP_WORK_CLIPVTX:	.bound	8
			.space	40*6
#else
#endif	
	#---------------------------------------------------------------------
	#  DRAM FIFO へ RDP コマンドを転送するための一時保存領域
	#	この領域をダブルバッファにすることでポリゴン処理を早くする.
	#	1 領域につき最低でも 176*2(=2TRI分) Bytes 欲しい.
	#	これによって DMA 転送の終了を待たずに次のポリゴンの処理を
	#	行なうことが可能.
	#	またこの領域を DMA 系命令のデータ IO エリアとしても併用可
	#	能となる.
	#---------------------------------------------------------------------
RSP_WORK_OUTPUT:	
	.bound  8
#if	defined(SAFE_MODE)
	.symbol	RSP_WORK_OUTPUT_SAFE, 8
#else
	.symbol	RSP_WORK_OUTPUT_SAFE, 0
#endif

#if	defined(UCODE_L3DEX2)
	# 1 Line の最大サイズ  1Tri+Scissor
	.symbol RSP_WORK_OUTPUT_MINSZ, 176+8+RSP_WORK_OUTPUT_SAFE
#elif	defined(UCODE_S2DEX2)
	# 1 Sprite の最大サイズ  (32+64)*2+8*4
	#	(Edge+Textue)が 2 枚
	#	sync*2, setTile, setTileSize
	.symbol RSP_WORK_OUTPUT_MINSZ, (32+64)*2+8*4+RSP_WORK_OUTPUT_SAFE
#else
	# 1 Tri  の最大サイズ  Sh+Tx+Zb
	.symbol RSP_WORK_OUTPUT_MINSZ, 176+RSP_WORK_OUTPUT_SAFE
#endif

#ifdef	USE_MINIMUM
	# 最低限必要なサイズ
	.symbol RSP_WORK_OUTPUT_BUFSZ,   RSP_WORK_OUTPUT_MINSZ*2
	.symbol RSP_WORK_OUTPUT_BUFSZ_1, RSP_WORK_OUTPUT_MINSZ*2
#else
# if	defined(UCODE_S2DEX2)&&defined(OUT_fifo)
	# 大きすぎるのも FIFO 領域に確保に困るので補正する
	.symbol	RSP_WORK_OUTPUT_BUFSZ,   0x400
	.symbol	RSP_WORK_OUTPUT_BUFSZ_1, 0x400
# else
	# 最大サイズ
	.symbol RSP_WORK_OUTPUT_BUFSZ,   ((0x0fc0-RSP_WORK_OUTPUT)/2)&0xff8
	.symbol RSP_WORK_OUTPUT_BUFSZ_1, ((0x0fc8-RSP_WORK_OUTPUT)/2)&0xff8
# endif
#endif
	# 次のいかなる GBI 処理でも溢れないサイズ
	.symbol RSP_WORK_OUTPUT_TSZ,   \
		RSP_WORK_OUTPUT_BUFSZ-RSP_WORK_OUTPUT_MINSZ
	.symbol RSP_WORK_OUTPUT_TSZ_1, \
		RSP_WORK_OUTPUT_BUFSZ_1-RSP_WORK_OUTPUT_MINSZ

RSP_WORK_OUTPUT_0:
	.space  RSP_WORK_OUTPUT_BUFSZ
	.symbol	RSP_WORK_OUTPUT_THD_0, RSP_WORK_OUTPUT_0+RSP_WORK_OUTPUT_TSZ
RSP_WORK_OUTPUT_1:
#if	defined(OUT_fifo)
	.space  RSP_WORK_OUTPUT_BUFSZ
	.symbol	RSP_WORK_OUTPUT_THD_1, RSP_WORK_OUTPUT_1+RSP_WORK_OUTPUT_TSZ
#elif	defined(OUT_xbus)
	.space  RSP_WORK_OUTPUT_BUFSZ_1
	.symbol	RSP_WORK_OUTPUT_THD_1, RSP_WORK_OUTPUT_1+RSP_WORK_OUTPUT_TSZ_1
#endif

/*======== End of gxdmem_work.h ========*/
