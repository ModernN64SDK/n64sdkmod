/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxsubmod_lxrej.h
	Coded    by	Yoshitaka Yasumoto.	Oct 31, 1997.
	
	$Id: gxsubmod_lxrej.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

RSP_SUBMOD_TOP_F3DLX2_Rej:
	#---------------------------------------------------------------------
	#  RSP_LSTAT_DMEMSUBMOD
	#	モジュール依存 Jump テーブル			16 Bytes
	#---------------------------------------------------------------------
		.half	caseLXRej_G_VTX		# 0x01	G_VTX
		.half	caseLXRej_G_MODIFYVTX	# 0x02	G_MODIFYVTX
		.half	caseLXRej_G_CULLDL	# 0x03	G_CULLDL
		.half	caseLXRej_G_BRANCH_Z	# 0x04	G_BRANCH_Z
#if	defined(UCODE_F3DLX2_Rej)
		.half	caseLXRej_G_TRI1	# 0x05	G_TRI1
		.half	caseLXRej_G_TRI2	# 0x06	G_TRI2
		.half	caseLXRej_G_TRI2	# 0x07	G_QUAD # Emulate
		.half	caseLXRej_G_LINE3D	# 0x08	G_LINE3D
#elif	defined(UCODE_F3DEX2_Rej)
		.half	caseEXRej_G_TRI1	# 0x05	G_TRI1
		.half	caseEXRej_G_TRI2	# 0x06	G_TRI2
		.half	caseEXRej_G_TRI2	# 0x07	G_QUAD # Emulate
		.half	caseEXRej_G_LINE3D	# 0x08	G_LINE3D
#endif
	#---------------------------------------------------------------------
	#  RSP_SUBMOD_POINTS:
	#	F3DEX/LX/LP/L3DEX それぞれに固有のパラメータ
	#						(0-64)	65x2 Bytes
	#---------------------------------------------------------------------
RSP_SUBMOD_POINTS:	
#define	_vtx(n)	.half	RSP_SAVE_POINTS+((n)*20)
		_vtx(0)  _vtx(1)  _vtx(2)  _vtx(3)  _vtx(4)
		_vtx(5)  _vtx(6)  _vtx(7)  _vtx(8)  _vtx(9)
		_vtx(10) _vtx(11) _vtx(12) _vtx(13) _vtx(14)
		_vtx(15) _vtx(16) _vtx(17) _vtx(18) _vtx(19)
		_vtx(20) _vtx(21) _vtx(22) _vtx(23) _vtx(24)
		_vtx(25) _vtx(26) _vtx(27) _vtx(28) _vtx(29)
		_vtx(30) _vtx(31) _vtx(32) _vtx(33) _vtx(34)
		_vtx(35) _vtx(36) _vtx(37) _vtx(38) _vtx(39)
		_vtx(40) _vtx(41) _vtx(42) _vtx(43) _vtx(44)
		_vtx(45) _vtx(46) _vtx(47) _vtx(48) _vtx(49)
		_vtx(50) _vtx(51) _vtx(52) _vtx(53) _vtx(54)
		_vtx(55) _vtx(56) _vtx(57) _vtx(58) _vtx(59)
		_vtx(60) _vtx(61) _vtx(62) _vtx(63) _vtx(64)
#undef	_vtx
	
	#---------------------------------------------------------------------
	#  Culling 処理判定用フラグマスク値
	#	外積値に vch _0x0001 をかけ, 
	#	外積値>0 なら vcc[13,9]=1, <0 なら vcc[5,1]=1
	#	で判定する. AND 処理で 0 でないなら描画
	#						(65-68)   4x2 Bytes
	#---------------------------------------------------------------------
RSP_SUBMOD_LXRej_CULLMASK:
		.half	0x2222		# CULL_NON
		.half	0x2200		# CULL_FRONT
		.half	0x0022		# CULL_BACK
		.half	0x0000		# CULL_BOTH

		# Vtx 69-71 残り
		.space	2*3
		.bound	8

RSP_SUBMOD_BTM_F3DLX2_Rej:
		.symbol	oRSP_POINT_R,      0
		.symbol	oRSP_POINT_A,      3
		.symbol	oRSP_POINT_S,      4
		.symbol	oRSP_POINT_XS,     8
		.symbol	oRSP_POINT_YS,    10
		.symbol	oRSP_POINT_ZS,    12
		.symbol	oRSP_POINT_ZSF,   14
		.symbol	oRSP_POINT_INVWI, 16
		.symbol	oRSP_POINT_INVWF, 18
		.symbol	RSP_POINT_LEN,    20
		
/*======== End of gxsubmod_lxrej.h ========*/
