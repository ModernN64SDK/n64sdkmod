/*---------------------------------------------------------------------*
	Copyright (C) 1997, Nintendo.
	
	File		gxdmem_submod.h
	Coded    by	Yoshitaka Yasumoto.	Nov  7, 1997.
	Modified by	
	
	$Id: gxdmem_submod.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
 *---------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 *  サブモジュール領域
 *	各サブモジュールにおいて固有に使用するステータス領域
 *---------------------------------------------------------------------------*/

	#---------------------------------------------------------------------
	#  モジュール依存 Jump テーブル				16 Bytes
	#	.half	case*_G_VTX		# 0x01	G_VTX
	#	.half	case*_G_MODIFYVTX	# 0x02	G_MODIFYVTX
	#	.half	case*_G_CULLDL		# 0x03	G_CULLDL
	#	.half	case*_G_BRANCH_Z	# 0x04	G_BRANCH_Z
	#	.half	case*_G_TRI1		# 0x05	G_TRI1
	#	.half	case*_G_TRI2		# 0x06	G_TRI2
	#	.half	case*_G_QUAD		# 0x07	G_QUAD
	#	.half	case*_G_LINE3D		# 0x08	G_LINE3D
	#---------------------------------------------------------------------
	#  F3DEX/LX/LP/L3DEX それぞれに固有のパラメータ		160 Bytes
	#    RSP_SUBMOD_POINTS:
	#	.space	2*80
	#---------------------------------------------------------------------
	#  RSP_SUBMOD_OVERLAY
	#	Overlay テーブル				16 Bytes
	#---------------------------------------------------------------------
	#  それぞれのサブモジュールの組み込み
	#---------------------------------------------------------------------
#if		(defined(UCODE_F3DEX2)||defined(UCODE_F3DEX2_NoN))
# include	"F3DEX2/gxsubmod_ex.h"
#elif		(defined(UCODE_F3DEX2_Rej)||defined(UCODE_F3DLX2_Rej))
# include	"F3DLX2.Rej/gxsubmod_lxrej.h"
#elif		(defined(UCODE_L3DEX2))
# include	"L3DEX2/gxsubmod_ln.h"
#endif

/*======== End of gxdmem_submod.h ========*/
