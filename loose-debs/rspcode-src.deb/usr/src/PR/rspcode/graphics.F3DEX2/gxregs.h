/*---------------------------------------------------------------------
	Copyright (C) 1997, Nintendo.
	
	File		gxregs.h
	Coded    by	Yoshitaka Yasumoto.	Jan 23, 1997.
	
	$Id: gxregs.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
  ---------------------------------------------------------------------*/
#ifndef	ASSERT_UNNAME

#define	Assign(n, reg)		.unname UNUSE##reg  .name n, $##reg
#define	EndAssign(n, reg)	.unname n  .name UNUSE##reg, $##reg

#define	FixedAssign		Assign

#define	R(a)	.name	UNUSE##a, $##a
	R(0)   R(1)   R(2)   R(3)   R(4)   R(5)   R(6)   R(7)
	R(8)   R(9)   R(10)  R(11)  R(12)  R(13)  R(14)  R(15)
	R(16)  R(17)  R(18)  R(19)  R(20)  R(21)  R(22)  R(23)
	R(24)  R(25)  R(26)  R(27)  R(28)  R(29)  R(30)  R(31)
	R(v0)  R(v1)  R(v2)  R(v3)  R(v4)  R(v5)  R(v6)  R(v7)
	R(v8)  R(v9)  R(v10) R(v11) R(v12) R(v13) R(v14) R(v15)
	R(v16) R(v17) R(v18) R(v19) R(v20) R(v21) R(v22) R(v23)
	R(v24) R(v25) R(v26) R(v27) R(v28) R(v29) R(v30) R(v31)
#undef	R
	Assign(zero,        0)
	Assign(sys0,       11)	/* DMA 系命令で tmp として使用 */
	Assign(sys1,       12)
	Assign(outpThd,    22)	/* F3DEX と共通 */
	Assign(outp,       23)	/* F3DEX と共通 */
	Assign(gfx1,       24)	/* F3DEX と共通 */
	Assign(gfx0,       25)	/* F3DEX と共通 */
	Assign(inp,        26)	/* F3DEX と共通 */
	Assign(dinp,       27)	/* F3DEX と共通 */
	Assign(return,     31)
	Assign(vzero,      v0)	/* 全ての要素が 0 */
	Assign(vone,       v1)	/* 全ての要素が 1 */
	Assign(vconst1,   v30)
	Assign(vconst0,   v31)

#ifdef	UCODE_S2DEX2
	Assign(vecptr,     30)
	Assign(vtmp,      v27)
	Assign(vconst3,   v28)
	Assign(vconst2,   v29)
#define	vconst	vconst0
#else
	Assign(vtmp,      v29)
#endif

#else
	EndAssign(zero,      0)
	EndAssign(sys0,	    11)
	EndAssign(sys1,     12)
	EndAssign(outpThd,  22)	/* F3DEX と共通 */
	EndAssign(outp,     23)	/* F3DEX と共通 */
	EndAssign(gfx1,     24)	/* F3DEX と共通 */
	EndAssign(gfx0,     25)	/* F3DEX と共通 */
	EndAssign(inp,      26)	/* F3DEX と共通 */
	EndAssign(dinp,     27)	/* F3DEX と共通 */
	EndAssign(return,   31)
	EndAssign(vzero,    v0)	/* 全ての要素が 0 */
	EndAssign(vone,     v1)	/* 全ての要素が 1 */
	EndAssign(vconst1, v30)
	EndAssign(vconst0, v31)
	
#ifdef	UCODE_S2DEX2
	EndAssign(vecptr,   30)
	EndAssign(vtmp,    v27)
	EndAssign(vconst3, v28)
	EndAssign(vconst2, v29)
#undef	vconst
#else
	EndAssign(vtmp,    v29)
#endif

#define	R(a)	.unname	UNUSE##a	.name	UNUSE##a, $##a
	R(0)   R(1)   R(2)   R(3)   R(4)   R(5)   R(6)   R(7)
	R(8)   R(9)   R(10)  R(11)  R(12)  R(13)  R(14)  R(15)
	R(16)  R(17)  R(18)  R(19)  R(20)  R(21)  R(22)  R(23)
	R(24)  R(25)  R(26)  R(27)  R(28)  R(29)  R(30)  R(31)
	R(v0)  R(v1)  R(v2)  R(v3)  R(v4)  R(v5)  R(v6)  R(v7)
	R(v8)  R(v9)  R(v10) R(v11) R(v12) R(v13) R(v14) R(v15)
	R(v16) R(v17) R(v18) R(v19) R(v20) R(v21) R(v22) R(v23)
	R(v24) R(v25) R(v26) R(v27) R(v28) R(v29) R(v30) R(v31)
#undef	R	
#endif
	
/*======== End of gxregs.h ========*/
