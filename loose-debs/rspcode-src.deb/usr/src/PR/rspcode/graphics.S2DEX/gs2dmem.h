/*---------------------------------------------------------------------
	Copyright (C) 1997, Nintendo.
	
	File		gs2dmem.h
	Coded    by	Yoshitaka Yasumoto.	Jan 24, 1997.
	Modified by	
	Comments	
	
	$Id: gs2dmem.h,v 1.1.1.1 2002/05/02 03:29:12 blythe Exp $
  ---------------------------------------------------------------------*/
	.align	16
	.bound	16

/*---------------------------------------------------------------------------*
 *	グローバルステート
 *	LOADABLE なマイクロコード間で共通に使用するステータス領域
 *	
 *	TASK 起動時に初期化される. gSPLoadUcode の前後で値を保持する.
 *	ベクトルレジスタでの lqv 可能領域は +63 までなので注意が必要
 *---------------------------------------------------------------------------*/
RSP_STATE_OFFSET:	

	#---------------------------------------------------------------------
	# 4x4 Matrix データ領域
	#  3D 系のマイクロコードで M,P,MP の各行列に使用する.
	#---------------------------------------------------------------------
			.bound	16	
RSP_STATEP_MMTX:	.space	64	# M  行列
RSP_STATEP_PMTX:	.space	64	# P  行列
RSP_STATEP_MPMTX:	.space	64	# MP 行列
		
	#---------------------------------------------------------------------
	# シザリングパラメータ保存エリア (llv でアクセス可能な位置 +252)
	#---------------------------------------------------------------------
			.bound	4
			.dmax	63*4
RSP_STATEP_SCISSOR_XL:	.half	0
RSP_STATEP_SCISSOR_XH:	.half	320<<2
RSP_STATEP_SCISSOR_YL:	.half	0
RSP_STATEP_SCISSOR_YH:	.half	240<<2
	
	#---------------------------------------------------------------------
	# SetOtherMode パラメータ保存領域
	#   初期値
	#	0xef:	G_RDPSETOTHERMODE
	#	0x08	テクスチャパース補正 ON
	#	0x0c	Cycle0,1 のテクスチャ Bilerp ON
	#	0xff	rgb dither = no dither / alpha_dither = no dither
	#---------------------------------------------------------------------
RSP_STATEP_OTHER_H:	.word	0xef080cff
RSP_STATEP_OTHER_L:	.word	0x00000000

	#---------------------------------------------------------------------
	# セーブした DL の数
	#---------------------------------------------------------------------
RSP_STATEP_DL_N:	.byte	0
			.space	1	# Dummy --- PADDING
	
	#---------------------------------------------------------------------
	# 現在の RDP の状態
	#   Sync を管理するために導入. 以下の条件で Sync コマンドを発行する
	#
	#	(A) プリミティブの作画前に RDP_STAT_LOADTILE なら PipeSync を
	#	    送信し, RDP_STAT_PRIM_TILE(n) に変更.
	#	(B) レンダーモードの変更時に RDP_STAT_PRIMITIVE なら PipeSync
	#	    を送信し, RDP_STAT_NON に変更.
	#	(C) LoadTile/LoadBlock/LoadTLUT 時に RDP_STAT_PRIM_TILE(n) な
	#	    ら LoadSync を送信し, RDP_STAT_LOADTILE に変更.
	#	(D) SetTile で TILE n 変更時に RDP_STAT_PRIM_TILE(n) なら
	#	    TileSync を送信し, RDP_STAT_NON に変更.
	#	(E) SetTile で LOADTILE の変更時に RDP_STAT_LOADTILE なら
	#	    TileSync を送信し, RDP_STAT_NON に変更.
	#	(F) ユーザが発行した sync があれば全て RSP_STAT_NON にする
	#   
	#	実際は ユーザが直接 RDP の LOAD コマンドを発行したときに
	#	それに応じたモードに切り替える必要があるがそれによるオーバー
	#	ヘッドがイヤなのでやめる. そのため (F) も手を抜いている.
	#---------------------------------------------------------------------
#define	RDP_STAT_NON		0x80
#define	RDP_STAT_LOADTILE	0x81		         /* TMEM ロード中 */
#define	RDP_STAT_PRIMITIVE	0x00		    /* プリミティブ作画中 */
#define	RDP_STAT_PRIM_TILE(n)	(RDP_STAT_PRIMITIVE+(n)) /* TILE n 使用中 */

RSP_STATEP_RDP_STAT:	.byte	RDP_STAT_NON	

	#---------------------------------------------------------------------
	# 現在のプリミティブで使用している Tile 記述子
	#	0<->2 と変化する
	#---------------------------------------------------------------------
RSP_STATEP_RENDERTILE:	.byte	2	# 初期値は 2
			
	#---------------------------------------------------------------------
	# 現在の FIFO 空き領域の先頭
	#---------------------------------------------------------------------
RSP_STATEP_FIFO_OUTP:	.word	0x0

	#---------------------------------------------------------------------
	# RDPHALF_0, RDPHALF_1 コマンドの保存領域
	#---------------------------------------------------------------------
RSP_STATEP_RDPHALF_0H:	.word	0x0
RSP_STATEP_RDPHALF_0L:	.word	0x0
RSP_STATEP_RDPHALF_1L:	.word	0x0
			.word	0	# Dummy --- Padding
	
	#---------------------------------------------------------------------
	# セグメントテーブル
	#   Segment 0 のみ 0 に初期化しておく
	#   Assert 処理のために未初期化データには AID を代入しておく.
	#---------------------------------------------------------------------
RSP_SEG_OFFSET:		_word4	(0x0, AID, AID, AID)
			_word4	(AID, AID, AID, AID)
			_word4	(AID, AID, AID, AID)
			_word4	(AID, AID, AID, AID)

	#---------------------------------------------------------------------
	# DISPLAY LIST スタック (F3DEX と同じで 18 段)
	#	通常は .space 18*4 とするのだが, 
	#	この位置にバージョン記述子を入れておく 
	#---------------------------------------------------------------------
RSP_DLSTACK_OFFSET:
	_word4	(AID, AID, AID, AID)
	#
	# 'RSP Gfx ucode S2DEX 1.07  Yoshitaka Yasumoto Nintendo.\n\0'
	#
	#----------\nR S P     _ G f x     _ u c o     d e _ S
	_word4	(0x0a525350, 0x20476678, 0x2075636f, 0x64652053)
#ifdef	ASSERT
	#----------2 D E X     D _ 1 .     0 7 _ Y     o s h i 
	_word4	(0x32444558, 0x4420312e, 0x30372059, 0x6f736869)
#else
	#----------2 D E X     _ _ 1 .     0 7 _ Y     o s h i 
	_word4	(0x32444558, 0x2020312e, 0x30372059, 0x6f736869)
#endif
	#----------t a k a     _ Y a s     u m o t     o _ N i 
	_word4	(0x74616b61, 0x20596173, 0x756d6f74, 0x6f204e69)
	#----------n t e n 
	.word	 0x6e74656e
	#----------d o . \n
	.word	 0x646f2e0a

/*---------------------------------------------------------------------------*
 *	ローカルステート
 *	マイクロコードにおいて固有に使用するステータス領域
 *	
 *	TASK 起動時および gSPLoadUcode で初期化される. 
 *---------------------------------------------------------------------------*/
RSP_LSTATE_OFFSET:
	
    #---------------------------------------------------------------------
    # ベクトルレジスタ用エリア (vecptr でのアクセスが可能)
    #---------------------------------------------------------------------

	#---------------------------------------------------------------------
	# ベクトルレジスタ定数 (lqv でアクセス可能な位置)
	#---------------------------------------------------------------------
			.bound	16
#define	______	0x0000
			#---- vconst = $v31 の値 ----
RSPOBJ_VCONST:		_half4	(0x0800, 0x0040, 0x0002, 0xffff)
			_half4	(0x4000, 0x0003, 0x0008, 0xfff8)
			#---- vconst1 = $v30 の値 ----
RSPOBJ_VCONST1:		_half4	(0x0100, 0x8000, 0xfe00, 0x0000) # [3|7]
			_half4	(0x1000, 0x0400, 0x2000, 0x0200) # には意味あり
			#---- vconst2 = $v29 の値 ----
RSPOBJ_VCONST2:		_half4	(0x3d10, 0x0001, 0x3200, 0x0000)
			_half4	(0x2700, 0x0000, 0x3524, 0x2628)
			#---- vconst3 = $v28 の値 ----
RSPOBJ_VCONST3:		_half4	(0xfffc, 0x0400, 0x0020, 0x0010)
			_half4	(0xfc00, 0x03ff, 0x001f, 0xffe0)

			.symbol	RSPOBJ_VPTR, RSPOBJ_VCONST+64
			.symbol	oRSPOBJ_VCONST,  RSPOBJ_VCONST-RSPOBJ_VPTR
			.symbol	oRSPOBJ_VCONST1, RSPOBJ_VCONST1-RSPOBJ_VPTR
			.symbol	oRSPOBJ_VCONST2, RSPOBJ_VCONST2-RSPOBJ_VPTR
			.symbol	oRSPOBJ_VCONST3, RSPOBJ_VCONST3-RSPOBJ_VPTR

	#---- ベクトル演算に使用する ----#
#define	_0x0000		vconst2[3]
#define	_0x0001		vconst2[1]
#define	_0x0002		vconst[2]
#define	_0xffff		vconst[3]
#define	_0x4000		vconst[4]
#define	_0x0003		vconst[5]
#define	_0x0008		vconst[6]
#define	_0xfff8		vconst[7]
#define	_0x0100		vconst1[0]
#define	_0x8000		vconst1[1]	/* vconst1[1]である必要 -> gs2sprite */
#define	_0xfe00		vconst1[2]	
#define	_Reserved0	vconst1[3]
#define	_Reserved1	vconst1[4]
#define	_Reserved2	vconst1[5]
#define	_0x2000		vconst1[6]
#define	_0x0200		vconst1[7]	/* gs2rect で [3] と共に使用 */
#define	_0x0800		vconst[0]	/* [0] でなければならない gs2bg1c.s */
#define	_0x0040		vconst[1]
#define	_0xfffc		vconst3[0]
#define	_0x0400		vconst3[1]
#define	_0x0020		vconst3[2]
#define	_0x0010		vconst3[3]
#define	_0xfc00		vconst3[4]
#define	_0x03ff		vconst3[5]
#define	_0x001f		vconst3[6]
#define	_0xffe0		vconst3[7]

	#---- RDP コマンドの設定に使用する ----#
#define	_0x10000400	vconst1[8]	/* 4<<10, 1<<10     */
#define	_0x3d100001	vconst2[0]	/* G_SETTIMG        */
#define	_0x32000000	vconst2[4]	/* G_SETTILE << 24 */
#define	_0x27000000	vconst2[8]	/* [LOADTILE7]<< 24 二度使用する */
#define	_0x27		vconst2[8]	/* G_PIPESYNC       */
#define	_0x35		vconst2[12]	/* G_SETTILE        */
#define	_0x24		vconst2[13]	/* G_TXTRRECT       */
#define	_0x26		vconst2[14]	/* G_RDPLOADSYNC    */
#define	_0x28		vconst2[15]	/* G_RDPTILESYNC    */
#define	_COPYMODESCALE	_0x10000400
#define	_SETTXTRIMG	_0x3d100001
#define	_SETTILESIZE	_0x32000000
#define	_SETTILE	_0x35
#define	_TXTRRECT	_0x24
#define	_LOADSYNC	_0x26
#define	_PIPESYNC	_0x27
#define	_TILESYNC	_0x28
#define	_TX_LOADTILE	_0x27000000

	#---------------------------------------------------------------------
	# ベクトルレジスタ用スクラッチエリア
	#   16 byte アサインがなされている.
	#---------------------------------------------------------------------
			.bound	16
RSPOBJ_VSCRATCH:	.space	32
			.symbol	oRSPOBJ_VSCRATCH, RSPOBJ_VSCRATCH-RSPOBJ_VPTR
	
	#---------------------------------------------------------------------
	# スプライト変形用行列 (lqv でアクセス可能な位置)
	#   頂点 (x,y) が以下の式で (x',y') に移動する.
	#	x' = Ax + By + X
	#	y' = Cx + Dy + Y
	#   Assert 処理のために未初期化データには AID を代入しておく.
	#---------------------------------------------------------------------
			.bound	16
RSPOBJ_MATRIX:		_word4	(1<<16,AID,AID,1<<16)	# 行列 A,B,C,D
RSPOBJ_MATRIX_X:	.half	0			# 行列 X
RSPOBJ_MATRIX_Y:	.half	0			# 行列 Y
			.symbol	oRSPOBJ_MATRIX, RSPOBJ_MATRIX-RSPOBJ_VPTR
			.symbol	oRSPOBJ_MATRIX_X, RSPOBJ_MATRIX_X-RSPOBJ_VPTR
			.symbol	oRSPOBJ_MATRIX_Y, RSPOBJ_MATRIX_Y-RSPOBJ_VPTR

	#---------------------------------------------------------------------
	# Rectangle 座標計算ベース値
	#   DMA 転送によりこの 4 byte は MATRIX と同時にロードされる
	#   このため RSPOBJ_MATRIX の直後になければならない.
	#---------------------------------------------------------------------
RSPOBJ_BASE_SCALEX:	.half	1<<10
RSPOBJ_BASE_SCALEY:	.half	1<<10
		.symbol	oRSPOBJ_BASE_SCALEX, RSPOBJ_BASE_SCALEX-RSPOBJ_VPTR
		.symbol	oRSPOBJ_BASE_SCALEY, RSPOBJ_BASE_SCALEY-RSPOBJ_VPTR
	
	# --------------------------------------------------------------------
	# Rect/Sprite の Shrink パラメータ
	#
	#                               Shrink 0     Shrink 1     Shrink 2
	# Texture のシフト量            0x0000       0x0010       0x0020
	# Sprite  サイズの縮小量        0x0000       0x0020       0x0040
	# Rect   の objXY のシフト量 P  0x0001       0x0001       0x0001
	#                            B  0xfffe       0x0001       0xfffe
	# Sprite の objXY のシフト量 P  0xfffe       0x0001       0xfffe
	#                            B  0xfffe       0x0001       0xfffe
	# --------------------------------------------------------------------
#define	iSHRINK_IMGST		0
#define	iSHRINK_IMGWH		1
#define	iSHRINK_R_OBJXY		2
#define	iSHRINK_S_OBJXY		3

			.bound	8
RSPOBJ_SHRINKPARAM:	.half	0x0000	# Texture  のシフト量
			.half	0x0000	# Sprite   サイズの縮小量
			.half	0x0001	# Rect   での objXY のシフト量
			.half	0xfffe	# Sprite での objXY のシフト量
		.symbol	oRSPOBJ_SHRINKPARAM, RSPOBJ_SHRINKPARAM-RSPOBJ_VPTR

	# --------------------------------------------------------------------
	# Bilerp 時における BG のパラメータ
	# --------------------------------------------------------------------
RSPBG_BILERPPARAM:	
			.half	0x0020		# 1<<5
			.half	0xffff		# -1
		.symbol	oRSPBG_BILERPPARAM, RSPBG_BILERPPARAM-RSPOBJ_VPTR

			.half	0	# Dummy - Padding
			.half	0	# Dummy - Padding
					
    #-------------------------------------------------------------------------
    # 非ベクトルレジスタ用エリア (vecptr でのアクセスをしない)
    #-------------------------------------------------------------------------
		
	#---------------------------------------------------------------------
	# G_OBJ_LOADTXTR の複合命令のための Jump テーブル
	#---------------------------------------------------------------------
	# adrs_G_OBJ_RECT_Txtr_NEG は adrs_G_OBJ_RECT_Txtr に 0x8000 を OR し
	# lh 命令でのロード時に負の値となるようにしたものである.
	# これにより, gfx0 < 0 となり, case_G_OBJ_RECT_R 処理へ進む.
	#
RSPOBJ_LDTX_TABLE:
	.half	GfxDone
	.half	adrs_G_OBJ_SPRITE_Txtr		# G_OBJ_LDTX_SPRITE
	.half	adrs_G_OBJ_RECT_Txtr		# G_OBJ_LDTX_RECT
	.half	adrs_G_OBJ_RECT_Txtr_NEG	# G_OBJ_LDTX_RECT_R

	# --------------------------------------------------------------------
	# image のシュリンク量のテーブル
	#
	#      Shrink   0   1   2   3  /  0a  1a  2a  3a
	#   ------------------------------------------------------
	#      IMGST    0  16  32  48      0  16  32  48
	#      IMGWH    0  32  64  96    -12  20  52  84
	# --------------------------------------------------------------------
RSPOBJ_SHRINKIMG_TBL:	_half8	(  0,  0, 16, 32, 32, 64, 48, 96)
			_half8	(  0,-12, 16, 20, 32, 52, 48, 84)

	# --------------------------------------------------------------------
	# objXY のシフト量のテーブル
	#                               Shrink 0     Shrink 1     Shrink 2
	# Rect   の objXY のシフト量 P  0x0001       0x0001       0x0001
	#                            B  0xfffe       0x0000       0xfffe
	# Sprite の objXY のシフト量 P  0xfffe       0x0000       0xfffe
	#                            B  0xfffe       0x0000       0xfffe
	# --------------------------------------------------------------------
RSPOBJ_SHRINKOBJ_TBL:	#	 P0-R    P0-S    B0-R    B0-S
			_half4	(0x0001, 0xfffe, 0xfffe, 0xfffe)
			#	 P1-R    P1-S    B1-R    B1-S
			_half4	(0x0001, 0x0000, 0x0000, 0x0000)

	#---------------------------------------------------------------------
	# OBJ 表示モード用パラメータテーブル
	#---------------------------------------------------------------------
			.bound	8
#define	iCUT_SUBPIX		0
#define	iGET_SUBPIX		1
#define	iR_ADD_IMGST		2
#define	iS_ADD_OBJOFS		3

RSPOBJ_RENDERTBL_SMODE:
	# --- Bilerp Off の場合
	.half	0xfffc		# R/S共通の SubPixel 切捨値
	.half	0x0000		#           SubPixel シフト量取得用 Mask 値
	.half	0x0000		# Rect   の imgST  の加算値
	.half	0x0001		# Sprite の objOfs の加算値
	# --- Bilerp On  の場合
	.half	0xffff		# R/S共通の SubPixel 切捨値
	.half	0x0003		#           SubPixel シフト量取得用 Mask 値
	.half	0xfff0		# Rect   の imgST  の加算値
	.half	0x0000		# Sprite の objOfs の加算値
	
	.bound	8
#define	iTWIN_FLIPST		0
#define	iTWIN_FLIPSC		1

RSPOBJ_RENDERTBL_TWINDOW:
	# ---Texture Window On  の場合 (default)
	.half	0x0001		# S,T   値への係数 (+1)
	.half	0xffff		# scale 値への係数 (-1)
	.word	0x00080200	# SETTILE MaskS=MaskT=0  Clamp
	# ---Texture Window Off の場合
	.half	0xffff		# S,T   値への係数 (-1)
	.half	0x0001		# scale 値への係数 (+1)
	.word	0x0007c1f0	# SETTILE MaskS=MaskT=15 Mirror/gs2bg.sで参照
	# 注意!!!
	# gs2bg.s において RENDERTILE を設定しているコードがこのテーブルを参照
	# しているため, もしこのテーブルの値を変更した場合, 以下のシンボルを修
	# 正する必要がある.
	.symbol	RSPOBJ_SETTILE_MIRROR, RSPOBJ_RENDERTBL_TWINDOW+12
	
	.bound	16

	#---------------------------------------------------------------------
	# OBJ 表示モード保存エリア (必要？)
	#---------------------------------------------------------------------
RSPOBJ_RENDERMODE:	.half	0x0000

	#---------------------------------------------------------------------
	# OBJ 表示モード用パラメータポインタ
	#---------------------------------------------------------------------
RSPOBJ_RENDERP_SMODE:	.half	RSPOBJ_RENDERTBL_SMODE
RSPOBJ_RENDERP_TWINDOW:	.half	RSPOBJ_RENDERTBL_TWINDOW
	
	#---------------------------------------------------------------------
	# TMEM のサイズ計算用パラメータテーブル
	#	(u15.1) or (s14.1) フォーマットになっている
	#---------------------------------------------------------------------
RSPBG_TMEMSIZE_TBL:
		.half	1024<<1		# RGBA
		.half	1024<<1		# YUV
		.half	 512<<1		# CI
		.half	1024<<1		# IA
		.half	1024<<1		# I
	
	#---------------------------------------------------------------------
	# BG の TMEM バウンダリ計算用パラメータテーブル
	#    imageX から tmemS と tmemX を計算するためのパラメータ
	#    ピクセルのサイズに依存する
	#---------------------------------------------------------------------
		.bound	8
RSPBG_IMAGEX_TO_TMEM:
		#  4bit
		.half	16*4-1		# tmemS の値は 0 から 15.75 まで
		.half		0x0800	# /(16*2)
		.half		0x1000	# /16
		.half		0x0080	# /(16*32)		
		#  8bit
		.half	 8*4-1		# tmemS の値は 0 から  7.75 まで
		.half		0x1000	# /( 8*2)
		.half		0x2000	# /8
		.half		0x0100	# /(8*32)
		# 16bit
		.half	 4*4-1		# tmemS の値は 0 から  3.75 まで
		.half		0x2000	# /( 4*2)
		.half		0x4000	# /4
		.half		0x0200	# /(4*32)
		# 32bit
		.half	 2*4-1		# tmemS の値は 0 から  1.75 まで
		.half		0x4000	# /( 2*2)
		.half		0x8000	# /2
		.half		0x0400	# /(2*32)

	#---------------------------------------------------------------------
	# SBG の TMEM バウンダリ計算用パラメータテーブル
	#---------------------------------------------------------------------
RSPSBG_TMEMPARAM:
	.bound		8
	.half		0x01ff		# tmemMask
	.half		0x0080		# 1/tmemShift 1/0x200
	.half		0x00ff		# tmemMask
	.half		0x0100		# 1/tmemShift 1/0x100
	.half		0x007f		# tmemMask
	.half		0x0200		# 1/tmemShift 1/0x080
	.half		0x003f		# tmemMask
	.half		0x0400		# 1/tmemShift 1/0x040
	#---------------------------------------------------------------------
	# SBG 版の TMEM のサイズ計算用パラメータテーブル
	#---------------------------------------------------------------------
RSPSBG_TMEMSIZE_TBL:
	.half	0x400		# RGBA
	.half	0x400		# YUV
	.half	0x200		# CI
	.half	0x400		# IA
	.half	0x400		# I
	
	.half	0		# Dummy - Padding
	.half	0		# Dummy - Padding
	.half	0		# Dummy - Padding
	
	.bound	16
	#---------------------------------------------------------------------
	# テクスチャ, パレットのロード状態フラグ
	#   ロードが既に行なわれているかどうかを
	#      STATE & MASK == FLAG
	#   であるかどうかで判定する. これが真なら既にロードされていると
	#   みなし, ロード命令をスキップする.
	#   偽なら, ロードを行ない,
	#      STATE = (STATE & ~MASK) | (FLAG & MASK)
	#   のように, STATE を更新する.
	#
	#   MASK=0, FLAG!=0 の場合, 上記判定式は常に偽となる.
	#   データを常にロードしたい場合は MASK=0 FLAG!=0 と指定すればよい.
	#---------------------------------------------------------------------
				.bound	4
RSPOBJ_GENSTAT_A_STATEP:	.word	0x00000000
RSPOBJ_GENSTAT_B_STATEP:	.word	0x00000000
RSPOBJ_GENSTAT_C_STATEP:	.word	0x00000000
RSPOBJ_GENSTAT_D_STATEP:	.word	0x00000000
		.symbol	RSPOBJ_GENSTAT_TABLE, RSPOBJ_GENSTAT_A_STATEP

	.bound	16
	#---------------------------------------------------------------------
	# スプライトの頂点座標計算係数
	#   0-3,1-2 がそれぞれ対角線になる       0+--+1
	#   V0(0,0) V1(1,0) V2(0,1) V3(1,1)       |  |
	#                                        2+--+3
	#   マトリクス乗算後の Y 座標に関して a<b<d,a<c<d となるように
	#   並べる.
	#---------------------------------------------------------------------
RSP_VTX_INDEX:
	.bound	16
	#         b c  a d   b c  a d                       a  b  c  d
	_half8	( 1,0, 0,1,  0,1, 0,1)	# C >=0, D >=0 の時 V0,V1,V2,V3
	_half8	( 0,1, 1,0,  0,1, 0,1)	# C < 0, D >=0 の時 V1,V0,V3,V2
	_half8	( 0,1, 1,0,  1,0, 1,0)	# C < 0, D < 0 の時 V3,V2,V1,V0
	_half8	( 1,0, 0,1,  1,0, 1,0)	# C >=0, D < 0 の時 V2,V3,V0,V1

	#---------------------------------------------------------------------
	# Overlay パラメータ
	#---------------------------------------------------------------------
#define	OVERLAY_OFFSET	0
#define	OVERLAY_SIZE	4
#define	OVERLAY_DEST	6
			.bound	4
OVERLAY_0_OFFSET:	.word	OVERLAY_P0_OFFSET
			.half	OVERLAY_P0_SIZE
			.half	0x1000
OVERLAY_1_OFFSET:	.word	OVERLAY_P1_OFFSET
			.half	OVERLAY_P1_SIZE
			.half	OVERLAY_AREA1
OVERLAY_2_OFFSET:	.word	OVERLAY_P2_OFFSET
			.half	OVERLAY_P2_SIZE
			.half	OVERLAY_AREA1
	
	#---------------------------------------------------------------------
	# Jump テーブル
	#   虫食いだらけだが, いずれ fix したときに他の定数値やステータス
	#   値とマージする
	#---------------------------------------------------------------------
	.bound	2
RSP_JUMPTABLE_TOP:
	#---- IMM 系 
	.half	case_G_SWITCH_UCODE		# 0xaf +
	.half	case_G_SELECT_DL		# 0xb0
	.half	case_G_OBJ_RENDERMODE		# 0xb1
	.half	case_G_OBJ_RECT_R		# 0xb2 DMA 系だが諸事情がある為
	.half	case_G_TEXRECT_DONE		# 0xb3 + F3DEX では G_RDPHALF_2
	.half	case_G_RDPHALF_1		# 0xb4 +
	.half	GfxDone				# 0xb5
	.half	GfxDone				# 0xb6
	.half	GfxDone				# 0xb7
        .half   case_G_ENDDL			# 0xb8 +
        .half   case_G_SETOTHERMODE_L		# 0xb9 +
        .half   case_G_SETOTHERMODE_H		# 0xba +
        .half   GfxDone				# 0xbb
	.half   case_G_MOVEWORD			# 0xbc +
	.half	GfxDone	# case_G_SPRITE2D_DRAW		# 0xbd
	.half	GfxDone	# case_G_SPRITE2D_SCALEFLIP	# 0xbe
	.half	GfxDone				# 0xbf
	#---- RDP 系 
	.half	case_G_RDP_General		# 0xc0	G_NOOP
	.half	case_G_OBJ_LOADTMEM		# 0xc1 RDP 系のところにお邪魔
        .half   case_G_OBJ_LDTM_SPRITE		# 0xc2 G_OBJ_LOADTMEM と同位置
        .half   case_G_OBJ_LDTM_RECT		# 0xc3 G_OBJ_LOADTMEM と同位置
        .half   case_G_OBJ_LDTM_RECT_R		# 0xc4 G_OBJ_LOADTMEM と同位置
	.space	(0xe4-0xc5)*2
	.half	case_G_RDPHALF_0		# 0xe4	G_TEXRECT     IMM 系
	.half	case_G_RDPHALF_0		# 0xe5	G_TEXRECTFLIP IMM 系
	.half	case_G_RDP_Sync			# 0xe6	G_RDPLOADSYNC
	.half	case_G_RDP_Sync			# 0xe7	G_RDPPIPESYNC
	.half	case_G_RDP_Sync			# 0xe8	G_RDPTILESYNC
	.half	case_G_RDP_Sync			# 0xe9	G_RDPFULLSYNC
	.half	case_G_RDP_General		# 0xea	G_SETKEYGB
	.half	case_G_RDP_General		# 0xeb	G_SETKEYR
	.half	case_G_RDP_General		# 0xec	G_SETCONVERT
	.half	case_G_SETSCISSOR		# 0xed	G_SETSCISSOR
	.half	case_G_RDP_General		# 0xee	G_SETPRIMDEPTH
	.half	case_G_RDPSETOTHERMODE		# 0xef	G_RDPSETOTHERMODE
	.half	case_G_RDP_General		# 0xf0	G_LOADTLUT
	.half	GfxDone				# 0xf1	
	.half	case_G_RDP_General		# 0xf2	G_SETTILESIZE
	.half	case_G_RDP_General		# 0xf3	G_LOADBLOCK
	.half	case_G_RDP_General		# 0xf4	G_LOADTILE	
	.half	case_G_RDP_General		# 0xf5	G_SETTILE
	.half	case_G_RDP_General		# 0xf6	G_FILLRECT
	.half	case_G_RDP_General		# 0xf7	G_SETFILLCOLOR
	.half	case_G_RDP_General		# 0xf8	G_SETFOGCOLOR
	.half	case_G_RDP_General		# 0xf9	G_SETBLENDCOLOR
	.half	case_G_RDP_General		# 0xfa	G_SETPRIMCOLOR
	.half	case_G_RDP_General		# 0xfb	G_SETENVCOLOR
	.half	case_G_RDP_General		# 0xfc	G_SETCOMBINE
	.half	case_G_RDP_AdrsFixup		# 0xfd	G_SETTIMG 要 AdrsFixup
	.half	case_G_RDP_AdrsFixup		# 0xfe	G_SETZIMG 要 AdrsFixup
	.half	case_G_RDP_AdrsFixup		# 0xff	G_SETCIMG 要 AdrsFixup
	#---- DMA 系
RSP_JUMPTABLE_ORIG:	
	.half	GfxDone				# 0x00 + G_NOP
	.half	overlay_G_BG_1CYC		# 0x01
	.half	case_G_BG_COPY			# 0x02
	.half	case_G_OBJ_RECT			# 0x03
	.half	case_G_OBJ_SPRITE		# 0x04
	.half	case_G_OBJ_MOVEMEM		# 0x05
	.half	case_G_DL			# 0x06 +
RSP_JUMPTABLE_BOTTOM:

	#---------------------------------------------------------------------
	# GBI Assert テーブル
	#   有効な GBI かどうか ASSERT かけるためのテーブル
	#   この値を参照して DL の ID が正しいかどうかを判定する
	#---------------------------------------------------------------------
#ifdef	ASSERT
#define	TBL(a,b,c,d, e,f,g,h, i,j,k,l, m,n,o,p)	\
	(((a)<<15)|((b)<<14)|((c)<<13)|((d)<<12)|((e)<<11)|\
	 ((f)<<10)|((g)<< 9)|((h)<< 8)|((i)<< 7)|((j)<< 6)|\
	 ((k)<< 5)|((l)<< 4)|((m)<< 3)|((n)<< 2)|((o)<< 1)|((p)<< 0))
	.bound	4
RSP_ASSERT_DL_TABLE:	
	#           0 1 2 3   4 5 6 7   8 9 a b   c d e f
	.half	TBL(1,1,1,1,  1,1,1,0,  0,0,0,0,  0,0,0,0)	# 00-0f
	.half	0						# 10-1f
	_word4	(0, 0, 0, 0)					# 20-9f
	.half	TBL(0,0,0,0,  0,0,0,0,  0,0,0,0,  0,0,0,1)	# a0-af
	.half	TBL(0,1,1,1,  1,0,0,0,  1,1,1,0,  1,0,0,0)	# b0-bf
	.half	TBL(1,1,1,1,  1,0,0,0,  0,0,0,0,  0,0,0,0)	# c0-cf
	.half	0						# d0-df
	.half	TBL(0,0,0,0,  1,1,1,1,  1,1,1,1,  1,1,1,1)	# e0-ef
	.half	TBL(1,0,1,1,  1,1,1,1,  1,1,1,1,  1,1,1,1)	# f0-ff
#undef	TBL
#endif
		
	#---------------------------------------------------------------------
	# MOVEMEM offset テーブル
	#---------------------------------------------------------------------
			.bound	2
RSP_MOVEMEM_TBL:	.half	RSPOBJ_MATRIX		# gSPObjMatrix   (24B)
			.half	RSPOBJ_MATRIX_X		# gSPObjSubMatrix (8B)

	#---------------------------------------------------------------------
	# MOVEWORD offset テーブル
	#---------------------------------------------------------------------
			.bound	2
RSP_MOVEWORD_TBL:	.half	RSP_SEG_OFFSET		# segment table
			.half	RSPOBJ_GENSTAT_A_STATEP	# GenStat Table
			.symbol	MOVEWORD_TBL_BEGIN, 6	# =G_MW_SEGMENT
			.symbol	MOVEWORD_TBL_END,   8	# =G_MW_GENSTAT
			.dmax	2048-1

			.bound	16
END_OF_DMEM_INIT:	.symbol	DummyInit, 0

/*---------------------------------------------------------------------------*
 *	Yield セーブ領域
 *	
 *	Yield の前後で保持される.
 *---------------------------------------------------------------------------*/
	#---------------------------------------------------------------------
	# DISPLAY LIST キャッシュ (40 個分の DL を保持)
	#---------------------------------------------------------------------
	.symbol	GS_MAX_DL,		40
	.bound	8
RSP_DLINPUT_OFFSET:
	.space	GS_MAX_DL*8
	.symbol	RSP_DLINPUT_BOTTOM,	RSP_DLINPUT_OFFSET+GS_MAX_DL*8	

	#---------------------------------------------------------------------
	# スクラッチバッファおよび Yield 時のレジスタ保存エリア
	#---------------------------------------------------------------------
RSP_SCRATCH_OFFSET:
	.space	16

/*---------------------------------------------------------------------------*
 *	一時ワーク領域
 *	
 *	Yield の前後でも保持されない.
 *---------------------------------------------------------------------------*/

	#---------------------------------------------------------------------
	# DMA 系命令用ローディングエリア
	#---------------------------------------------------------------------
RSP_INPUT_OFFSET:	.bound	16
			.space	8
RSP_INPUT_TMEM:		.space	8	# 24 Bytes
			.bound	16
RSP_INPUT_BG:		.space	16	# 40 Bytes
			.bound	16
RSP_INPUT_SPRITE:	.space	24	# 24 Bytes
	
	#---------------------------------------------------------------------
	# レジスタ一時待避エリア
	#---------------------------------------------------------------------
RSP_TMP_AREA:		.space	64
	# gs2bg1cycL.s
	.symbol	RSPBG_TMP_frameX0,		RSP_TMP_AREA+0
	.symbol	RSPBG_TMP_frameX1,		RSP_TMP_AREA+2
	.symbol	RSPBG_TMP_framePtrY0,		RSP_TMP_AREA+4
	.symbol	RSPBG_TMP_frameRemain,		RSP_TMP_AREA+6
	.symbol	RSPBG_TMP_flagBilerp,		RSP_TMP_AREA+8
	.symbol	RSPBG_TMP_flagSplit,		RSP_TMP_AREA+9
	.symbol	RSPBG_TMP_tmemSliceWmax,	RSP_TMP_AREA+10
	.symbol	RSPBG_TMP_imageLYoffset,	RSP_TMP_AREA+12
	.symbol	RSPBG_TMP_frameSliceLines,	RSP_TMP_AREA+16
	.symbol	RSPBG_TMP_frameLSliceL0,	RSP_TMP_AREA+20
	.symbol	RSPBG_TMP_imageYorig,		RSP_TMP_AREA+24
	.symbol	RSPBG_TMP_imagePtrX0,		RSP_TMP_AREA+28
	.symbol	RSPBG_TMP_imageSrcWsize,	RSP_TMP_AREA+30
	.symbol	RSPBG_TMP_rdpSetTimg_w0,	RSP_TMP_AREA+32
	.symbol	RSPBG_TMP_rdpSetTile_w0,	RSP_TMP_AREA+36
	.symbol	RSPBG_TMP_imageISliceL0,	RSP_TMP_AREA+40
	.symbol	RSPBG_TMP_imageSliceLines,	RSP_TMP_AREA+42
	.symbol	RSPBG_TMP_imageSliceSize0,	RSP_TMP_AREA+44
	.symbol	RSPBG_TMP_imageSliceSize,	RSP_TMP_AREA+48
	.symbol	RSPBG_TMP_tmemSrcLines,		RSP_TMP_AREA+52
	.symbol	RSPBG_TMP_imageIY0,		RSP_TMP_AREA+54
	# short
    .symbol oRSPBG_TMP_frameX0,		RSPBG_TMP_frameX0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_frameX1,		RSPBG_TMP_frameX1-RSP_TMP_AREA
    .symbol oRSPBG_TMP_framePtrY0,	RSPBG_TMP_framePtrY0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_flagBilerp,	RSPBG_TMP_flagBilerp-RSP_TMP_AREA
    .symbol oRSPBG_TMP_tmemSliceWmax,	RSPBG_TMP_tmemSliceWmax-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageSliceLines,	RSPBG_TMP_imageSliceLines-RSP_TMP_AREA
    .symbol oRSPBG_TMP_frameSliceLines,	RSPBG_TMP_frameSliceLines-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageLYoffset,	RSPBG_TMP_imageLYoffset-RSP_TMP_AREA
    .symbol oRSPBG_TMP_frameLSliceL0,	RSPBG_TMP_frameLSliceL0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageISliceL0,	RSPBG_TMP_imageISliceL0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageYorig,	RSPBG_TMP_imageYorig-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imagePtrX0,	RSPBG_TMP_imagePtrX0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageIY0,	RSPBG_TMP_imageIY0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageSliceSize,	RSPBG_TMP_imageSliceSize-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageSliceSize0,	RSPBG_TMP_imageSliceSize0-RSP_TMP_AREA
    .symbol oRSPBG_TMP_imageSrcWsize,	RSPBG_TMP_imageSrcWsize-RSP_TMP_AREA
#if 0
	.symbol	oRSPBG_TMP_frameRemain,		RSPBG_TMP_frameRemain-RSP_TMP_AREA
#endif

	#---------------------------------------------------------------------
	# RDP コマンドの一時保存領域
	#---------------------------------------------------------------------
			.bound	8
			.symbol	RSP_OUTPUT_BUFSZ, 1024
RSP_OUTPUT_OFFSET:	.space	RSP_OUTPUT_BUFSZ
	
	# Texture Triangle の場合 4*8 for Edge  8*8 for Texture となり
        # さらにそれが 2 枚必要
	# また sync コマンド 2 つと setTile, setTileSize が必要
	.symbol	RSP_OUTPUT_END,     RSP_OUTPUT_BUFSZ+RSP_OUTPUT_OFFSET
	.symbol	RSP_OUTPUT_ENOUGH,  RSP_OUTPUT_END-12*8*2-8*4
	.symbol	RSP_YIELD_SAVE_LEN, 0x0c00	# F3DEX 共通
	
/*---------------------------------------------------------------------------*
 *	Sprite 構造体
 *---------------------------------------------------------------------------*/
	.symbol	RSP_SPR_OBJXY,		0
	.symbol	RSP_SPR_OBJX,		0
	.symbol	RSP_SPR_SCALEX,		2
	.symbol	RSP_SPR_IMGW,		4
	.symbol	RSP_SPR_PADDINGX,	6
	.symbol	RSP_SPR_OBJY,		8
	.symbol	RSP_SPR_SCALEY,		10
	.symbol	RSP_SPR_IMGH,		12
	.symbol	RSP_SPR_PADDINGY,	14
	.symbol	RSP_SPR_IMGSTR,		16
	.symbol	RSP_SPR_IMGADRS,	18
	.symbol	RSP_SPR_IMGFMT,		20
	.symbol	RSP_SPR_IMGSIZ,		21
	.symbol	RSP_SPR_IMGPAL,		22
	.symbol	RSP_SPR_IMGFLAGS,	23
	
/*---------------------------------------------------------------------------*
 *	Texture 構造体
 *---------------------------------------------------------------------------*/
	.symbol	RSP_TXT_TYPE,		0
	.symbol	RSP_TXT_TYPE_LINE,	1
	.symbol	RSP_TXT_TYPE_FMT,	2
	.symbol	RSP_TXT_TYPE_HEAD,	3
	.symbol	RSP_TXT_IMAGE,		4
	.symbol	RSP_TXT_TMEM,		8
	.symbol	RSP_TXT_TSIZE,		10
	.symbol	RSP_TXT_TSTRIDE,	12
	.symbol	RSP_TXT_PADDING2,	14
	.symbol	RSP_TXT_SID,		15
	.symbol	RSP_TXT_FLAG,		16
	.symbol	RSP_TXT_MASK,		20
	
/*---------------------------------------------------------------------------*
 *	Bg 構造体
 *---------------------------------------------------------------------------*/
	.symbol	RSP_BG_IMAGEX,		0	# imageX
	.symbol	RSP_BG_IMAGEW,		2	# imageW
	.symbol	RSP_BG_FRAMEX,		4	# frameX
	.symbol	RSP_BG_FRAMEW,		6	# frameW

	.symbol	RSP_BG_IMAGEY,		8	# imageY
	.symbol	RSP_BG_IMAGEH,		10	# imageH
	.symbol	RSP_BG_FRAMEY,		12	# frameY
	.symbol	RSP_BG_FRAMEH,		14	# frameH

	.symbol	RSP_BG_IMAGEPTR,	16	# imagePtr
	.symbol	RSP_BG_IMAGELOAD_MASK,	20	# imageLoad
	.symbol	RSP_BG_IMAGELOAD_HEAD,	21	# imageLoad
	.symbol	RSP_BG_IMAGEFMT,	22	# imageFmt 
	.symbol	RSP_BG_IMAGESIZ,	23	# imageSiz
	.symbol	RSP_BG_IMAGEPAL,	25	# imagePal
	.symbol	RSP_BG_IMAGEFLIP,	27	# imagePal
	.symbol	RSP_BG_TMEMW,		28	# tmemW
	.symbol	RSP_BG_TMEMH,		30	# tmemH
	.symbol	RSP_BG_TMEMLOADSH,	32	# tmemLoadSH
	.symbol	RSP_BG_TMEMLOADTH,	34	# tmemLoadTH
	.symbol	RSP_BG_TMEMSIZEW,	36	# tmemSizeW
	.symbol	RSP_BG_TMEMSIZE,	38	# tmemSize

	.symbol	RSP_SBG_SCALEW,		28	# scaleW
	.symbol	RSP_SBG_SCALEH,		30	# scaleH
	.symbol	RSP_SBG_IMAGEYORIG,	32	# imageYorig
	.symbol	RSP_SBG_PADDING,	36	# padding

/*---------------------------------------------------------------------------*
 *	Task 構造体領域
 *	
 *	OSTask のデータが CPU から渡される
 *---------------------------------------------------------------------------*/
	.symbol  RSP_TASK_OFFSET,	0x1000-OS_TASK_SIZE
	.symbol  GTASK_TYPE,		RSP_TASK_OFFSET+OS_TASK_OFF_TYPE
	.symbol  GTASK_FLAGS,		RSP_TASK_OFFSET+OS_TASK_OFF_FLAGS
	.symbol  GTASK_UCODE,		RSP_TASK_OFFSET+OS_TASK_OFF_UCODE
	.symbol  GTASK_OUTBUFF,		RSP_TASK_OFFSET+OS_TASK_OFF_OUTBUFF
	.symbol  GTASK_OUTBUFF_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_OUTBUFF_SZ
	.symbol  GTASK_DATA,		RSP_TASK_OFFSET+OS_TASK_OFF_DATA
	.symbol  GTASK_DATA_SZ,		RSP_TASK_OFFSET+OS_TASK_OFF_DATA_SZ
	.symbol  GTASK_YIELD,		RSP_TASK_OFFSET+OS_TASK_OFF_YIELD
	.symbol  GTASK_YIELD_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_YIELD_SZ
	
	.symbol  ASSERT_WORKAREA,	RSP_TASK_OFFSET-0x20
	.symbol  ASSERT_SAVE_INP,	ASSERT_WORKAREA+0x00
	.symbol  ASSERT_SAVE_GFX0,	ASSERT_WORKAREA+0x04
	.symbol  ASSERT_SAVE_PC,	ASSERT_WORKAREA+0x08
	.symbol  ASSERT_DEBUG0,		ASSERT_WORKAREA+0x0c
	.symbol  ASSERT_DEBUG1,		ASSERT_WORKAREA+0x10
	.symbol  ASSERT_DEBUG2,		ASSERT_WORKAREA+0x14
	.symbol  ASSERT_DEBUG3,		ASSERT_WORKAREA+0x18
	.symbol  ASSERT_DEBUG4,		ASSERT_WORKAREA+0x1c
	.symbol  ASSERT_LOG_PTR,	GTASK_DATA_SZ

/*======== End of gs2dmem.h ========*/
