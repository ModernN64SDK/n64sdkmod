
/**************************************************************************
 *                                                                        *
 *               Copyright (C) 1994, Silicon Graphics, Inc.               *
 *                                                                        *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright  law.  They  may not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 *                                                                        *
 *************************************************************************/

 #
 # gdmem.h
 #
 # This file lays out the DMEM usage for the RSP gspFast3D tasks
 # and the gspLine3D tasks.
 #

#include <rcp.h>
#include <os.h>
#include <sptask.h>

 #
 # IMPORTANT NOTE:
 #
 # Many of the following fields require some alignment, for the ld/st to
 # work as efficiently as possible... Add this someday...
 #
 #


/*
 * Memory layout of DMEM:
 *
 * The strategy is to divide up DMEM into a bunch of known regions
 * that we can get to quickly to store/retrieve stuff.
 *
 * The order of things here is kind of important. Things that need
 * to be initialized via DMA should be near the top. Some buffers
 * require 64-bit alignment.
 *
 *      -------------------------------------------------
 *      | Program data from compiler...                 |     (must be first)
 *	|     overlays, constants, etc.  272 bytes      |
 *	|-----------------------------------------------|
 *	| RSP GFX State                                 |
 *	|                                 80 bytes      |
 *      |-----------------------------------------------|
 *	| RSP memory segment table:                     |
 *      |      16 x 4b = 		 64 bytes       |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Lights                                        |
 *	|                               384 bytes       |
 *	|-----------------------------------------------|
 *	| Viewport:			                |
 *	|                                16 bytes       |
 *	|-----------------------------------------------|
 *	| Fog factors:		                        |
 *	|                                 6 bytes       |
 *	|-----------------------------------------------|
 *	| padding		                        |
 *	|                                 2 bytes       |
 *	|-----------------------------------------------|
 *	| Display list stack:  10 deep	 40 bytes       |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Modelview Matrix top of stack:                | 64-bit aligned
 *	|      4x4 x 4b                                 |
 *	|              			 64 bytes       |
 *	|-----------------------------------------------|
 *	| Projection Matrix top of stack:               | 64-bit aligned
 *	|      4x4 x 4b                                 |
 *	|              			 64 bytes       |
 *	|-----------------------------------------------|
 *	| MP matrix: (Modelview * Projection)           |
 *	|      4x4 x 4b (doubled for vector register)   |
 *	|              			 64 bytes       |
 *	|-----------------------------------------------|
 *	| Points buffer:                640 bytes       |
 *	|                                               |
 *	| 16 points, @ 40 bytes                         |
 *	| (includes clip coords, screen, etc.)          |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Input (display list)		320 bytes       | 64-bit aligned
 *      |    40 cmds, @ 8bytes				|
 *	|-----------------------------------------------|
 *	| Input (data)				        | 64-bit aligned
 *	|    				256 bytes       |
 *	| (needs to be big enough to hold 16 pts, etc.) |
 *	|-----------------------------------------------|
 *	| setup tmp			 96 bytes       |
 *	|-----------------------------------------------|
 *	| clip tmp			160 bytes       |
 *	|-----------------------------------------------|
 *	| Output to RDP:	       			| 64-bit aligned
 *	|    6 nasty triangles x 160b+                  |
 *	|    (cycle memory)            1024 bytes	|
 *	|-----------------------------------------------|
 *	| Scratch space for intermediate results        |
 *	| Holds clipped vertices during clip and setup. |
 *	|                                               |
 *	|                               480 bytes       |
 *      -------------------------------------------------
 * 
 */

/*
 * Memory addressing Strategy:
 *
 * All dmem will be addressed relative to register zero which is 
 * equivalent to the top of dmem.
 * Memory is allocated in this file by adding bytes, halfs, words, etc.
 * If alignment is required attempt to align by hand and use a 
 *      .bound <byte_alignment>
 * where <byte_alignment> is the number of bytes to align to.  This will
 * supply an error message when alignment is incorrect.  To force alignment use
 *      .align <byte_alignment>
 * which will force alignment by adding pad bytes.
 * An error will occur if dmem is overflowed.
 *
 */

     .data

 #################################################################
 ############## BEGIN INITIALIZING AND DEFINING DMEM USE #########
 #################################################################

	.print	"----------------------------------------------------------\n"
RSP_PDATA_OFFSET:

 #################################################################
 ############## OVERLAY TABLE ####################################
 #################################################################
 #
 # Program module overlay table. Offsets and sizes are filled in by
 # the 'buildtask' utility, destinations are the responsibility of
 # the ucode.
 #
 # OVERLAY_OFFSET:  offset from beginning of microcode in RDRAM and
 #		      in .o file (filled in by buildtask).
 # OVERLAY_SIZE:    length of overlay in bytes (filled in by buildtask).
 # OVERLAY_DEST:    where in IMEM to put the overlay (filled in by 
 #                    microcode).
 #
 # The overlay table must be the first thing in DMEM.
 # The 1st overlay must be the initial code.
 #
	.bound	0x80000000

OVERLAY_TAB_OFFSET:

#define OVERLAY_OFFSET  0
#define OVERLAY_SIZE    4
#define OVERLAY_DEST    6

 #==========================================
 #============= MAIN CODE OVERLAY ==========
 #==========================================
OVERLAY_0_OFFSET:
    # main module.
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   0x04001080      # destination

 #==========================================
 #============= NEWTONS OVERLAY ============
 #==========================================
OVERLAY_1_OFFSET:
OVERLAY_NEWTON:
    # Newton's module laid over boot code.
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   0x04001000      # destination

 #==========================================
 #============= CLIPPING OVERLAY ===========
 #==========================================
#if defined(FASTLIGHT3D)||defined(CLIP_ALONE)||defined(FLIGHT)
#else
#define startClip 0		# bogus startClip if not using overlays
#endif

OVERLAY_2_OFFSET:
OVERLAY_CLIP:
    # clip code
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   startClip       # destination

 #==========================================
 #============= LIGHTING OVERLAY ===========
 #==========================================
OVERLAY_3_OFFSET:
OVERLAY_LIGHT:
    # light code
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   startClip       # destination

 #==========================================
 #============= DONE OVERLAY ===============
 #==========================================
OVERLAY_4_OFFSET:
OVERLAY_DONE:
    # TaskDone and Yield code
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
TASKYIELD:
        .half   startClip       # destination

 ### ADD NEW OVERLAY TABLE ENTRIES HERE

 #
 #
 ############## END OF OVERLAY TABLE ##############################

 #################################################################
 ############## QUAD CONSTANTS ###################################
 #################################################################
 #
 # Constants. Setup a bunch of constants at compile-time. Be
 # sure to #define the macros and offsets needed to access them.
 #
 #################################################################
 #
 #
 # Initialize vconst; each element a different scalar constant...
 #

	.bound	8
VCONST_SCREENCLAMP:
	.half	4090		# +xy clamp to +1000 (*4)
	.half	-4090		# -xy clamp to -1000 (*4)

	.half	0x7fff		# +z clamp max
	.half	0x0000		# -z clamp to 0

	.align	16
	.bound	16

VCONST_OFFSET:
        .half   0x0000          # 0
        .half   0x0001          # 1
        .half   0x0002          # 2
        .half   0xffff          # -1
        .half   0x4000          # 1/4.0 in fixed-point fraction
        .half   0x0004          # 4.0, for screen point scaling.
        .half   0x0633          # (2047-4e0) for screen-space clamping.
        .half   0x0200          # 1/512.0 for pixel-packed loads
 #
 # Initialize vconst; each element a different scalar constant...
 #
#ifdef LINE3D
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
        .half   0x0010          #
        .half   0x0020          # for z scale
        .half   0x8000          #
        .half   0x0755		# 1877=(2048-640)/0.75 for slope clamp
        .half   0x0000          # not used
#endif /* LINE3D */

#ifdef FAST3D
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
 #	.half   0x00fd          # 1/128 * 0.990 *.5 (sqrt correction) (.5 for sf
	.half   0x0040          # 1/128 * .5 * .25 (sqrt correct) (.5 for sf
        .half   0x0020          # for z scale
#ifdef	F3DLP_GBI
        .half   0xfffc          # round screen position to integer *** YASU ***
#else
        .half   0x8000		# test bow-tie fix
#endif
	.half	0x01cc		# 460 = 2048/3 for slope clamp
				# WARNING: used in lighting.  Tell Acorn if this
				# value becomes >0x200 or <0x100.

        .half   0xcccc          # W multiplier(0.8). 1/w ranges from 0 to 0.8 
#endif /* FAST3D */

#ifdef SPRITE2D
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
 #	.half   0x00fd          # 1/128 * 0.990 *.5 (sqrt correction) (.5 for sf
	.half   0x0040          # 1/128 * .5 * .25 (sqrt correct) (.5 for sf
        .half   0x0020          # for z scale
#ifdef	F3DLP_GBI
        .half   0xfffc          # round screen position to integer *** YASU ***
#else
        .half   0x8000          # test bow-tie fix
#endif
	.half	0x01cc		# 460 = 2048/3 for slope clamp
				# WARNING: used in lighting.  Tell Acorn if this
				# value becomes >0x200 or <0x100.

        .half   0xcccc          # W multiplier(0.8). 1/w ranges from 0 to 0.8 
#endif /* FAST3D */



 #
 # Initialize OpenGL correction scale
 #
VOPENGL_OFFSET:
        .half   0x0001          # x
        .half   0xffff          # y
        .half   0x0001          # z
        .half   0x0001          # w
        .half   0x0001          # x
        .half   0xffff          # y
        .half   0x0001          # z
        .half   0x0001          # w

 #
 # Initialize constant vector for Newton's iteration
 #
#ifndef NONEWTONTBL
VNEWT_OFFSET:
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # MUST BE 2 !
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # MUST BE 2 !
#endif
 #
 #
 ############## END OF CONSTANTS ##################################

 #################################################################
 ############## CLIPPING & LIGHTING ##############################
 #################################################################
 #
 # static tables and masks for clipping & lighting
 #
 #################################################################
 #
	.bound	16
CLIP_SELECT:				# NOTE: MOVEWORD command alters these
        .word   0x00010000              # -x plane (1 0 0  1)
#ifdef	F3DLP_GBI
        .word   0x00000002              # Reject box factor
#else
        .word   0x00000001              # -x
#endif
        .word   0x00000001              # -y plane (0 1 0  1)
        .word   0x00000001              # -y
        .word   0x00010000              # +x plane (1 0 0 -1)
        .word   0x0000ffff              # +x
        .word   0x00000001              # +y plane (0 1 0 -1)
        .word   0x0000ffff              # +y
        .word   0x00000000              # +z plane (0 0 1 -1)
        .word   0x0001ffff              # +z
        .word   0x00000000              # -z plane (0 0 1  1)
#ifdef NEAR_CLIP_OFF
        .word   0x00000001              # -z   if NEARCLIP_OFF: (0 0 0 1)
#else /* NEAR_CLIP_OFF */
        .word   0x00010001              # -z   if NEARCLIP_OFF: (0 0 0 1)
#endif /* NEAR_CLIP_OFF */

	.bound	8
#if defined(FASTLIGHT3D)||defined(CLIP_ALONE)||defined(FLIGHT)
DOLIGHT:
        .half   doLight
#else /* FASTLIGHT3D or CLIP_ALONE */
DOLIGHT:
        .half   0               # pad
#endif /* FASTLIGHT3D or CLIP_ALONE */
        .half   0x7fff          # 1-.0x0001
        .half   0x571d          # 0x571d for arccos
        .half   0x3a0c          # 0x3a0b+.0x0001 for arccos

	.bound 2
CLIP_MASKS_TABLE:
CLIPMASKS:
#ifdef	F3DLP_GBI
	.bound 8
REJECT_RATIO:
        .half   0x0002		# X
        .half   0x0002		# Y
        .half   0x0001		# Z
        .half   0x0000		# Pad
REJECT_FLAG:
        .half   0x7fff		# Reject (0x7fff)
        .half   0x8000		# Accept (0x8000)
#else
        .half   0x0001			# -x plane
        .half   0x0002			# -y plane
        .half   0x0100			# +x plane
        .half   0x0200			# +y plane
        .half   0x4000			# +z plane
        .half   0x0040			# -z plane (not always used)
#endif
ANCHOR:
        .half   0x0000
TASKDONE:
#if defined(FASTLIGHT3D)||defined(CLIP_ALONE)||defined(FLIGHT)
	.half	taskDone
#else /* FASTLIGHT3D or CLIP_ALONE */
	.half	0		# pad
#endif /* FASTLIGHT3D or CLIP_ALONE */

 #
 #
 ############## END OF CLIPPING & LIGHTING ########################

 #################################################################
 ############## SCALAR CONSTANTS #################################
 #################################################################
 #
 # Constants. Setup a bunch of constants at compile-time. Be
 # sure to #define the macros and offsets needed to access them.
 #
 #################################################################
 #

 #
 # a common necessary mask value
 #

  	.bound	4
#if 0
SEGADDR_MASK_OFFSET:
          .word   0x00ffffff      # segment address mask.
#endif
 #
 #
 ############## END OF SCALAR CONSTANTS ##########################

 #################################################################
 ############## JUMP TABLES ######################################
 #################################################################
 #
 # Jump Tables: These DMEM jump tables are only 16 bits, that's
 # plenty, given only 4K of IMEM...
 #
 # Jump tables should be 'complete', any new command in the
 # mbi should be included here, even if it's a jump to GfxDone
 # in some cases (a no-op).
 #
 # Notice also that a bunch of #ifdef's are used to disable
 # certain commands for certain versions of the microcode.
 # Patching the 'GfxDone' label into the table makes a command
 # be a no-op.
 #
 #################################################################
 #

 #====================================================================
 # setup a jump table for the optypes:
 # This table is the high-level handler for the display list commands.
 # Based on the upper 2 bits, each different type of command is handled
 # differently.
 #====================================================================
	.bound	2

OPTYPE_JMP_OFFSET:
        .half   doDMA
GFXDONE:
        .half   GfxDone         # dummy label, invalid op type
        .half   doIMM
        .half   doRDP

 #====================================================================
 # setup a jump table for the DMA ops:
 #====================================================================
DMA_JMP_OFFSET:
        .half   GfxDone         # all 0's is G_SPNOOP
        .half   case_G_MTX
        .half   GfxDone         # case_G_MTX_STATE not implemented
        .half   case_G_MOVEMEM  # viewport and light
        .half   case_G_VTX
        .half   GfxDone         # case_G_TRIN not implemented
        .half   case_G_DL
        .half   GfxDone         # not implemented
        .half   GfxDone         # not implemented
#ifdef SPRITE2D
        .half   case_G_SPRITE
#elif	(defined(RSP_PAUSE))
	.half   case_G_RSP_PAUSE
#else
	.half   GfxDone
#endif

 #====================================================================
 # setup a jump table for the IMM ops:
 # IMPORTANT: ADD NEW OPCODES AT TOP OF THIS TABLE
 #====================================================================
IMM_JMP_OFFSET:
#if	(defined(F3DLP_GBI)||defined(F3DEX_GBI))
#ifdef	SWITCH_UCODE
        .half	case_G_SWITCH_UCODE
#else
        .half	GfxDone
#endif
#ifdef	BRANCH_Z
        .half	case_G_BRANCH_Z
#else
        .half	GfxDone
#endif
#endif
#if	(defined(F3DLP_GBI)||defined(F3DEX_GBI))
        .half   case_G_TRI2
        .half   case_G_MODIFYVTX
#else
        .half   GfxDone
        .half   case_G_RDPHALF_CONT
#endif
        .half   case_G_RDPHALF_2
        .half   case_G_RDPHALF_1
#ifdef LINE3D
        .half   case_G_LINE3D
#endif
#ifdef FAST3D
#ifdef	TXLOAD4b
	.half	case_G_TXTRBLK_4b_1
#else
        .half   GfxDone              # Lines not grokked in triangle code
#endif
#endif
#ifdef SPRITE2D
        .half   GfxDone              # Lines not grokked in triangle code
#endif

        .half   case_G_CLEARGEOMETRYMODE
        .half   case_G_SETGEOMETRYMODE
        .half   case_G_ENDDL
        .half   case_G_SETOTHERMODE_L
        .half   case_G_SETOTHERMODE_H
        .half   case_G_TEXTURE
        .half   case_G_MOVEWORD
        .half   case_G_POPMTX
#ifdef	TXLOAD4b
	.half	case_G_TXTRBLK_4b_2
#else
        # LP では CullDL をサポートしなかったが Rej になってサポート開始
        .half   case_G_CULLDL
#endif
#ifdef LINE3D
        .half   case_G_TRI1   # Tri's grokked differently in line microcoode
#endif
#ifdef FAST3D
        .half   case_G_TRI1
#endif
#ifdef SPRITE2D
	.half   GfxDone
#endif

 # ADD NEW IMM OPCODES ONLY AT TOP OF LIST, NOT HERE

	.symbol NUMBER_OF_IMM,  17
	.symbol IMM_JMP_ADD,    (IMM_JMP_OFFSET)+(((G_IMMFIRST)+(NUMBER_OF_IMM)+1)*2)

 #====================================================================
 # no jump table for the RDP ops is needed.
 #====================================================================

 #
 #
 ############## END OF JUMP TABLES ################################

 #################################################################
 ############## LABEL CONSTANTS ##################################
 #################################################################
 #
 # Labels for loading jump addresses
 #
 #################################################################
 #

	.bound 2

 #==========================================
 #============= DUMMY LABELS ===============
 #==========================================
#ifdef NODATA
CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0

CLIPDRAWLOOP:
        .half   0
DOCLIP:
        .half   0
NEXTCLIP:
        .half   0
#else /* NODATA */

#ifdef LINE3D
CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0

CLIPDRAWLOOP:
        .half   0

DOCLIP:
        .half   doClip
NEXTCLIP:
        .half   nextClip
#endif  /* LINE3D */

#ifdef FAST3D

 #==========================================
 #============= REAL LABELS ================
 #==========================================
CLIP_STATE_TABLE:
        .half   foundIn
FOUND_OUT:
        .half   foundOut
        .half   foundFirstIn
        .half   foundFirstOut

CLIPDRAWLOOP:
        .half   clipDrawLoop
DOCLIP:
        .half   doClip
NEXTCLIP:
        .half   nextClip
#endif  /* FAST3D */

#ifdef SPRITE2D
CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0

CLIPDRAWLOOP:
        .half   0

DOCLIP:
        .half   0
NEXTCLIP:
        .half   0
#endif  /* SPRITE2D */

#endif /* NODATA */

DMAWAITDL:
	.half	DMAWaitDL

 #
 #
 ############## END OF LABELS #####################################

PROGRAM_PAD_OFFSET:

 ######################################################################
 ############## DMEM STATE ############################################
 ######################################################################
 #
 # Up to this point, we have been just filling in compile-time
 # structures. The rest of this initialization sets up the DMEM
 # state for the beginning of the graphics task.
 #
 # Alignment is important, changes above might screw up initialization
 # in a bad way...
 #
 ######################################################################
 #
 #
 # initialize RSP GFX state.
 #
	.bound	2
RETURNJUMP:
        .half   0x0000

	.bound	4
RSP_STATEP_YIELD_STORE:
	.word	0x0			# where to store yield dmem

	.bound	4
RSP_STATEP_RDPHALF:
        .word   0x0			# RSP_STATE_RDPHALF

	.align	8
	.bound	8
RSP_STATE_OFFSET:

	.bound	4
#if	(defined(F3DEX_GBI)||defined(F3DLP_GBI))
RSP_STATEP_PERSPNORM_H:
        .half   0x0000			# PERSPNORM tophalf (always 0)
RSP_STATEP_PERSPNORM:
        .half   0xffff                  # RSP_STATE_PERSPNORM
#else
RSP_STATEP_DL_N:
        .byte   0x0                     # RSP_STATE_DL_N
	.align	2
	.bound	2
RSP_STATEP_PERSPNORM:
        .half   0xffff                  # RSP_STATE_PERSPNORM
#endif
	.align	4
	.bound	4
RSP_STATEP_RENDER:
#ifdef	CLIPSWITCH
        .half   G_CLIPPING_H            # RSP_STATE_RENDER
#else
        .half   0x0 	                # RSP_STATE_RENDER
#endif
RSP_STATEP_RENDER_L:
        .byte   0x0                     # RSP_STATE_RENDER
RSP_STATEP_TRI:
        .byte   0x0                     # RSP_STATE_RENDER

	.bound	8
RSP_STATEP_OTHER_H:
        .byte   G_RDPSETOTHERMODE       # RSP_STATE_OTHER_H
        .byte   0x08                    # RSP_STATE_OTHER_H
        .byte   0x0c                    # RSP_STATE_OTHER_H
        .byte   0xff			# blend mask is fixed
RSP_STATEP_OTHER_L:
        .word   0x0                     # RSP_STATE_OTHER_L

        .bound  8
RSP_STATEP_TEX_CMD:
        .byte   0x0			# RSP_STATE_TEX_CMD
RSP_STATEP_TEX_LOD:
        .byte   0x0			# RSP_STATE_TEX_LOD
RSP_STATEP_TEX_TILE:
        .byte   0x0                     # RSP_STATE_TEX_TILE
RSP_STATEP_TEX_PAD:
        .byte   0x0
RSP_STATEP_TEX_SCALE_S:
        .half   0x0                     # RSP_STATE_TEX_SCALE_S
RSP_STATEP_TEX_SCALE_T:
        .half   0x0                     # RSP_STATE_TEX_SCALE_T

	.bound	4
RSP_STATEP_FIFO_OUTP:
RSP_STATEP_DRAM_OUTP:
        .word   0x0                     # RSP_STATE_DRAM_OUTP

RSP_STATEP_L_LEN:			# altered by MOVEWORD command
        .word   0x80000040              # # lights * RSP_L_LEN (1 light default)

	.bound	4
RSP_STATEP_DRAM_STACK:
        .word   0x0                     # RSP_STATE_DRAM_STACK

	.bound	4
RSP_STATEP_MMTX_STACK_P:
        .word   0x0                     # RSP_STATE_MMTX_STACK_P

RSP_STATEP_TXTR_ATTR:				# Texture Attributes
RSP_STATEP_XOFF:
	.half	0x4000			# x offset
RSP_STATEP_YOFF:
	.half	0x4000			# y offset
RSP_STATEP_HCURVE:
	.half	0			# horizontal curve
RSP_STATEP_VCURVE:
	.half	0			# vertical curve
	.bound	16			# MUST BE LAST 4 half'S OF QUAD


        .bound 8
RSP_STATEP_DRAM_OUT_LENP:		# RSP_STATE_DRAM_OUT_LENP
        .word   0x0

#ifdef LINE3D
	.bound	4
RSP_STATEP_SCISSOR_XH:
	.half   0x0000			# RSP_STATE_SCISSOR_XH
RSP_STATEP_SCISSOR_YH:		
	.half   0x0000  	        # RSP_STATE_SCISSOR_YH
RSP_STATEP_SCISSOR_XL:	
	.half   0x0000  	        # RSP_STATE_SCISSOR_XL
RSP_STATEP_SCISSOR_YL:	
	.half   0x0000	              	# RSP_STATE_SCISSOR_YL
#endif /* LINE3D */

#ifdef FAST3D
#ifdef	F3DLP_GBI
RSP_STATEP_VPTR_COEFF:
	.half	RSP_POINTS_SIZE		# value
	.half	RSP_POINTS_OFFSET_RV	# offset
#else
	.half	0x0000			# pad
	.half	0x0000			# pad
#endif
RSP_STATEP_DL_N:
        .byte   0x0                     # RSP_STATE_DL_N
	.byte	0x0			# pad
	.half	0x0000			# pad
#endif

#ifdef SPRITE2D
	.half	0x0000			# pad
	.half	0x0000			# pad
	.half	0x0000			# pad
	.half	0x0000			# pad
#endif


        .align 8
        .bound 8
RSP_STATEP_FIFO_BUF_TOP:
RSP_STATEP_DRAM_OUT_LEN:
        .word   0x0                     # RSP_STATE_DRAM_OUT_LEN
RSP_STATEP_FIFO_BUF_END:
        .word   0x0                     # is a 64-bit counter

	.bound	2
RETURNJUMP2:
        .half   0x0000
#ifdef	DMA2BUF
RSP_STATEP_FIFO_DMA2BUF:
        .half	RSP_OUTPUT_OFFSET
#else
#ifdef	LINE3D
RSP_STATEP_DL_N:
        .byte   0x0                     # RSP_STATE_DL_N
	.byte	0x0			# pad
#endif
#endif
	.align	4
	.bound	4
RSP_STATEP_MMTX_STACK_MAX:
        .word   0x0                     # RSP_STATE_MMTX_STACK_MAX


    
    .symbol RSP_STATE_YIELD_STORE,    (RSP_STATEP_YIELD_STORE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DL_N, 	      (RSP_STATEP_DL_N)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_OTHER_H, 	      (RSP_STATEP_OTHER_H)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_OTHER_L, 	      (RSP_STATEP_OTHER_L)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_RENDER, 	      (RSP_STATEP_RENDER)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_RENDER_L,       (RSP_STATEP_RENDER_L)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TRI, 	      (RSP_STATEP_TRI)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_STACK,     (RSP_STATEP_DRAM_STACK)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_MMTX_STACK_P,   (RSP_STATEP_MMTX_STACK_P)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_MMTX_STACK_MAX, (RSP_STATEP_MMTX_STACK_MAX)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_CMD, 	      (RSP_STATEP_TEX_CMD)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_LOD, 	      (RSP_STATEP_TEX_LOD)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_TILE,       (RSP_STATEP_TEX_TILE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_SCALE_S,    (RSP_STATEP_TEX_SCALE_S)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_SCALE_T,    (RSP_STATEP_TEX_SCALE_T)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_FIFO_OUTP,      (RSP_STATEP_FIFO_OUTP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_FIFO_BUF_TOP,   (RSP_STATEP_FIFO_BUF_TOP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_FIFO_BUF_END,   (RSP_STATEP_FIFO_BUF_END)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_OUTP,      (RSP_STATEP_DRAM_OUTP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_OUT_LEN,   (RSP_STATEP_DRAM_OUT_LEN)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_OUT_LENP,  (RSP_STATEP_DRAM_OUT_LENP)-(RSP_STATE_OFFSET)
#ifdef	DMA2BUF
    .symbol RSP_STATE_FIFO_DMA2BUF,   (RSP_STATEP_FIFO_DMA2BUF)-(RSP_STATE_OFFSET)
#endif
    .symbol RSP_STATE_L_LEN, 	      (RSP_STATEP_L_LEN)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_PERSPNORM,      (RSP_STATEP_PERSPNORM)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_RDPHALF,	      (RSP_STATEP_RDPHALF)-(RSP_STATE_OFFSET)
#ifdef LINE3D
    .symbol RSP_STATE_SCISSOR_XH,     (RSP_STATEP_SCISSOR_XH)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_SCISSOR_XL,     (RSP_STATEP_SCISSOR_XL)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_SCISSOR_YH,     (RSP_STATEP_SCISSOR_YH)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_SCISSOR_YL,     (RSP_STATEP_SCISSOR_YL)-(RSP_STATE_OFFSET)
#endif /* LINE3D */
#ifdef	F3DLP_GBI
    .symbol RSP_STATE_VPTR_COEFF,     (RSP_STATEP_VPTR_COEFF)-(RSP_STATE_OFFSET)
#endif
    .symbol RSP_STATE_HCURVE,	      (RSP_STATEP_HCURVE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_VCURVE,	      (RSP_STATEP_VCURVE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_XOFF,	      (RSP_STATEP_XOFF)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_YOFF,	      (RSP_STATEP_YOFF)-(RSP_STATE_OFFSET)

 #
 #
 ############## END OF RSP STATE ##################################


 ##################################################################
 ############## MEMORY SEGMENT TABLE ##############################
 ##################################################################
 #
 # initialize memory segment table.
 # altered by MOVEWORD command
 #
	.align	4
	.bound	4
RSP_SEG_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
#ifndef	LESSSEGMENT
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
#endif
 #
 #
 ############## END OF MEMORY SEGMENT TABLE #######################

 ##################################################################
 ############## REFLECTANCE TABLE #################################
 ##################################################################
 #
 #
 # define offsets for the light structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |S.x|S.y|S.z|000|S.x|S.y|S.z|000|000|000|000|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |T.x|T.y|T.z|000|T.x|T.y|T.z|000|TVx|TVy|TVz|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |TMx|TMy|TMz|000|TMx|TMy|TMz|000|000|000|000|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |D.x|D.y|D.z|000|D.x|D.y|D.z|000|SVx|SVy|SVz|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |SMx|SMy|SMz|000|SMx|SMy|SMz|000|000|000|000|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #
 # S.xyz = S select vector (always 0x80000000 = [-1  0 0])
 # T.xyz = T select vector (always 0x00800000 = [ 0 -1 0])
 # TVxyz = T direction in Viewspace (Up vector)
 # TMxyz = T direction in Modelspace (calculated by microcode)
 # SVxyz = S direction in Viewspace (Right vector)
 # SMxyz = S direction in Modelspace (calculated by microcode)
 # D.xyz = Dummy color (must always be 0x00000000 = [0 0 0])
 # 
 #
#define RSP_R_SCALE     0
#define RSP_R_DIR_VIEW  8
#define RSP_R_PAD       12
#define RSP_R_DIR       16


	.align	16
	.bound	16	/* must be quad aligned */
RSP_LIGHTS_OFFSET:
RSP_SELECT_S:
        .word   0x80000000      # S select vector
        .word   0x80000000      # S select vector
        .word   0x0             # pad
        .word   0x0             # pad

RSP_R_LOOKATX:
        .word   0x00800000      # T select vector
        .word   0x00800000      # T select vector copy
        .word   0x7f000000      # reflectance direction (world) T (x)
        .word   0x0             # pad
        .word   0x0             # reflectance direction (modeling) T
        .word   0x0             # reflectance direction copy
        .word   0x0             # pad
        .word   0x0             # pad

RSP_R_LOOKATY:
        .word   0x00000000      # dummy color (must be 0)
        .word   0x00000000      # dummy color (must be 0)
        .word   0x007f0000      # reflectance direction (world) S (y)
        .word   0x0             # pad
        .word   0x0             # reflectance direction (modeling) S
        .word   0x0             # reflectance direction copy
        .word   0x0             # pad
        .word   0x0             # pad
 #
 #
 ############## END OF REFLECTANCE TABLE ##########################

 ### NOTE: DO NOT PUT ANYTHING BETWEEN THE REFLECTANCE AND LIGHT TABLES

 ##################################################################
 ############## LIGHTING TABLE ####################################
 ##################################################################
 #
 # IMPORTANT!!! THIS MUST IMMEDIATELY FOLLOW THE REFLECTANCE TABLE!!!
 #
 # define offsets for the light structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |c.r|c.g|c.b|   |c.r|c.g|c.b|   |w.x|w.y|w.z|   |   |   |   |   |
 #  ----------------------------------------------------------------|
 #  |m.x|m.y|m.z|   |m.x|m.y|m.z|   |   |   |   |   |   |   |   |   |
 #  ----------------------------------------------------------------|
 #
 # c.r   light color, red componant    (supplied vi MOVEMEM command)
 # c.g   light color, green componant  (supplied vi MOVEMEM command)
 # c.b   light color, blue componant   (supplied vi MOVEMEM command)
 # w.x   light direction, world coords (supplied vi MOVEMEM command)
 # w.y   light direction, world coords (supplied vi MOVEMEM command)
 # w.z   light direction, world coords (supplied vi MOVEMEM command)
 # m.x   light direction, model coords (calculated by the microcode)
 # m.y   light direction, model coords (calculated by the microcode)
 # m.z   light direction, model coords (calculated by the microcode)
 # blank pad, don't care (can be any value)
 # 
 # There are 2 copies of the light color and 2 copies of the modeling
 # coordinate light direction.
 #
 # light direction is a vector pointing from the object towards the light.
 #
 # NOTE: the last light in the table is the ambient light of which only c.r,
 #       c.g, and c.b are used.
 #
 #
#define RSP_L_COL       0
#define RSP_L_DIR_VIEW  8
#define RSP_L_PAD       12
#define RSP_L_DIR       16
#define RSP_L_LEN       32

	.bound	16	/* must be quad aligned. */
RSP_L_0:
RSP_LIGHT_COL:
        .word   0x0             # light #1 color (black)
        .word   0x0             # light #1 color copy
        .word   0x0             # light #1 direction (world)
        .word   0x0             # pad
        .word   0x0             # light #1 direction (modeling)
        .word   0x0             # light #1 direction copy
 #	.word   0x0             # pad
 #	.word   0x0             # pad

VCONST3_OFFSET:
	.half	0xe001		# min clamp for lighting direction
	.half	0x1fff		# max clamp for lighting direction
	.half	4		# multiplier after clamp
	.half	0		# pad

RSP_L_1:
        .word   0xFF000000      # ambient color (red)
        .word   0xFF000000      # ambient color copy
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0             # pad
        .word   0x0             # pad

/* NewCom 仕様としてライトの数を 8->4 にした分の空き 128 bytes を VTX Offset 
   テーブルへ回す */
#ifndef	NEWCOM
RSP_L_2:
        .word   0x0             # light #2 (uninitialized)
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0             # pad
        .word   0x0             # pad
RSP_L_3:
        .word   0x0             # light #3 (uninitialized)
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0             # pad
        .word   0x0             # pad
#endif

#if (defined(F3DEX_GBI)||defined(F3DLP_GBI))
# ifndef NEWCOM
RSP_L_4:      			# light #4 (initialized to magic values)
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
RSP_L_5:      			# light #5 (initialized to magic values)
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
        .word   0x00000000
RSP_L_6:             		# light #6 (initialized to magic values)
# else
RSP_L_2:
# endif
        .word   0x52535020	# "RSP "
        .word   0x47667820	# "Gfx "
        .word   0x75636f64	# "ucod"
        .half   0x6520		# "e "

# if	(defined(VER_NCOM))	/******* F3DNCom *******/
#  ifdef NEAR_CLIP_OFF
        .half   0x4633		# 
        .word   0x444e436f	# "F3DNCom.NoN/I "
        .word   0x6d2e4e6f	#
        .word   0x4e2f4920	#
#  elif (defined(F3DLP_GBI))
        .half   0x4633		# 
        .word   0x444e436f	# "F3DNCom.Rej/I "
        .word   0x6d2e5265	#
        .word   0x6a2f4920	#
#  else	/* NEAR_CLIP_OFF */
        .half   0x4633		# 
        .word   0x444e436f	# "F3DNCom/I     "
        .word   0x6d2f4920	#
        .word   0x20202020	#
#  endif /* NEAR_CLIP_OFF */

# elif	(defined(F3DLP_GBI))	/******* F3DL?.Rej *******/
#  ifdef PERSPTXTR
        .half   0x4633		# 
#ifndef DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
        .word   0x444c582e	# "F3DLX.Rej       "
        .word   0x52656a20	#
        .word   0x20202020	#
#else
        .word   0x44504c58	# "F3DPLX.Rej/D    "
        .word   0x2e52656a	#
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4c58	# "F3DZLX.Rej/E    "
        .word   0x2e52656a	#
        .word   0x2f452020	#
#endif
#  else
        .half   0x4633		# 
#ifndef DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
        .word   0x444c502e	# "F3DLP.Rej       "
        .word   0x52656a20	#
        .word   0x20202020	#
#else
        .word   0x44504c50	# "F3DPLP.Rej/D    "
        .word   0x2e52656a	#
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4c50	# "F3DZLP.Rej/E    "
        .word   0x2e52656a	#
        .word   0x2f452020	#
#endif
#  endif
# elif	(defined(NOSUBPIXEL))	/******* F3DLX *******/
#  ifdef NEAR_CLIP_OFF
        .half   0x4633		# 
#ifndef	DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
        .word   0x444c582e	# "F3DLX.NoN       "
        .word   0x4e6f4e20	#
        .word   0x20202020	#
#else
        .word   0x44504c58	# "F3DPLX.NoN/D    "
        .word   0x2e4e6f4e	#
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4c58	# "F3DZLX.NoN/E    "
        .word   0x2e4e6f4e	#
        .word   0x2f452020	#
#endif
#  else  /* NEAR_CLIP_OFF */
        .half   0x4633		# 
#ifndef	DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
        .word   0x444c5820	# "F3DLX           "
        .word   0x20202020	#
#else
        .word   0x44504c58	# "F3DPLX/D        "
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4c58	# "F3DZLX/E        "
        .word   0x2f452020	#
#endif
        .word   0x20202020	#
#  endif /* NEAR_CLIP_OFF */

# elif	(defined(LINE3D))	/******* L3DEX *******/
        .half   0x4c33		# 
#ifndef	DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
        .word   0x44455820	# "L3DEX           "
        .word   0x20202020	#
#else
        .word   0x44504558	# "L3DPEX/D        "
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4558	# "L3DZEX/E        "
        .word   0x2f452020	#
#endif
        .word   0x20202020	#
# else				/******* F3DEX *******/
#  ifdef NEAR_CLIP_OFF
        .half   0x4633		# 
#ifndef	DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
        .word   0x4445582e	# "F3DEX.NoN       "
        .word   0x4e6f4e20	#
        .word   0x20202020	#
#else
        .word   0x44504558	# "F3DPEX.NoN/D    "
        .word   0x2e4e6f4e	#
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4558	# "F3DZEX.NoN/E    "
        .word   0x2e4e6f4e	#
        .word   0x2f452020	#
#endif
#  else  /* NEAR_CLIP_OFF */
        .half   0x4633		# 
#ifndef	DIRECTZCMP
#ifndef	FORCE_MMTX_LOAD
#ifndef	OUTPUT_DRAM
#ifdef	TXLOAD4b
        .word   0x44544558	# "F3DTEX/A        "
        .word   0x2f412020	#
#else
        .word   0x44455820	# "F3DEX           "
        .word   0x20202020	#
#endif
#else
        .word   0x4445582e	# "F3DEX.dram      "
        .word   0x6472616d	#
#endif
#else
        .word   0x44504558	# "F3DPEX/D        "
        .word   0x2f442020	#
#endif
#else
        .word   0x445a4558	# "F3DZEX/E        "
        .word   0x2f452020	#
#endif
        .word   0x20202020	#
#  endif /* NEAR_CLIP_OFF */
# endif
        .word   0x312e3233	# "1.23"

# ifdef NEWCOM
RSP_L_3:
# else
RSP_L_7:             		# light #7 (initialized to magic values)
# endif
        .word   0x20596f73
        .word   0x68697461
        .word   0x6b612059
        .word   0x6173756d
        .word   0x6f746f20
        .word   0x4e696e74
        .word   0x656e646f
#ifdef	OUTPUT_LOG
	.word	0x00700000	# for OUTPUT_LOG
#else
        .word   0x2e000000
#endif
#else
RSP_L_4:      			# light #4 (initialized to magic values)
        .word   0x52535020
        .word   0x53572056
        .word   0x65727369
        .word   0x6f6e3a20
        .word   0x322e3044
        .word   0x2c203034
        .word   0x2d30312d
        .word   0x39360053
RSP_L_5:      			# light #5 (initialized to magic values)
        .word   0x47492055
        .word   0x36342047
        .word   0x46582053
        .word   0x57205445
        .word   0x414d3a20
        .word   0x5320416e
        .word   0x64657273
        .word   0x6f6e2c20
RSP_L_6:             		# light #6 (initialized to magic values)
        .word   0x53204361
        .word   0x72722c20
        .word   0x48204368
        .word   0x656e672c
        .word   0x204b204c
        .word   0x75737465
        .word   0x722c2052
        .word   0x204d6f6f
RSP_L_7:             		# light #7 (initialized to magic values)
        .word   0x72652c20
        .word   0x4e20506f
        .word   0x6f6c6579
        .word   0x2c204120
        .word   0x5372696e
        .word   0x69766173
        .word   0x616e0a00
        .word   0x00000000
#endif
	.symbol RSP_L_BASE,     (RSP_L_0)-((RSP_L_LEN)*2)
	.symbol RSP_L_NUM,      RSP_STATEP_L_LEN

 #
 #
 ############## END OF LIGHTING TABLE #############################

 ### NOTE: DO NOT PUT ANYTHING BETWEEN THE LIGHTING AND MOVEMEM TABLES

 ##################################################################
 ############## MOVEMEM TABLE #####################################
 ##################################################################
 # This is a table of locations to store quad words which have been
 # DMA'd with the MOVEMEM DMA command.  The MOVEMEM command
 # specifies an index into this table to indicate where the 4 words
 # of DMA'd data should be stored.

	.bound	2
MOVEMEM_TBL:
        .half   RSP_VIEWPORT_OFFSET     # viewport address
        .half   RSP_R_LOOKATX           # lookat X vector in world space
        .half   RSP_R_LOOKATY           # lookat Y vector in world space
        .half   RSP_L_0                 # light 0
        .half   RSP_L_1                 # light 1
        .half   RSP_L_2                 # light 2
        .half   RSP_L_3                 # light 3
#ifdef	NEWCOM
        .half   RSP_L_0                 # light 4
        .half   RSP_L_1                 # light 5
        .half   RSP_L_2                 # light 6
        .half   RSP_L_3                 # light 7
#else
        .half   RSP_L_4                 # light 4
        .half   RSP_L_5                 # light 5
        .half   RSP_L_6                 # light 6
        .half   RSP_L_7                 # light 7
#endif
	.half	RSP_STATEP_TXTR_ATTR	# Texture Attributes
#ifdef	FORCE_MMTX_LOAD
	.half	RSP_CURR_MMTX_OFFSET_2	# Matrix part 2
	.half	RSP_CURR_MMTX_OFFSET_3	# Matrix part 3
	.half	RSP_CURR_MMTX_OFFSET_4	# Matrix part 4
MOVEWORD_TBL:
	.half	RSP_CURR_MMTX_OFFSET	# Matrix part 1
#else
	.half	RSP_CURR_MPMTX_OFFSET_2 # Matrix part 2
	.half	RSP_CURR_MPMTX_OFFSET_3 # Matrix part 3
	.half	RSP_CURR_MPMTX_OFFSET_4 # Matrix part 4
MOVEWORD_TBL:
	.half	RSP_CURR_MPMTX_OFFSET	# matrix IMPORTANT! Must be first! (for movemem)
#endif
	.half   RSP_L_NUM               # number of active lights * RSP_L_LEN
	.half	CLIP_SELECT		# clip lookup table
	.half	RSP_SEG_OFFSET		# segment table
	.half	RSP_FOG_FACTOR		# fog multipliers
	.half	RSP_LIGHT_COL		# light colors
	.half	RSP_POINTS_OFFSET	# points buffer
	.half	RSP_STATEP_PERSPNORM_H	# perspnorm factor

 #
 #
 ############## END OF MOVEMEM TABLE ##############################

 ##################################################################
 ############## MORE CONSTS #######################################
 ##################################################################
 #
#ifdef	F3DEX_GBI
 #
 # 命令数を削るために変換テーブルを用意する.
 #
#define	sP1(i)	.symbol RSP_POINT_##i, RSP_POINTS_OFFSET+(i)*40
#define	sP2(i)	.symbol RSP_POINT_##i, RSP_POINTS_OFFSET+((i)-42)*40+20
#define	pPT(i)	.half	RSP_POINT_##i

RSP_VADDR_TABLE:
        pPT(0)  pPT(1)  pPT(2)  pPT(3)  pPT(4)  pPT(5)  pPT(6)  pPT(7)
        pPT(8)  pPT(9)  pPT(10) pPT(11) pPT(12) pPT(13) pPT(14) pPT(15)
        pPT(16) pPT(17) pPT(18) pPT(19) pPT(20) pPT(21) pPT(22) pPT(23)
        pPT(24) pPT(25) pPT(26) pPT(27) pPT(28) pPT(29) pPT(30) pPT(31)

# ifdef	NEWCOM
        pPT(32) pPT(33) pPT(34) pPT(35) pPT(36) pPT(37) pPT(38) pPT(39)
        pPT(40) pPT(41)

        pPT(42) pPT(43) pPT(44) pPT(45) pPT(46) pPT(47) pPT(48) pPT(49)
        pPT(50) pPT(51) pPT(52) pPT(53) pPT(54) pPT(55) pPT(56) pPT(57)
        pPT(58) pPT(59) pPT(60) pPT(61) pPT(62) pPT(63) pPT(64) pPT(65)
        pPT(66) pPT(67) pPT(68) pPT(69) pPT(70) pPT(71) pPT(72) pPT(73)
        pPT(74) pPT(75) pPT(76) pPT(77) pPT(78) pPT(79) pPT(80) pPT(81)
        pPT(82) pPT(83) 
#if 0
        .space	128-40		# ライトを 8->4 にして空いた 128bytes の内
                                # 40 bytes をテーブルに使用した残り
#endif
# endif
	.align	16
	.bound	16

# ifdef	FASTYSORT
 #
 # y-sort 用のテーブル
 #
RSP_YSORT_MAX:
	.byte	4
	.byte	4
	.byte	0
	.byte	4
	.byte	2
	.byte	2
	.byte	0
RSP_YSORT_MID:
	.byte	2
	.byte	2
	.byte	4
	.byte	0
	.byte	0
	.byte	4
	.byte	2
RSP_YSORT_MIN:
	.byte	0
	.byte	0
	.byte	2
	.byte	2
	.byte	4
	.byte	0
	.byte	4
RSP_YSORT_NEG:
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	1
	.byte	1

        .half	0	# PADDING
        .half	0	# PADDING
# endif
#endif
#if	(defined(F3DLP_GBI)&&defined(DIRECTZCMP))
#define	sP1(i)	.symbol RSP_POINT_##i, RSP_POINTS_OFFSET+(i)*24
#define	pPT(i)	.half	RSP_POINT_##i
RSP_VADDR_TABLE:
        pPT(0)  pPT(1)  pPT(2)  pPT(3)  pPT(4)  pPT(5)  pPT(6)  pPT(7)
        pPT(8)  pPT(9)  pPT(10) pPT(11) pPT(12) pPT(13) pPT(14) pPT(15)
        pPT(16) pPT(17) pPT(18) pPT(19) pPT(20) pPT(21) pPT(22) pPT(23)
        pPT(24) pPT(25) pPT(26) pPT(27) pPT(28) pPT(29) pPT(30) pPT(31)
        pPT(32) pPT(33) pPT(34) pPT(35) pPT(36) pPT(37) pPT(38) pPT(39)
        pPT(40) pPT(41) pPT(42) pPT(43) pPT(44) pPT(45) pPT(46) pPT(47)
#endif
 #
 #
 ############## END OF MORE CONSTS ################################

 ##################################################################
 ############## VIEWPORT ##########################################
 ##################################################################
 #
 # define offsets for the viewport structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |scal.x |scal.y |scal.z |       |trns.x |trns.y |trns.z |        |
 #  -----------------------------------------------------------------
 #
 # These guys have 1-bit of fraction to them. This is factored out
 # during the transform.
 #
 #
#define RSP_VIEWPORT_SX         0
#define RSP_VIEWPORT_SY         2
#define RSP_VIEWPORT_SZ         4
#define RSP_VIEWPORT_TX         8
#define RSP_VIEWPORT_TY         10
#define RSP_VIEWPORT_TZ         12

	.align	16
	.bound	16
RSP_VIEWPORT_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
 #
 #
 ############## END OF VIEWPORT ###################################

 ##################################################################
 ############## FOG FACTOR ########################################
 ##################################################################
 #
	.bound	16
RSP_FOG_FACTOR:				# NOTE: altered by MOVEWORD
	.half	0x0100	# multiplier
	.half	0x0000	# add
	.half	0x00ff	# clamp
#ifdef	F3DEX_GBI
CLIPANDSETUP:
#ifdef	LINE3D
        .half	0x0000
#else
        .half	clipAndSetup
#endif
#endif
 #
 #
 ############## END OF FOG FACTOR #################################

 ##################################################################
 ############## DISPLAY LIST STACK ################################
 ##################################################################
 #

 #-YASU
 #  
 #  FIFO ucode に固定することによるバッファの拡大 (+32bytes)
 #  
 #-YASU
RSP_DLSTACK_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
#ifdef	MOREDLLNK
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
#endif
 #
 #
 ############## END OF DISPLAY LIST STACK #########################

 ##################################################################
 ############## END OF INITIALIZED DATA############################
 ##################################################################
	.align	16
	.bound	16
RSP_END_INITIALIZE:

 ##################################################################
 ############## MATRICES ##########################################
 ##################################################################
 #
	.bound	16	
RSP_CURR_MMTX_OFFSET:	/* 64 bytes per matrix */
        .space	16
RSP_CURR_MMTX_OFFSET_2:
        .space	16
RSP_CURR_MMTX_OFFSET_3:
        .space	16
RSP_CURR_MMTX_OFFSET_4:
        .space	16
 #       .space	64

RSP_CURR_PMTX_OFFSET:	/* 64 bytes per matrix */
	.space	64


RSP_CURR_MPMTX_OFFSET:	/* 64 bytes per matrix */
	.space	16	/* 1st quad word */
RSP_CURR_MPMTX_OFFSET_2:
	.space	16	/* 2nd quad word */
RSP_CURR_MPMTX_OFFSET_3:
	.space	16	/* 3rd quad word */
RSP_CURR_MPMTX_OFFSET_4:
	.space	16	/* 4th quad word */
      #	.space	64	/* 64 bytes per matrix */
 #
 #
 ############## END OF MATRICES ###################################

 ##################################################################
 ############## POINTS BUFFER #####################################
 ##################################################################
 #
 #
 # NOTE:
 # Since we try to always process two points at a time in the vertex
 # and shading, we should interleave pairs of points in the points
 # buffer, so that we can load pairs of things in one instruction.
 #
 # Wed Aug 17 14:44:01 PDT 1994
 #
 #
 #
 #
 # define offsets for the points buffer structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  | x.int | y.int | z.int | w.int | x.frac| y.frac| z.frac| w.frac|
 #  ----------------------------------------------------------------|
 #  | r | g | b | a |   s   |   t   | xscr  | yscr  | zscr.i|zscr.f |
 #  -----------------------------------------------------------------
 #  | 1/w.i | 1/w.f |  0c0c |flg| 00|
 #  ---------------------------------
 #
 #  depending on flag, color could be normal (nx, ny, nz).
 #
 # 32-bit 3D xyzw might be overkill; but we do need the resolution for z,
 # and certainly for intermediate computations.
 #
 #

 #-------------------------------------------
 # F3DLP.Rej/F3DLX.Rej の頂点バッファ
 #-------------------------------------------
#ifdef	F3DLP_GBI
# ifdef	DIRECTZCMP
 #----------------------------------------
 #  Z 値ダイレクト比較モード  頂点数 48
 #----------------------------------------
#  define RSP_PTS_XS             0
#  define RSP_PTS_YS             2
#  define RSP_PTS_ZS             4
#  define RSP_PTS_ZSF            6
#  define RSP_PTS_R_NX           8
#  define RSP_PTS_G_NY           9
#  define RSP_PTS_B_NZ          10
#  define RSP_PTS_A             11
#  define RSP_PTS_S             12
#  define RSP_PTS_T             14
#  define RSP_PTS_INVW_INT	16
#  define RSP_PTS_INVW_FRAC	18
#  define RSP_PTS_W_INT		20
#  define RSP_PTS_LEN		24	/* 大きめに確保する */
#  define RSP_PTS_X_FRAC	 0	/* Dummy */
#  define RSP_PTS_CC		 0	/* Dummy */
# else
 #----------------------------------------
 #  screen Z 値比較モード  頂点数 64/80
 #----------------------------------------
#  define RSP_PTS_XS             0
#  define RSP_PTS_YS             2
#  define RSP_PTS_ZS             4
#  define RSP_PTS_ZSF            6
#  define RSP_PTS_R_NX           8
#  define RSP_PTS_G_NY           9
#  define RSP_PTS_B_NZ          10
#  define RSP_PTS_A             11
#  define RSP_PTS_S             12
#  define RSP_PTS_T             14
#  define RSP_PTS_INVW_INT	16
#  define RSP_PTS_INVW_FRAC	18
#  ifdef  PERSPTXTR
#    define RSP_PTS_LEN		20
#  else
#    define RSP_PTS_LEN		16
#  endif
#  define RSP_PTS_X_INT		0	/* Dummy */
#  define RSP_PTS_X_FRAC	0	/* Dummy */
#  define RSP_PTS_CC		0	/* Dummy */
# endif
#else
# ifndef	NEWCOM

/* F3DEX/LX (デフォルト) の頂点バッファ */
#define RSP_PTS_X_INT           0
#define RSP_PTS_Y_INT           2
#define RSP_PTS_Z_INT           4
#define RSP_PTS_W_INT           6
#define RSP_PTS_X_FRAC          8
#define RSP_PTS_Y_FRAC          10
#define RSP_PTS_Z_FRAC          12
#define RSP_PTS_W_FRAC          14
#define RSP_PTS_R_NX            16
#define RSP_PTS_G_NY            17
#define RSP_PTS_B_NZ            18
#define RSP_PTS_A               19
#define RSP_PTS_S               20
#define RSP_PTS_T               22
#define RSP_PTS_XS              24
#define RSP_PTS_YS              26
#define RSP_PTS_ZS              28
#define RSP_PTS_ZSF             30
#define RSP_PTS_INVW_INT        32
#define RSP_PTS_INVW_FRAC       34
#define RSP_PTS_CC              36
#define RSP_PTS_FLAG            38
#define RSP_PTS_LEN             40
# else	/* NEWCOM */

/* F3DNCom (NEWCOM カスタム) の頂点バッファ */
#define RSP_PTS_X_INT           24
#define RSP_PTS_Y_INT           26
#define RSP_PTS_Z_INT           28
#define RSP_PTS_W_INT           30
#define RSP_PTS_X_FRAC          32
#define RSP_PTS_Y_FRAC          34
#define RSP_PTS_Z_FRAC          36
#define RSP_PTS_W_FRAC          38
#define RSP_PTS_R_NX            0
#define RSP_PTS_G_NY            1
#define RSP_PTS_B_NZ            2
#define RSP_PTS_A               3
#define RSP_PTS_S               4
#define RSP_PTS_T               6
#define RSP_PTS_XS              8
#define RSP_PTS_YS              10
#define RSP_PTS_ZS              12
#define RSP_PTS_ZSF             14
#define RSP_PTS_INVW_INT        16
#define RSP_PTS_INVW_FRAC       18
#define RSP_PTS_CC              20
#define RSP_PTS_FLAG            22
#define RSP_PTS_LEN             40
# endif	/* NEWCOM */
#endif

 #-YASU
 #  
 #  FIFO ucode に固定することで得られた 1024 バイトの内 640bytes を
 #  頂点キャッシュに割り当てる.
 #
 #  これで合計 1280 バイト 32 頂点分となる
 #
 #   1 頂点辺りのバイト数をもう少し減らせばもっとたくさんの頂点を
 #   設定することができるが, それはまた今度
 #  
 #-YASU
RSP_POINTS_OFFSET:
	.space	640	/* 40 bytes * 16 points */
#ifdef	F3DEX_GBI
	.space	640	/* 40 bytes * 16 points */
# ifdef	NEWCOM
/*
 *  NewCom 仕様の場合, CLIPPING OFF の時にここを頂点バッファに使用する
 *  ただし実際には gflight.s で 64 bytes, gvtx.s で 20 bytes 必要なので
 *  480-64=416 bytes 使用する. (gvtx.s は gflight.s と同じ領域に割り当てる)
 *  1 頂点 20 bytes 必要だから 20 頂点分の追加バッファが確保できる. 
 *  yield 時のセーブバッファを 480 bytes = (0x1e0) 増やす必要あり.
 */

RSP_SCRATCH_OFFSET:   /* 12 points * 40 bytes/pt = 480 bytes of clip points */
	.space	400   /* NewCom 追加 20 頂点 */

        .space	16    /* PAD */
RSP_SCRATCH_FLIGHT:
        .space	64    /* gflight.s/gvtx.s 用 scratch エリア */
# endif
#elif	defined(F3DLP_GBI)
# ifdef DIRECTZCMP
	.space	512	/* 24*48-640 bytes */
        .space   32	/* 空きエリア 1280-24*48-2*48 for PADDING */
# else
	.space	640	/* 40 bytes * 16 points */
# endif
#endif
#ifdef	F3DEX_GBI
        sP1(0)  sP1(1)  sP1(2)  sP1(3)  sP1(4)  sP1(5)  sP1(6)  sP1(7)
        sP1(8)  sP1(9)  sP1(10) sP1(11) sP1(12) sP1(13) sP1(14) sP1(15)
        sP1(16) sP1(17) sP1(18) sP1(19) sP1(20) sP1(21) sP1(22) sP1(23)
        sP1(24) sP1(25) sP1(26) sP1(27) sP1(28) sP1(29) sP1(30) sP1(31)
# ifdef	NEWCOM
        sP1(32) sP1(33) sP1(34) sP1(35) sP1(36) sP1(37) sP1(38) sP1(39)
        sP1(40) sP1(41)
        sP2(42) sP2(43) sP2(44) sP2(45) sP2(46) sP2(47) sP2(48) sP2(49)
        sP2(50) sP2(51) sP2(52) sP2(53) sP2(54) sP2(55) sP2(56) sP2(57)
        sP2(58) sP2(59) sP2(60) sP2(61) sP2(62) sP2(63) sP2(64) sP2(65)
        sP2(66) sP2(67) sP2(68) sP2(69) sP2(70) sP2(71) sP2(72) sP2(73)
        sP2(74) sP2(75) sP2(76) sP2(77) sP2(78) sP2(79) sP2(80) sP2(81)
        sP2(82) sP2(83) 
# endif
#endif
#ifdef	F3DLP_GBI
# ifdef DIRECTZCMP
        sP1(0)  sP1(1)  sP1(2)  sP1(3)  sP1(4)  sP1(5)  sP1(6)  sP1(7)
        sP1(8)  sP1(9)  sP1(10) sP1(11) sP1(12) sP1(13) sP1(14) sP1(15)
        sP1(16) sP1(17) sP1(18) sP1(19) sP1(20) sP1(21) sP1(22) sP1(23)
        sP1(24) sP1(25) sP1(26) sP1(27) sP1(28) sP1(29) sP1(30) sP1(31)
        sP1(32) sP1(33) sP1(34) sP1(35) sP1(36) sP1(37) sP1(38) sP1(39)
        sP1(40) sP1(41) sP1(42) sP1(43) sP1(44) sP1(45) sP1(46) sP1(47)
# endif
        .symbol	RSP_POINTS_OFFSET_RV,	-RSP_POINTS_OFFSET
        .symbol	RSP_POINTS_SIZE,	RSP_PTS_LEN*0x0080
#endif
 #
 #
 ############## END OF POINTS BUFFER ##############################

 ##################################################################
 ############## I/O and SCRATCH BUFFERS ###########################
 ##################################################################
 #
RSP_DLINPUT_OFFSET:
	.space	320	/* load display lists in 320 byte chunks */

 ##################################################################
 ############## SPRITE BUFFER #####################################
 ##################################################################
 #
 #
 # NOTE:
 # The sprite structure is only used for the Sprite Microcode. The
 # sprite structure data are DMA'd into the Input data area in DMEM.
 #
 # Thu Apr 18 16:09:36 PDT 1996
 #
 #
 #
 #
 # define offsets for the sprite data structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  DO THIS WHEN THE STRUCTURE HAS CEMENTED, FOR NOW EVERYTHING BELOW
 #  IS JUST TEMPORARY. ACTUAL LOCATIONS, NAMES AND SIZES WILL CHANGE.
 #
 #

#define RSP_SP_SOURCEP         0
#define RSP_SP_TLUTP           4
#define RSP_SP_STRIDE          8
#define RSP_SP_SUBWIDTH        12
#define RSP_SP_SUBHEIGHT       16
#define RSP_SP_SOURCETYPE      20
#define RSP_SP_SOURCEBITSIZE   24
#define RSP_SP_SCALEX          28
#define RSP_SP_SCALEY          32
#define RSP_SP_FLIPX           36
#define RSP_SP_FLIPY           40
#define RSP_SP_SOURCEOFFSETS   44
#define RSP_SP_SOURCEOFFSETT   48
#define RSP_SP_PSCREENX        52
#define RSP_SP_PSCREENY        56
#define RSP_SP_SPRITEZ         60
#define RSP_SP_YFLIPMIRROR     64
#define RSP_SP_DUMMY0          68
#define RSP_SP_DUMMY1          72
#define RSP_SP_DUMMY2          76
#define RSP_SP_DUMMY3          80
#define RSP_SP_DUMMY4          84
#define RSP_SP_DUMMY5          88
#define RSP_SP_DUMMY6          92
#define RSP_SP_DUMMY7          96
#define RSP_SP_DUMMY8          100
#define RSP_SP_DUMMY9          104
#define RSP_SP_DUMMY10         108
#define RSP_SP_DUMMY11         112
#define RSP_SP_DUMMY12         116

 #-YASU
 #  
 #  DMA input 用のデータエリアである.
 #  16bytes/頂点 なので 32 頂点とした場合 32*16 バイト必要となるが
 #  この次のエリアの RSP_SETUP_TMP_OFFSET/RSP_CLIP_TMP_OFFSET (計 256bytes)
 #  とは同時に使用することはないので、次のエリアも使用する.
 #  ただし, setup を変更したのでかなりの部分が空きとなることが予想される.
 #  また scratch エリアとこの領域を共用できるのではないのかと考えられるので
 #  予断は許さない状況である. とりあえず、絞るのはあとに回して, 先に進む.
 #  
 #  スプライトライブラリがこの部分を使用するようなのでこの分も yield 時に
 #  保存している..... 絞るのはあとで.... 
 #
 #-YASU
RSP_INPUT_OFFSET:
	.space	256	/* 256 bytes of DMA input buffer */

 #
 #
 ############## END OF SPRITE BUFFER ##############################

 #-YASU
 #  
 #  yield 時のレジスタセーブ領域の為に 32 バイト分多めにセーブする
 #  この値は sptask.h の OS_YIELD_DATA_SIZE に設定
 #  
 #-YASU
RSP_YIELD_SAVE_LEN1:	/* what to save when yield occurs */
	.print	""
#ifdef	SWITCH_UCODE	/* LOADABLE にするためにセーブ領域を一致させる */
	.symbol RSP_YIELD_SAVE_LEN,	0xc00
#else
	.symbol RSP_YIELD_SAVE_LEN,	(RSP_YIELD_SAVE_LEN1)+(0x20)
#endif
#ifdef	F3DNCom_GBI
	.dmax	(0xe20) - (31)
#else
	.dmax	(OS_YIELD_DATA_SIZE) - (31)
#endif

 #
 # WARNING! 
 # We do not use the correct DMA length in the RSP_INPUT transfer in
 # gmain.s... This means we might overwrite the first word of SETUP_TMP.
 # That's okay, SETUP_TMP is guarenteed to be trash-able at the time we
 # do this transfer.
 #
 # Don't move this around, or put anything between RSP_INPUT and SETUP_TMP
 # If you do, it might get overwritten when you least expect it.
 #

RSP_SETUP_TMP_OFFSET:
	.space	96	/* 96 bytes of setup scratch mem */

RSP_CLIP_TMP_OFFSET:
	.space	160	/* 160 bytes of clip scratch space */

 #-YASU
 #  
 #  FIFO 限定にするため、RSP_OUTPUT_OFFSET は FIFO バッファへの DMA ソース
 #  用として 3 角形 2 個分のみ(ダブルバッファ用)確保する.
 #  １つの 3 角形につき最大 176 bytes 必要であるから 176*2=352 バイトを確保
 #  する. 
 #  1024-352 = 672 bytes free となるから, 頂点キャッシュを倍にするため、
 #  残り 640 バイトを頂点バッファとして確保する.
 #
 #  よって残り 32 バイトを DL リンク用として使う
 #
 #  F3DEX の場合, 頂点キャッシュ座標計算用としてテーブル参照を行なうのでそ
 #  の分 32*2=64 を使用する. この時の OUTPUT バッファは 176 bytes のみ使用する.
 #  さらに y-sort の為の変換テーブル用として 32 bytes を使用する.
 #
 #-YASU
RSP_OUTPUT_OFFSET:
#ifdef	F3DLP_GBI
	.space	352	/* 176*2 bytes of output buffer (for 2 triangles) */
        .space  352	/* double buffer */
#else
#  ifdef  F3DEX_GBI
        .space	176	  /* 176*1 bytes of output buffer (for 1 triangle) */
#    ifdef  FASTYSORT
#      ifdef  NEWCOM
 #        .space  176-64-32-64 /* 空き 16 bytes */
        .space  176	  /* 空き 176 bytes */
#      else
        .space  176-64-32 /* 空き 80 bytes */
#      endif
#    else
        .space  176-64    /* 空き */
#    endif
#  else
	.space	1024	/* 1024 bytes of output buffer */
#  endif
#endif
RSP_OUTPUT_END:

#ifndef	NEWCOM
#ifdef	F3DLP_GBI
	.space	480-64-352
RSP_SCRATCH_OFFSET:
RSP_SCRATCH_FLIGHT:
        .space	64    /* gflight.s/gvtx.s 用 scratch エリア */
#else
RSP_SCRATCH_OFFSET:
	.space	480   /* 12 points * 40 bytes/pt = 480 bytes of clip points */
#endif
#endif
	.symbol RSP_DLINPUT_SIZE8,	(RSP_INPUT_OFFSET)-(RSP_DLINPUT_OFFSET)
	.symbol RSP_OUTPUT_SIZE8,	(RSP_OUTPUT_END)-(RSP_OUTPUT_OFFSET)
#ifdef  SMARTDLCOUNT
        .symbol RSP_DLCOUNT_INIT,       RSP_INPUT_OFFSET
#endif
 #
 #
 ############## END OF I/O and SCRATCH BUFFERS ####################

 ##################################################################
 ############## END OF ALLOCATED DMEM #############################
 ##################################################################
RSP_END_DMEM:

 ##################################################################
 ############## TASK HEADER ADDRESS ###############################
 ##################################################################

	.symbol RSP_TASK_OFFSET,	(0x1000)-(OS_TASK_SIZE)

 ##################################################################
 ############## CHECK END OF ALLOCATED DMEM #######################
 ##################################################################

	.dmax	4096

 ##################################################################
 ############## PRINT COMPILATION REPORT ##########################
 ##################################################################
 #
/* During compilation, report an informative message about DMEM allocation: */
#ifdef _LANGUAGE_ASSEMBLY

	.print	"----------------------------------------------------------\n"
	.print	"FILE: "
	.print	__FILE__
	.print	"                                          |\n"
	.print	"                                                          |\n"

	.print	"Total DMEM:    hex bytes                                  |\n"
	.print	"-------------- ---------                                  |\n"
	.print	"Initialized  : %3x",RSP_END_INITIALIZE
	.print	"                                        |\n"
	.print	"In Yield Buf : %3x",  RSP_YIELD_SAVE_LEN
	.print	"                                        |\n"
	.print	"Allocated    : %3x",RSP_END_DMEM
	.print	"                                        |\n"
	.print	"                                                          |\n"

	.print  "DMEM Map:               loc  l"
	.print	"en (hex bytes)              |\n"
	.print  "----------------------- ---  ---------------              |\n"


	.print	"RSP_PDATA_OFFSET      : %3x  %3x                          |\n",
		 RSP_PDATA_OFFSET, (-
		 RSP_PDATA_OFFSET  )+
		 RSP_STATE_OFFSET
	.print	"RSP_STATE_OFFSET      : %3x  %3x                          |\n",
		 RSP_STATE_OFFSET, (-
		 RSP_STATE_OFFSET  )+
		 RSP_SEG_OFFSET
	.print	"RSP_SEG_OFFSET        : %3x  %3x                          |\n",
		 RSP_SEG_OFFSET, (-
		 RSP_SEG_OFFSET  )+
		 RSP_LIGHTS_OFFSET
	.print	"RSP_LIGHTS_OFFSET     : %3x  %3x                          |\n",
		 RSP_LIGHTS_OFFSET, (-
		 RSP_LIGHTS_OFFSET  )+
		 RSP_VIEWPORT_OFFSET
	.print	"RSP_VIEWPORT_OFFSET   : %3x  %3x                          |\n",
		 RSP_VIEWPORT_OFFSET, (-
		 RSP_VIEWPORT_OFFSET  )+
		 RSP_DLSTACK_OFFSET
	.print	"RSP_DLSTACK_OFFSET    : %3x  %3x                          |\n",
		 RSP_DLSTACK_OFFSET, (-
		 RSP_DLSTACK_OFFSET  )+
		 RSP_CURR_MMTX_OFFSET
	.print	"RSP_CURR_MMTX_OFFSET  : %3x  %3x                          |\n",
		 RSP_CURR_MMTX_OFFSET, (-
		 RSP_CURR_MMTX_OFFSET  )+
		 RSP_CURR_PMTX_OFFSET
	.print	"RSP_CURR_PMTX_OFFSET  : %3x  %3x                          |\n",
		 RSP_CURR_PMTX_OFFSET, (-
		 RSP_CURR_PMTX_OFFSET  )+
		 RSP_CURR_MPMTX_OFFSET
	.print	"RSP_CURR_MPMTX_OFFSET : %3x  %3x                          |\n",
		 RSP_CURR_MPMTX_OFFSET, (-
		 RSP_CURR_MPMTX_OFFSET  )+
		 RSP_POINTS_OFFSET
#ifndef	NEWCOM
	.print	"RSP_POINTS_OFFSET     : %3x  %3x                          |\n",
		 RSP_POINTS_OFFSET, (-
		 RSP_POINTS_OFFSET  )+
		 RSP_DLINPUT_OFFSET
	.print	"RSP_DLINPUT_OFFSET    : %3x  %3x                          |\n",
		 RSP_DLINPUT_OFFSET, (-
		 RSP_DLINPUT_OFFSET  )+
		 RSP_INPUT_OFFSET
#else
	.print	"RSP_POINTS_OFFSET     : %3x  %3x                          |\n",
		 RSP_POINTS_OFFSET, (-
		 RSP_POINTS_OFFSET  )+
		 RSP_SCRATCH_OFFSET
	.print	"RSP_SCRATCH_OFFSET    : %3x  %3x                          |\n",
		 RSP_SCRATCH_OFFSET, (-
		 RSP_SCRATCH_OFFSET  )+
		 RSP_DLINPUT_OFFSET

	.print	"RSP_DLINPUT_OFFSET    : %3x  %3x                          |\n",
		 RSP_DLINPUT_OFFSET, (-
		 RSP_DLINPUT_OFFSET  )+
		 RSP_INPUT_OFFSET
#endif
	.print	"RSP_INPUT_OFFSET      : %3x  %3x                          |\n",
		 RSP_INPUT_OFFSET, (-
		 RSP_INPUT_OFFSET  )+
		 RSP_SETUP_TMP_OFFSET
	.print	"RSP_SETUP_TMP_OFFSET  : %3x  %3x                          |\n",
		 RSP_SETUP_TMP_OFFSET, (-
		 RSP_SETUP_TMP_OFFSET  )+
		 RSP_CLIP_TMP_OFFSET
	.print	"RSP_CLIP_TMP_OFFSET   : %3x  %3x                          |\n",
		 RSP_CLIP_TMP_OFFSET, (-
		 RSP_CLIP_TMP_OFFSET  )+
		 RSP_OUTPUT_OFFSET
#ifndef	NEWCOM
	.print	"RSP_OUTPUT_OFFSET     : %3x  %3x                          |\n",
		 RSP_OUTPUT_OFFSET, (-
		 RSP_OUTPUT_OFFSET  )+
		 RSP_SCRATCH_OFFSET
	.print	"RSP_SCRATCH_OFFSET    : %3x  %3x                          |\n",
		 RSP_SCRATCH_OFFSET, (-
		 RSP_SCRATCH_OFFSET  )+
		 RSP_END_DMEM
#else
	.print	"RSP_OUTPUT_OFFSET     : %3x  %3x                          |\n",
		 RSP_OUTPUT_OFFSET, (-
		 RSP_OUTPUT_OFFSET  )+
		 RSP_END_DMEM
#endif

	.print	"----------------------------------------------------------\n"

    .text

#   undef _DumpDMEMOffset
#else  /* _LANGUAGE_ASSEMBLY */
#endif /* _LANGUAGE_ASSEMBLY */
