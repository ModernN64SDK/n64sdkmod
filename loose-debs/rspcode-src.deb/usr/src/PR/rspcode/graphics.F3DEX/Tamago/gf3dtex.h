/*---------------------------------------------------------------------
	Copyright (C) 1997, Nintendo.
	
	File		gf3dtex.h
	Coded    by	Yoshitaka Yasumoto.	Aug 26, 1997.
	Modified by	
	Comments	Header file for F3DTEX ucode
	
	$Id: gf3dtex.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
  ---------------------------------------------------------------------*/
#ifndef	_gf3dtex_h_
#define	_gf3dtex_h_

#define	G_TXTRBLK_4b_1	(G_IMMFIRST-10)
#define	G_TXTRBLK_4b_2	(G_IMMFIRST-1)

#define	_gDPLoadTextureBlock_4b_1(pkt, width, height, imgadrs)	\
{								\
  Gfx *_g = (Gfx *)(pkt);					\
  _g->words.w0 = (_SHIFTL(G_TXTRBLK_4b_1,24,8)|			\
                  _SHIFTL((MIN((((width)*(height)+3)>>2)-1,	\
			       G_TX_LDBLK_MAX_TXL)),12,12)|	\
		  _SHIFTL(CALC_DXT_4b(width),0,12));		\
  _g->words.w1 = (u32)imgadrs;					\
}

#define	_gsDPLoadTextureBlock_4b_1(width, height, imgadrs)	\
{								\
  (_SHIFTL(G_TXTRBLK_4b_1,24,8)|				\
   _SHIFTL((MIN((((width)*(height)+3)>>2)-1,			\
		G_TX_LDBLK_MAX_TXL)),12,12)|			\
   _SHIFTL(CALC_DXT_4b(width),0,12)),				\
  ((u32)(imgadrs))						\
}

#define	_gDPLoadTextureBlock_4b_2(pkt, width, height, pal,		\
				   cms, masks, shifts, cmt, maskt, shiftt) \
{									\
  Gfx *_g = (Gfx *)(pkt);						\
  _g->words.w0 = (_SHIFTL(G_TXTRBLK_4b_2,24,8)|				\
		  _SHIFTL((pal),   20,4) | 				\
		  _SHIFTL((cmt),   18,2) | _SHIFTL((maskt),14, 4) |	\
		  _SHIFTL((shiftt),10,4) | _SHIFTL((cms),   8, 2) |	\
		  _SHIFTL((masks),  4,4) | _SHIFTL((shifts),0, 4));	\
  _g->words.w1 = (_SHIFTL((((width)+15)>>4),24, 8)|			\
		  _SHIFTL((((width) -1)<<2),12,12)|		       	\
		  _SHIFTL((((height)-1)<<2), 0,12));		       	\
}

#define	_gsDPLoadTextureBlock_4b_2(width, height, pal,			\
				   cms, masks, shifts, cmt, maskt, shiftt) \
   (_SHIFTL(G_TXTRBLK_4b_2,24,8)|					\
   _SHIFTL((pal),   20,4) | 						\
   _SHIFTL((cmt),   18,2) | _SHIFTL((maskt),14, 4) |			\
   _SHIFTL((shiftt),10,4) | _SHIFTL((cms),   8, 2) |			\
   _SHIFTL((masks),  4,4) | _SHIFTL((shifts),0, 4)),			\
   (_SHIFTL((((width)+15)>>4),24, 8)|					\
    _SHIFTL((((width) -1)<<2),12,12)|		       			\
    _SHIFTL((((height)-1)<<2), 0,12))

#define gDPLoadTextureBlock_4b_TM(pkt, timg, fmt, width, height, pal,	\
				  cms, cmt, masks, maskt, shifts, shiftt)\
{                                                                       \
  _gDPLoadTextureBlock_4b_1((pkt),(width),(height),(timg));		\
  _gDPLoadTextureBlock_4b_2((pkt),(width),(height),(pal),		\
			    (cms),(masks),(shifts),			\
			    (cmt),(maskt),(shiftt));			\
}

#define gsDPLoadTextureBlock_4b_TM(timg, fmt, width, height,        	\
                pal, cms, cmt, masks, maskt, shifts, shiftt)            \
	_gsDPLoadTextureBlock_4b_1((width),(height),(timg)),		\
	_gsDPLoadTextureBlock_4b_2((width),(height),(pal),		\
				   (cms),(masks),(shifts),		\
				   (cmt),(maskt),(shiftt))

extern long long int  gspF3DTEX_fifoTextStart[], gspF3DTEX_fifoTextEnd[];
extern long long int  gspF3DTEX_fifoDataStart[], gspF3DTEX_fifoDataEnd[];

#endif
/*======== End of gf3dtex.h ========*/
