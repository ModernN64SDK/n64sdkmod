/*---------------------------------------------------------------------
  $Id: ucode_flatfog.h,v 1.1.1.1 2002/05/02 03:29:11 blythe Exp $
  
  File : ucode_flatfog.h
  
  Coded     by Yoshitaka Yasumoto.   Jun  6, 1997.
  Copyright by Nintendo, Co., Ltd.           1997.
  ---------------------------------------------------------------------*/
#ifndef _UCODE_FLATFOG_H_
#define	_UCODE_FLATFOG_H_

#ifdef _LANGUAGE_C_PLUS_PLUS
extern "C" {
#endif

#if defined(_LANGUAGE_C) || defined(_LANGUAGE_C_PLUS_PLUS)
extern long long int gspF3DLX_FlatFog_fifoTextStart[],
                     gspF3DLX_FlatFog_fifoTextEnd[];
extern long long int gspF3DLX_FlatFog_fifoDataStart[],
                     gspF3DLX_FlatFog_fifoDataEnd[];
#endif /* _LANGUAGE_C */

#ifdef _LANGUAGE_C_PLUS_PLUS
}
#endif

#endif /* !_UCODE_FLATFOG_H_ */
/*======== End of ucode_flatfog.h ========*/
