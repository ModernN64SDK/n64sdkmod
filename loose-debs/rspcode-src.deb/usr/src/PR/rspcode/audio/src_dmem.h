
/*
 * src_dmem.h
 *
 * This file lays out the DMEM usage for the RSP resampling task.
 *
 */

#ifndef _src_dmem_h_
#define _src_dmem_h_ 1

/*
 * usage of the 'eval' macro below implies that this code must pass
 * throught the 'm4' macro processor. The RSP assembler does this,
 * by default, but any C program including this might have trouble with this.
 * Protect them by defining the eval() macro...
 */
#ifdef _LANGUAGE_C
# ifndef eval
#    define eval(s)	(s)
# endif /* eval */
#endif /* _LANGUAGE_C */


/*
 * Memory addressing Strategy:
 *
 * We'll probably always keep the base address of DMEM around in
 * a register. We'll define all the fixed areas as offsets from
 * there. We'll also try to keep things clean and flexible as they
 * _will_ change during development.
 *
 */

#ifndef DCACHEBASE
#   define DCACHEBASE	0x00000000
#endif

#ifndef DCACHEBASEHI
#   define DCACHEBASEHI	0x0000
#endif
#ifndef DCACHEBASELO
#   define DCACHEBASELO	0x0000
#endif

#define BYTES_PER_SHORT           2
#define BYTES_PER_VECTOR         16
#define COEF_TAB_SIZE           256

#define C_MULINC		eval(RSP_PDATA_OFFSET)
#define C_ONE			eval(C_MULINC + BYTES_PER_VECTOR)
#define C_SHIFT			eval(C_ONE + BYTES_PER_VECTOR)
#define C_ZEROFOUR		eval(C_SHIFT + BYTES_PER_VECTOR)
#define C_ONEFIVE		eval(C_ZEROFOUR + BYTES_PER_VECTOR)
#define C_TWOSIX		eval(C_ONEFIVE + BYTES_PER_VECTOR)
#define C_THREESEVEN		eval(C_TWOSIX + BYTES_PER_VECTOR)
#define C_RAMP			eval(C_THREESEVEN + BYTES_PER_VECTOR)

#define COEF_TAB		eval(C_RAMP + BYTES_PER_VECTOR)
#define END_OF_SRC_PDATA	eval(COEF_TAB + (COEF_TAB_SIZE * BYTES_PER_SHORT))

#define ICA			eval(RSP_SCRATCH_OFFSET + RESAMPLE_STATE_SIZE8)
#define CPH			eval(ICA + BYTES_PER_VECTOR)
#define VT			eval(CPH + BYTES_PER_VECTOR)
#define LAST_FCA		eval(VT + BYTES_PER_SHORT)
#define OUTPUT_COUNT		eval(LAST_FCA + BYTES_PER_SHORT)

/* During compilation, report an informative message about DMEM allocation: */
#ifdef _LANGUAGE_ASSEMBLY
#   define _DumpDMEMOffset(o,s)  				\
    .print 	#o						\
    .print 	"\t\t : %d\t%d bytes.\n", (DCACHEBASE + (o)), (s)

    .print	"--------------------------------------------------------------------\n"

    .print	__FILE__
    .print	" : Scratch space allocated is %d bytes.\n", RSP_SCRATCH_SIZE8
    .print	__FILE__
    .print	" : Program data segment is at %08x.\n", DCACHEBASE+RSP_PDATA_OFFSET
    .print	__FILE__
    .print	" : DMEM PDATA Map:\n"

     _DumpDMEMOffset(C_MULINC, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_ONE, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_SHIFT, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_ZEROFOUR, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_ONEFIVE, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_TWOSIX, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_THREESEVEN, BYTES_PER_VECTOR)
     _DumpDMEMOffset(C_RAMP, BYTES_PER_VECTOR)
     _DumpDMEMOffset(COEF_TAB, (COEF_TAB_SIZE * BYTES_PER_SHORT))
     _DumpDMEMOffset(END_OF_SRC_PDATA, 0)

     .print	"\n\n"

    .print	__FILE__
    .print	" : DMEM SCRATCH Map:\n"

     _DumpDMEMOffset(ICA, BYTES_PER_VECTOR)
     _DumpDMEMOffset(CPH, BYTES_PER_VECTOR)
     _DumpDMEMOffset(VT, BYTES_PER_SHORT)
     _DumpDMEMOffset(LAST_FCA, BYTES_PER_SHORT)

    .print	"--------------------------------------------------------------------\n"

#   undef _DumpDMEMOffset
#endif

#endif /* _src_dmem_h_ */
