#include <abi.h>
/* #include <os.h>*/
#include <stdio.h>

/* Size value come from u-code assembly, locations are arbitrary,
   but should be used for load command in simulator.

   The command list is written by this program and sits right after
   the task header in DRAM, which is loaded at 0x00000000
*/

#define AUD_UCODE_POINTER 0x7000
#define AUD_UCODE_SIZE 1500         /* In bytes */

#define AUD_PDATA_POINTER 0x8000
#define AUD_PDATA_SIZE 600          /* In bytes */

#define AUD_CL_POINTER 48

int
VirtualToPhysical(void *a)
{
return (int) a;
}

main(int argc, char *argv[])

{
  Task tlist, *tlistp;
  Acmd alist[4096], *alistp;
  ADPCM_STATE state, *statep;
  int w0, w1, i, outpoint, inpoint;
  FILE *outp;

  if((outp = fopen(argv[1], "w")) == NULL){
    fprintf(stderr,"Can't open %s\n",argv[1]);
    exit(1);
  }
  /* Run through all the abi commands and output some
     command list - should include all the address conversion
     routines as well */

  statep = &state;
  tlistp = &tlist;
  alistp = alist;

  inpoint = 0; /* This is in samples */
  outpoint = 0;
  aSegment(alistp++, 0, 36864); /* Bitstream in DRAM 0x4000 */
  aSegment(alistp++, 1, 1048576); /* Decoded samples in DRAM 0x100000 */
  aSegment(alistp++, 3, 36848); /* Use this for state */
  aSetBuffer(alistp++, 0, 480, 180); /* 40 frames of 16 samples */
  aLoadBuffer(alistp++, inpoint<<1); /* Address in bytes */
  aSetBuffer(alistp++, 0, 200, 640); /* 40 frames of 16 samples */
  aADPCMdec(alistp++, A_INIT, 1, (3<<26)); 
  aSaveBuffer(alistp++, 1<<26 | (outpoint<<1)); /* Address in bytes!! */
  outpoint += 640;
  inpoint += 180;
  for (i=0; i<625; i++){
/*  for (i=0; i<15; i++){*/
    aSetBuffer(alistp++, 0, 480, 180); 
    aLoadBuffer(alistp++, inpoint<<1); 
    aSetBuffer(alistp++, 0, 200, 640); 
    aADPCMdec(alistp++, 0, 1, (3<<26));
    aSaveBuffer(alistp++, 1<<26 | (outpoint<<1)); /* Address in bytes!! */
    outpoint += 640;
    inpoint += 180;
  }

  alistp = alist;
  tlistp->dl = AUD_CL_POINTER;
  tlistp->len = 3133*8;
/*  tlistp->len = 83*8;*/
  tlistp->type = M_AUDTASK | ((AUD_UCODE_SIZE+256)<<12); /* ucode expects different */
  tlistp->ucode = (unsigned long *) AUD_UCODE_POINTER;
  tlistp->ucode_data = (unsigned long *) AUD_PDATA_POINTER;
  tlistp->ucode_data_len = AUD_PDATA_SIZE;
  fwrite(tlistp, 1, 48, outp);
/*  for (i=0; i<83; i++){ */
  for (i=0; i<3133; i++){
    w0 = alistp->words.w0;
    w1 = alistp->words.w1;
    fwrite(&w0, 1, 4, outp);
    fwrite(&w1, 1, 4, outp);
    fprintf(stderr,"%d %d %d %d\n",w0>>16, w0 & 0x0000FFFF, w1>>16, w1 & 0x0000FFFF);
    fprintf(stderr,"Vol %d %d %d %d\n", alistp->setvol.cmd, alistp->setvol.vol,
	    alistp->setvol.voltgt, alistp->setvol.volrate);
    alistp++;
  }
  fclose(outp);
}










