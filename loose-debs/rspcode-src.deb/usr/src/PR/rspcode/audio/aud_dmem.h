
/**************************************************************************
 *								          *
 *               Copyright (C) 1994, Silicon Graphics, Inc.       	  *
 *								          *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright  law.  They  may not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 *								          *
 *************************************************************************/

#ifndef _aud_dmem_h_
#define _aud_dmem_h_

/*
 * File:		aud_dmem.h
 *
 * This file lays out the DMEM usage for the RSP audio task.
 *
 */

/*
 * Memory layout of DMEM:
 *
 * Our aim is to minimize DMEM use so that we can process as
 * many samples as possible with a single command. 
 * The buffer area is a resource managed by the Host rather than 
 * divided into hard defined regions.
 *
 *      -------------------------------------------------
 *      | Program data from compiler...                 |     (must be first)
 *	|                               800 bytes       |
 *	|	Includes constants 			|
 *	|	coefficient table for resampler		|
 *	|						|
 *	|-----------------------------------------------|
 *	| RSP memory segment table:                     |
 *      |      16 x 4b = 		 64 bytes       |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Parameters:					|
 *	|      Input DMEM buffer	2		|
 *	|      Output DMEM buffer	2		|
 *	|      Count			2		|
 *	|      left ch initial vol 	2		|
 *	|      rightt ch initial vol 	2		|
 *	|      OutputR DMEM buffer	2		|
 *	|      Aux busL DMEM buffer	2		|
 *	|      Aux busR DMEM buffer	2		|
 *	|      left ch vol target	2		|
 *	|      left ch ms vol rate	2		|
 *	|      left ch ls vol rate	2		|
 *	|      right ch vol target	2		|
 *	|      right ch ms vol rate	2		|
 *	|      right ch ls vol rate	2		|
 *	|      aux dry amount	       	4		|
 *	|      aux wet amount	       	4		|
 *	|                              32 bytes		|  
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Input (command list)		320 bytes       |
 *      |    40 cmds, @ 8bytes				|
 *      |               				|
 *	|  (We can make this smaller if nec.		|
 *	|						|
 *	|-----------------------------------------------|
 *      | ADPCM coefficient table                       |
 *      |       Each entry is 32 bytes (16*2)           |
 *      |       so 8 entries is 256 bytes               |
 *      |                                               |
 *      |-----------------------------------------------|
 *	| Buffers available for command	results		|
 *	|  Managed by the Host CPU			|
 *	|						|
 *	|						|
 *	|-----------------------------------------------|
 *	| Scratch space for intermediate results        |
 *	|   Not touched by the Host CPU                 |
 *	|     Whatever is left                          |
 *	|                                        	|
 *	|                                        	|
 *      -------------------------------------------------
 * 
 */

/*
 * Memory addressing Strategy:
 *
 * We'll probably always keep the base address of DMEM around in
 * a register. We'll define all the fixed areas as offsets from
 * there. We'll also try to keep things clean and flexible as they
 * _will_ change during development.
 *
 */

#ifndef DCACHEBASE
#   define DCACHEBASE	0x00000000
#endif

#ifndef DCACHEBASEHI
#   define DCACHEBASEHI	0x0000
#endif
#ifndef DCACHEBASELO
#   define DCACHEBASELO	0x0000
#endif

/* These relate to the illustration above. Note that everything should
   be kept 8 byte aligned */

#define RSP_DMEM_SIZE8         4096

#define RSP_PDATA_SIZE8	        800	/* This will change in the 
					    initial stages as we develop
					    algorithms. */
#define RSP_SEG_SIZE8            64
#define RSP_PARAMETER_SIZE8      32
#define RSP_DLINPUT_SIZE8       320
#define RSP_ADPCMTABLE_SIZE8    256
#define RSP_BUFFER_SIZE8       2496	/* Try to make this bigger */
#define RSP_YIELD_BUF_SIZE8     16
#define RSP_SCRATCH_SIZE8     (RSP_DMEM_SIZE8 - RSP_YIELD_BUF_SIZE8 - \
                                RSP_BUFFER_SIZE8 - \
				RSP_DLINPUT_SIZE8 - RSP_ADPCMTABLE_SIZE8 - \
				RSP_PARAMETER_SIZE8 - RSP_SEG_SIZE8 - \
				RSP_PDATA_SIZE8)

#define RSP_PDATA_OFFSET	(0)
#define RSP_SEG_OFFSET		(RSP_PDATA_OFFSET + RSP_PDATA_SIZE8)
#define RSP_PARAMETER_OFFSET	(RSP_SEG_OFFSET + RSP_SEG_SIZE8)
#define RSP_DLINPUT_OFFSET	(RSP_PARAMETER_OFFSET + RSP_PARAMETER_SIZE8)
#define RSP_ADPCMTABLE_OFFSET   (RSP_DLINPUT_OFFSET + RSP_DLINPUT_SIZE8)
#define RSP_BUFFER_OFFSET	(RSP_ADPCMTABLE_OFFSET + RSP_ADPCMTABLE_SIZE8)
#define RSP_YIELD_BUF_OFFSET    (RSP_BUFFER_OFFSET + RSP_BUFFER_SIZE8)
#define RSP_SCRATCH_OFFSET	(RSP_YIELD_BUF_OFFSET + RSP_YIELD_BUF_SIZE8)

/* During compilation, report an informative message about DMEM allocation: */
#ifdef _LANGUAGE_ASSEMBLY
#   define _DumpDMEMOffset(o,s)  				\
    .print 	#o						\
    .print 	"\t\t : %d\t%d bytes.\n", (DCACHEBASE + (o)), (s)

    .print	"--------------------------------------------------------------------\n"

    .print	__FILE__
    .print	" : Scratch space allocated is %d bytes.\n", RSP_SCRATCH_SIZE8
    .print	__FILE__
    .print	" : Program data segment is at %08x.\n", DCACHEBASE+RSP_PDATA_OFFSET
    .print	__FILE__
    .print	" : DMEM Map:\n"

     _DumpDMEMOffset(RSP_PDATA_OFFSET, RSP_PDATA_SIZE8)
     _DumpDMEMOffset(RSP_SEG_OFFSET, RSP_SEG_SIZE8)
     _DumpDMEMOffset(RSP_PARAMETER_OFFSET, RSP_PARAMETER_SIZE8)
     _DumpDMEMOffset(RSP_DLINPUT_OFFSET, RSP_DLINPUT_SIZE8)
     _DumpDMEMOffset(RSP_ADPCMTABLE_OFFSET, RSP_ADPCMTABLE_SIZE8)
     _DumpDMEMOffset(RSP_BUFFER_OFFSET, RSP_BUFFER_SIZE8)
     _DumpDMEMOffset(RSP_YIELD_BUF_OFFSET, RSP_YIELD_BUF_SIZE8)
     _DumpDMEMOffset(RSP_SCRATCH_OFFSET, RSP_SCRATCH_SIZE8)

    .print	"--------------------------------------------------------------------\n"

#   undef _DumpDMEMOffset
#endif

/*
 * define (byte) offsets for the parameter structure.
 */

#define RSP_PARAMETER_DMEMIN	0
#define RSP_PARAMETER_DMEMOUT	2
#define RSP_PARAMETER_COUNT	4
#define RSP_PARAMETER_VOLL	6
#define RSP_PARAMETER_VOLR	8
#define RSP_PARAMETER_DMOUTR	10
#define RSP_PARAMETER_DMAUXL	12
#define RSP_PARAMETER_DMAUXR	14
/*
 * the following parameters are assumed by the envelope
 * microcode to be on an 16-byte boundary (for lqv)
 */
#define RSP_PARAMETER_VOLTGTL	16
#define RSP_PARAMETER_VOLRATELM	18
#define RSP_PARAMETER_VOLRATELL	20
#define RSP_PARAMETER_VOLTGTR	22
#define RSP_PARAMETER_VOLRATERM	24
#define RSP_PARAMETER_VOLRATERL	26
#define RSP_PARAMETER_DRYAMT	28
#define RSP_PARAMETER_WETAMT	30

/*
 * The loop state address parameter is overlapped with the
 * volume parameters
 */
#define RSP_PARAMETER_LSTATE    16

#endif /* _aud_dmem_h_ */
