
/**************************************************************************
 *                                                                        *
 *               Copyright (C) 1994, Silicon Graphics, Inc.               *
 *                                                                        *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright  law.  They  may not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 *                                                                        *
 *************************************************************************/

 #
 # gdmem.h
 #
 # This file lays out the DMEM usage for the RSP gspFast3D tasks
 # and the gspLine3D tasks.
 #

#include <rcp.h>
#include <os.h>
#include <sptask.h>

 #
 # IMPORTANT NOTE:
 #
 # Many of the following fields require some alignment, for the ld/st to
 # work as efficiently as possible... Add this someday...
 #
 #


/*
 * Memory layout of DMEM:
 *
 * The strategy is to divide up DMEM into a bunch of known regions
 * that we can get to quickly to store/retrieve stuff.
 *
 * The order of things here is kind of important. Things that need
 * to be initialized via DMA should be near the top. Some buffers
 * require 64-bit alignment.
 *
 *      -------------------------------------------------
 *      | Program data from compiler...                 |     (must be first)
 *	|     overlays, constants, etc.  272 bytes      |
 *	|-----------------------------------------------|
 *	| RSP GFX State                                 |
 *	|                                 80 bytes      |
 *      |-----------------------------------------------|
 *	| RSP memory segment table:                     |
 *      |      16 x 4b = 		 64 bytes       |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Lights                                        |
 *	|                               384 bytes       |
 *	|-----------------------------------------------|
 *	| Viewport:			                |
 *	|                                16 bytes       |
 *	|-----------------------------------------------|
 *	| Fog factors:		                        |
 *	|                                 6 bytes       |
 *	|-----------------------------------------------|
 *	| padding		                        |
 *	|                                 2 bytes       |
 *	|-----------------------------------------------|
 *	| Display list stack:  10 deep	 40 bytes       |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Modelview Matrix top of stack:                | 64-bit aligned
 *	|      4x4 x 4b                                 |
 *	|              			 64 bytes       |
 *	|-----------------------------------------------|
 *	| Projection Matrix top of stack:               | 64-bit aligned
 *	|      4x4 x 4b                                 |
 *	|              			 64 bytes       |
 *	|-----------------------------------------------|
 *	| MP matrix: (Modelview * Projection)           |
 *	|      4x4 x 4b (doubled for vector register)   |
 *	|              			 64 bytes       |
 *	|-----------------------------------------------|
 *	| Points buffer:                640 bytes       |
 *	|                                               |
 *	| 16 points, @ 40 bytes                         |
 *	| (includes clip coords, screen, etc.)          |
 *	|                                               |
 *	|-----------------------------------------------|
 *	| Input (display list)		320 bytes       | 64-bit aligned
 *      |    40 cmds, @ 8bytes				|
 *	|-----------------------------------------------|
 *	| Input (data)				        | 64-bit aligned
 *	|    				256 bytes       |
 *	| (needs to be big enough to hold 16 pts, etc.) |
 *	|-----------------------------------------------|
 *	| setup tmp			 96 bytes       |
 *	|-----------------------------------------------|
 *	| clip tmp			160 bytes       |
 *	|-----------------------------------------------|
 *	| Output to RDP:	       			| 64-bit aligned
 *	|    6 nasty triangles x 160b+                  |
 *	|    (cycle memory)            1024 bytes	|
 *	|-----------------------------------------------|
 *	| Scratch space for intermediate results        |
 *	| Holds clipped vertices during clip and setup. |
 *	|                                               |
 *	|                               480 bytes       |
 *      -------------------------------------------------
 * 
 */

/*
 * Memory addressing Strategy:
 *
 * All dmem will be addressed relative to register zero which is 
 * equivalent to the top of dmem.
 * Memory is allocated in this file by adding bytes, halfs, words, etc.
 * If alignment is required attempt to align by hand and use a 
 *      .bound <byte_alignment>
 * where <byte_alignment> is the number of bytes to align to.  This will
 * supply an error message when alignment is incorrect.  To force alignment use
 *      .align <byte_alignment>
 * which will force alignment by adding pad bytes.
 * An error will occur if dmem is overflowed.
 *
 */

     .data

 #################################################################
 ############## BEGIN INITIALIZING AND DEFINING DMEM USE #########
 #################################################################

	.print	"----------------------------------------------------------\n"
RSP_PDATA_OFFSET:

 #################################################################
 ############## OVERLAY TABLE ####################################
 #################################################################
 #
 # Program module overlay table. Offsets and sizes are filled in by
 # the 'buildtask' utility, destinations are the responsibility of
 # the ucode.
 #
 # OVERLAY_OFFSET:  offset from beginning of microcode in RDRAM and
 #		      in .o file (filled in by buildtask).
 # OVERLAY_SIZE:    length of overlay in bytes (filled in by buildtask).
 # OVERLAY_DEST:    where in IMEM to put the overlay (filled in by 
 #                    microcode).
 #
 # The overlay table must be the first thing in DMEM.
 # The 1st overlay must be the initial code.
 #
	.bound	0x80000000

OVERLAY_TAB_OFFSET:

#define OVERLAY_OFFSET  0
#define OVERLAY_SIZE    4
#define OVERLAY_DEST    6

 #==========================================
 #============= MAIN CODE OVERLAY ==========
 #==========================================
OVERLAY_0_OFFSET:
    # main module.
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   0x04001080      # destination

 #==========================================
 #============= NEWTONS OVERLAY ============
 #==========================================
OVERLAY_1_OFFSET:
OVERLAY_NEWTON:
    # Newton's module laid over boot code.
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   0x04001000      # destination

 #==========================================
 #============= CLIPPING OVERLAY ===========
 #==========================================
#if defined(FASTLIGHT3D)||defined(CLIP_ALONE)||defined(FLIGHT)
#else
#define startClip 0		# bogus startClip if not using overlays
#endif

OVERLAY_2_OFFSET:
OVERLAY_CLIP:
    # clip code
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   startClip       # destination

 #==========================================
 #============= LIGHTING OVERLAY ===========
 #==========================================
OVERLAY_3_OFFSET:
OVERLAY_LIGHT:
    # light code
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
        .half   startClip       # destination

 #==========================================
 #============= DONE OVERLAY ===============
 #==========================================
OVERLAY_4_OFFSET:
OVERLAY_DONE:
    # TaskDone and Yield code
        .word   0x0             # offset from beginning of code
        .half   0x0             # size in bytes (-1)
TASKYIELD:
        .half   startClip       # destination

 ### ADD NEW OVERLAY TABLE ENTRIES HERE

 #
 #
 ############## END OF OVERLAY TABLE ##############################

 #################################################################
 ############## QUAD CONSTANTS ###################################
 #################################################################
 #
 # Constants. Setup a bunch of constants at compile-time. Be
 # sure to #define the macros and offsets needed to access them.
 #
 #################################################################
 #
 #
 # Initialize vconst; each element a different scalar constant...
 #

	.bound	8
VCONST_SCREENCLAMP:
	.half	4090		# +xy clamp to +1000 (*4)
	.half	-4090		# -xy clamp to -1000 (*4)

	.half	0x7fff		# +z clamp max
	.half	0x0000		# -z clamp to 0

	.align	16
	.bound	16

VCONST_OFFSET:
        .half   0x0000          # 0
        .half   0x0001          # 1
        .half   0x0002          # 2
        .half   0xffff          # -1
        .half   0x4000          # 1/4.0 in fixed-point fraction
        .half   0x0004          # 4.0, for screen point scaling.
        .half   0x0633          # (2047-4e0) for screen-space clamping.
        .half   0x0200          # 1/512.0 for pixel-packed loads
 #
 # Initialize vconst; each element a different scalar constant...
 #
#if defined(LINE3D)
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
        .half   0x0010          #
        .half   0x0020          # for z scale
        .half   0x8000          #
        .half   0x0755		# 1877=(2048-640)/0.75 for slope clamp
        .half   0x0000          # not used
#elif defined (FAST3D)
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
 #	.half   0x00fd          # 1/128 * 0.990 *.5 (sqrt correction) (.5 for sf
	.half   0x0040          # 1/128 * .5 * .25 (sqrt correct) (.5 for sf
        .half   0x0020          # for z scale
        .half   0x8000          # test bow-tie fix
	.half	0x01cc		# 460 = 2048/3 for slope clamp
				# WARNING: used in lighting.  Tell Acorn if this
				# value becomes >0x200 or <0x100.

        .half   0xcccc          # W multiplier(0.8). 1/w ranges from 0 to 0.8 
#elif defined (SPRITE2D)
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0x1000          # Multiply by 4096
        .half   0x0008          # mult by 8 for LOD computation.
 #	.half   0x00fd          # 1/128 * 0.990 *.5 (sqrt correction) (.5 for sf
	.half   0x0400          # 1/128 * .5 * .25 (sqrt correct) (.5 for sf
        .half   0x0020          # for z scale
        .half   0x8000          # test bow-tie fix
	.half	0x0080		# multiply by 128
        .half   0xcccc          # W multiplier(0.8). 1/w ranges from 0 to 0.8 
#else
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
 #	.half   0x00fd          # 1/128 * 0.990 *.5 (sqrt correction) (.5 for sf
	.half   0x0040          # 1/128 * .5 * .25 (sqrt correct) (.5 for sf
        .half   0x0020          # for z scale
        .half   0x8000          # test bow-tie fix
	.half	0x01cc		# 460 = 2048/3 for slope clamp
				# WARNING: used in lighting.  Tell Acorn if this
				# value becomes >0x200 or <0x100.

        .half   0xcccc          # W multiplier(0.8). 1/w ranges from 0 to 0.8 
#endif /* FAST3D */



 #
 # Initialize OpenGL correction scale
 #
VOPENGL_OFFSET:
        .half   0x0001          # x
        .half   0xffff          # y
        .half   0x0001          # z
        .half   0x0001          # w
        .half   0x0001          # x
        .half   0xffff          # y
        .half   0x0001          # z
        .half   0x0001          # w

 #
 # Initialize constant vector for Newton's iteration
 #
VNEWT_OFFSET:
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # MUST BE 2 !
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # MUST BE 2 !
 #
 #
 ############## END OF CONSTANTS ##################################

 #################################################################
 ############## CLIPPING & LIGHTING ##############################
 #################################################################
 #
 # static tables and masks for clipping & lighting
 #
 #################################################################
 #
	.bound	16
CLIP_SELECT:				# NOTE: MOVEWORD command alters these
        .word   0x00010000              # -x plane (1 0 0  1)
        .word   0x00000001              # -x
        .word   0x00000001              # -y plane (0 1 0  1)
        .word   0x00000001              # -y
        .word   0x00010000              # +x plane (1 0 0 -1)
        .word   0x0000ffff              # +x
        .word   0x00000001              # +y plane (0 1 0 -1)
        .word   0x0000ffff              # +y
        .word   0x00000000              # +z plane (0 0 1 -1)
        .word   0x0001ffff              # +z
        .word   0x00000000              # -z plane (0 0 1  1)
#ifdef NEAR_CLIP_OFF
        .word   0x00000001              # -z   if NEARCLIP_OFF: (0 0 0 1)
#else /* NEAR_CLIP_OFF */
        .word   0x00010001              # -z   if NEARCLIP_OFF: (0 0 0 1)
#endif /* NEAR_CLIP_OFF */

	.bound	8
#if defined(FASTLIGHT3D)||defined(CLIP_ALONE)||defined(FLIGHT)
DOLIGHT:
        .half   doLight
#else /* FASTLIGHT3D or CLIP_ALONE */
DOLIGHT:
        .half   0               # pad
#endif /* FASTLIGHT3D or CLIP_ALONE */
        .half   0x7fff          # 1-.0x0001
        .half   0x571d          # 0x571d for arccos
        .half   0x3a0c          # 0x3a0b+.0x0001 for arccos

	.bound 2
CLIP_MASKS_TABLE:
CLIPMASKS:
        .half   0x0001			# -x plane
        .half   0x0002			# -y plane
        .half   0x0100			# +x plane
        .half   0x0200			# +y plane
        .half   0x4000			# +z plane
        .half   0x0040			# -z plane (not always used)

ANCHOR:
        .half   0x0000
TASKDONE:
#if defined(FASTLIGHT3D)||defined(CLIP_ALONE)||defined(FLIGHT)
	.half	taskDone
#else /* FASTLIGHT3D or CLIP_ALONE */
	.half	0		# pad
#endif /* FASTLIGHT3D or CLIP_ALONE */

 #
 #
 ############## END OF CLIPPING & LIGHTING ########################

 #################################################################
 ############## SCALAR CONSTANTS #################################
 #################################################################
 #
 # Constants. Setup a bunch of constants at compile-time. Be
 # sure to #define the macros and offsets needed to access them.
 #
 #################################################################
 #

 #
 # a common necessary mask value
 #

  	.bound	4
SEGADDR_MASK_OFFSET:
          .word   0x00ffffff      # segment address mask.

 #
 #
 ############## END OF SCALAR CONSTANTS ##########################

 #################################################################
 ############## JUMP TABLES ######################################
 #################################################################
 #
 # Jump Tables: These DMEM jump tables are only 16 bits, that's
 # plenty, given only 4K of IMEM...
 #
 # Jump tables should be 'complete', any new command in the
 # mbi should be included here, even if it's a jump to GfxDone
 # in some cases (a no-op).
 #
 # Notice also that a bunch of #ifdef's are used to disable
 # certain commands for certain versions of the microcode.
 # Patching the 'GfxDone' label into the table makes a command
 # be a no-op.
 #
 #################################################################
 #

 #====================================================================
 # setup a jump table for the optypes:
 # This table is the high-level handler for the display list commands.
 # Based on the upper 2 bits, each different type of command is handled
 # differently.
 #====================================================================
	.bound	2

OPTYPE_JMP_OFFSET:
        .half   doDMA
GFXDONE:
        .half   GfxDone         # dummy label, invalid op type
        .half   doIMM
        .half   doRDP

 #====================================================================
 # setup a jump table for the DMA ops:
 #====================================================================
DMA_JMP_OFFSET:
#ifndef SPRITE2D
        .half   GfxDone         # all 0's is G_SPNOOP
        .half   case_G_MTX
        .half   GfxDone         # case_G_MTX_STATE not implemented
        .half   case_G_MOVEMEM  # viewport and light
        .half   case_G_VTX
        .half   GfxDone         # case_G_TRIN not implemented
        .half   case_G_DL
        .half   GfxDone         # not implemented
        .half   GfxDone         # not implemented
	.half   GfxDone
#else
        .half   GfxDone         # all 0's is G_SPNOOP
        .half   GfxDone   
        .half   GfxDone         # case_G_MTX_STATE not implemented
        .half   GfxDone         # viewport and light
        .half   GfxDone   
        .half   GfxDone         # case_G_TRIN not implemented
        .half   case_G_DL
        .half   GfxDone         # not implemented
        .half   GfxDone         # not implemented
        .half   GfxDone         # Just do the dma of the sprite structure
                                # nothing else
#endif

 #====================================================================
 # setup a jump table for the IMM ops:
 # IMPORTANT: ADD NEW OPCODES AT TOP OF THIS TABLE
 #====================================================================
IMM_JMP_OFFSET:

        .half   case_G_RDPHALF_CONT
        .half   case_G_RDPHALF_2
        .half   case_G_RDPHALF_1
#ifdef LINE3D
        .half   case_G_LINE3D
#else
        .half   GfxDone              # Lines not grokked in triangle code
#endif

        .half   case_G_CLEARGEOMETRYMODE
        .half   case_G_SETGEOMETRYMODE
        .half   case_G_ENDDL
        .half   case_G_SETOTHERMODE_L
        .half   case_G_SETOTHERMODE_H
        .half   case_G_TEXTURE
        .half   case_G_MOVEWORD
#ifndef SPRITE2D
        .half   case_G_POPMTX
        .half   case_G_CULLDL
#else
        .half   case_G_SPRITE2D_DRAW
        .half   case_G_SPRITE2D_SCALEFLIP
#endif
#if defined(LINE3D) || defined (FAST3D)
        .half   case_G_TRI1   # Tri's grokked differently in line microcoode
#else
	.half   GfxDone
#endif

 # ADD NEW IMM OPCODES ONLY AT TOP OF LIST, NOT HERE

	.symbol NUMBER_OF_IMM,  14
	.symbol IMM_JMP_ADD,    (IMM_JMP_OFFSET)+(((G_IMMFIRST)+(NUMBER_OF_IMM)+1)*2)

 #====================================================================
 # no jump table for the RDP ops is needed.
 #====================================================================

 #
 #
 ############## END OF JUMP TABLES ################################

 #################################################################
 ############## LABEL CONSTANTS ##################################
 #################################################################
 #
 # Labels for loading jump addresses
 #
 #################################################################
 #

	.bound 2

#if defined(NODATA)
 #==========================================
 #============= DUMMY LABELS ===============
 #==========================================
CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0
CLIPDRAWLOOP:
        .half   0
DOCLIP:
        .half   0
NEXTCLIP:
        .half   0

 #==========================================
 #============= REAL LABELS ================
 #==========================================
#elif defined(LINE3D)

CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0
CLIPDRAWLOOP:
        .half   0

DOCLIP:
        .half   doClip
NEXTCLIP:
        .half   nextClip

#elif defined(FAST3D)

CLIP_STATE_TABLE:
        .half   foundIn
FOUND_OUT:
        .half   foundOut
        .half   foundFirstIn
        .half   foundFirstOut

CLIPDRAWLOOP:
        .half   clipDrawLoop

DOCLIP:
        .half   doClip
NEXTCLIP:
        .half   nextClip

#elif defined(SPRITE2D)

CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0

CLIPDRAWLOOP:
        .half   0
DOCLIP:
        .half   0
NEXTCLIP:
        .half   0
#else
 #==========================================
 #============= DUMMY LABELS ===============
 #==========================================
CLIP_STATE_TABLE:
        .half   0
FOUND_OUT:
        .half   0
        .half   0
        .half   0
CLIPDRAWLOOP:
        .half   0
DOCLIP:
        .half   0
NEXTCLIP:
        .half   0
#endif /* NODATA */

DMAWAITDL:
	.half	DMAWaitDL

 #
 #
 ############## END OF LABELS #####################################

PROGRAM_PAD_OFFSET:

 ######################################################################
 ############## DMEM STATE ############################################
 ######################################################################
 #
 # Up to this point, we have been just filling in compile-time
 # structures. The rest of this initialization sets up the DMEM
 # state for the beginning of the graphics task.
 #
 # Alignment is important, changes above might screw up initialization
 # in a bad way...
 #
 ######################################################################
 #
 #
 # initialize RSP GFX state.
 #
	.bound	2
RETURNJUMP:
        .half   0x0000

	.align	4
	.bound	4
RSP_STATEP_YIELD_STORE:
	.word	0x0			# where to store yield dmem

	.bound	4
RSP_STATEP_RDPHALF:
        .word   0x0			# RSP_STATE_RDPHALF

	.align	8
	.bound	8
RSP_STATE_OFFSET:

	.bound	4
RSP_STATEP_PERSPNORM_H:			# altered by MOVEWORD command
        .half   0x0000                  # PERSPNORM tophalf (always 0)
RSP_STATEP_PERSPNORM:
        .half   0xffff                  # RSP_STATE_PERSPNORM

	.align	4
	.bound	4
RSP_STATEP_RENDER:
        .half   0x0 	                # RSP_STATE_RENDER
RSP_STATEP_RENDER_L:
        .byte   0x0                     # RSP_STATE_RENDER
RSP_STATEP_TRI:
        .byte   0x0                     # RSP_STATE_RENDER

	.bound	8
RSP_STATEP_OTHER_H:
        .byte   G_RDPSETOTHERMODE       # RSP_STATE_OTHER_H
        .byte   0x08                    # RSP_STATE_OTHER_H
        .byte   0x0c                    # RSP_STATE_OTHER_H
        .byte   0xff			# blend mask is fixed
RSP_STATEP_OTHER_L:
        .word   0x0                     # RSP_STATE_OTHER_L

        .bound  8
RSP_STATEP_TEX_CMD:
        .byte   0x0			# RSP_STATE_TEX_CMD
RSP_STATEP_TEX_LOD:
        .byte   0x0			# RSP_STATE_TEX_LOD
RSP_STATEP_TEX_TILE:
        .byte   0x0                     # RSP_STATE_TEX_TILE
RSP_STATEP_TEX_PAD:
        .byte   0x0
RSP_STATEP_TEX_SCALE_S:
        .half   0x0                     # RSP_STATE_TEX_SCALE_S
RSP_STATEP_TEX_SCALE_T:
        .half   0x0                     # RSP_STATE_TEX_SCALE_T

	.bound	4
RSP_STATEP_FIFO_OUTP:
RSP_STATEP_DRAM_OUTP:
        .word   0x0                     # RSP_STATE_DRAM_OUTP

RSP_STATEP_L_LEN:			# altered by MOVEWORD command
        .word   0x80000040              # # lights * RSP_L_LEN (1 light default)

	.bound	4
RSP_STATEP_DRAM_STACK:
        .word   0x0                     # RSP_STATE_DRAM_STACK

	.bound	4
RSP_STATEP_MMTX_STACK_P:
        .word   0x0                     # RSP_STATE_MMTX_STACK_P

RSP_STATEP_TXTR_ATTR:				# Texture Attributes
RSP_STATEP_XOFF:
	.half	0x4000			# x offset
RSP_STATEP_YOFF:
	.half	0x4000			# y offset
RSP_STATEP_HCURVE:
	.half	0			# horizontal curve
RSP_STATEP_VCURVE:
	.half	0			# vertical curve
	.bound	16			# MUST BE LAST 4 half'S OF QUAD


        .bound 8
RSP_STATEP_DRAM_OUT_LENP:		# RSP_STATE_DRAM_OUT_LENP
        .word   0x0

#ifdef LINE3D
	.bound	4
RSP_STATEP_SCISSOR_XH:
	.half   0x0000			# RSP_STATE_SCISSOR_XH
RSP_STATEP_SCISSOR_YH:		
	.half   0x0000  	        # RSP_STATE_SCISSOR_YH
RSP_STATEP_SCISSOR_XL:	
	.half   0x0000  	        # RSP_STATE_SCISSOR_XL
RSP_STATEP_SCISSOR_YL:	
	.half   0x0000	              	# RSP_STATE_SCISSOR_YL
#endif /* LINE3D */

#ifdef FAST3D
	.half	0x0000			# pad
	.half	0x0000			# pad
	.half	0x0000			# pad
	.half	0x0000			# pad
#endif

#ifdef SPRITE2D
	.half	0x0000			# pad
	.half	0x0000			# pad
	.half	0x0000			# pad
	.half	0x0000			# pad
#endif


        .align 8
        .bound 8
RSP_STATEP_FIFO_BUF_TOP:
RSP_STATEP_DRAM_OUT_LEN:
        .word   0x0                     # RSP_STATE_DRAM_OUT_LEN
RSP_STATEP_FIFO_BUF_END:
        .word   0x0                     # is a 64-bit counter

	.bound	2
RETURNJUMP2:
        .half   0x0000

	.bound	1
RSP_STATEP_DL_N:
        .byte   0x0                     # RSP_STATE_DL_N

	.align	4
	.bound	4
RSP_STATEP_MMTX_STACK_MAX:
        .word   0x0                     # RSP_STATE_MMTX_STACK_MAX


    
    .symbol RSP_STATE_YIELD_STORE,    (RSP_STATEP_YIELD_STORE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DL_N, 	      (RSP_STATEP_DL_N)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_OTHER_H, 	      (RSP_STATEP_OTHER_H)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_OTHER_L, 	      (RSP_STATEP_OTHER_L)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_RENDER, 	      (RSP_STATEP_RENDER)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_RENDER_L,       (RSP_STATEP_RENDER_L)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TRI, 	      (RSP_STATEP_TRI)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_STACK,     (RSP_STATEP_DRAM_STACK)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_MMTX_STACK_P,   (RSP_STATEP_MMTX_STACK_P)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_MMTX_STACK_MAX, (RSP_STATEP_MMTX_STACK_MAX)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_CMD, 	      (RSP_STATEP_TEX_CMD)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_LOD, 	      (RSP_STATEP_TEX_LOD)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_TILE,       (RSP_STATEP_TEX_TILE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_SCALE_S,    (RSP_STATEP_TEX_SCALE_S)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_TEX_SCALE_T,    (RSP_STATEP_TEX_SCALE_T)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_FIFO_OUTP,      (RSP_STATEP_FIFO_OUTP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_FIFO_BUF_TOP,   (RSP_STATEP_FIFO_BUF_TOP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_FIFO_BUF_END,   (RSP_STATEP_FIFO_BUF_END)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_OUTP,      (RSP_STATEP_DRAM_OUTP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_OUT_LEN,   (RSP_STATEP_DRAM_OUT_LEN)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_DRAM_OUT_LENP,  (RSP_STATEP_DRAM_OUT_LENP)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_L_LEN, 	      (RSP_STATEP_L_LEN)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_PERSPNORM,      (RSP_STATEP_PERSPNORM)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_RDPHALF,	      (RSP_STATEP_RDPHALF)-(RSP_STATE_OFFSET)
#ifdef LINE3D
    .symbol RSP_STATE_SCISSOR_XH,     (RSP_STATEP_SCISSOR_XH)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_SCISSOR_XL,     (RSP_STATEP_SCISSOR_XL)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_SCISSOR_YH,     (RSP_STATEP_SCISSOR_YH)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_SCISSOR_YL,     (RSP_STATEP_SCISSOR_YL)-(RSP_STATE_OFFSET)
#endif /* LINE3D */
    .symbol RSP_STATE_HCURVE,	      (RSP_STATEP_HCURVE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_VCURVE,	      (RSP_STATEP_VCURVE)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_XOFF,	      (RSP_STATEP_XOFF)-(RSP_STATE_OFFSET)
    .symbol RSP_STATE_YOFF,	      (RSP_STATEP_YOFF)-(RSP_STATE_OFFSET)

 #
 #
 ############## END OF RSP STATE ##################################


 ##################################################################
 ############## MEMORY SEGMENT TABLE ##############################
 ##################################################################
 #
 # initialize memory segment table.
 # altered by MOVEWORD command
 #
	.align	4
	.bound	4
RSP_SEG_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
 #
 #
 ############## END OF MEMORY SEGMENT TABLE #######################

 ##################################################################
 ############## REFLECTANCE TABLE #################################
 ##################################################################
 #
 #
 # define offsets for the light structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |S.x|S.y|S.z|000|S.x|S.y|S.z|000|000|000|000|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |T.x|T.y|T.z|000|T.x|T.y|T.z|000|TVx|TVy|TVz|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |TMx|TMy|TMz|000|TMx|TMy|TMz|000|000|000|000|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |D.x|D.y|D.z|000|D.x|D.y|D.z|000|SVx|SVy|SVz|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #  |SMx|SMy|SMz|000|SMx|SMy|SMz|000|000|000|000|000|000|000|000|000|
 #  -----------------------------------------------------------------
 #
 # S.xyz = S select vector (always 0x80000000 = [-1  0 0])
 # T.xyz = T select vector (always 0x00800000 = [ 0 -1 0])
 # TVxyz = T direction in Viewspace (Up vector)
 # TMxyz = T direction in Modelspace (calculated by microcode)
 # SVxyz = S direction in Viewspace (Right vector)
 # SMxyz = S direction in Modelspace (calculated by microcode)
 # D.xyz = Dummy color (must always be 0x00000000 = [0 0 0])
 # 
 #
#define RSP_R_SCALE     0
#define RSP_R_DIR_VIEW  8
#define RSP_R_PAD       12
#define RSP_R_DIR       16


	.align	16
	.bound	16	/* must be quad aligned */
RSP_LIGHTS_OFFSET:
RSP_SELECT_S:
        .word   0x80000000      # S select vector
        .word   0x80000000      # S select vector
        .word   0x0             # pad
        .word   0x0             # pad

RSP_R_LOOKATX:
        .word   0x00800000      # T select vector
        .word   0x00800000      # T select vector copy
        .word   0x7f000000      # reflectance direction (world) T (x)
        .word   0x0             # pad
        .word   0x0             # reflectance direction (modeling) T
        .word   0x0             # reflectance direction copy
        .word   0x0             # pad
        .word   0x0             # pad

RSP_R_LOOKATY:
        .word   0x00000000      # dummy color (must be 0)
        .word   0x00000000      # dummy color (must be 0)
        .word   0x007f0000      # reflectance direction (world) S (y)
        .word   0x0             # pad
        .word   0x0             # reflectance direction (modeling) S
        .word   0x0             # reflectance direction copy
        .word   0x0             # pad
        .word   0x0             # pad
 #
 #
 ############## END OF REFLECTANCE TABLE ##########################

 ### NOTE: DO NOT PUT ANYTHING BETWEEN THE REFLECTANCE AND LIGHT TABLES

 ##################################################################
 ############## LIGHTING TABLE ####################################
 ##################################################################
 #
 # IMPORTANT!!! THIS MUST IMMEDIATELY FOLLOW THE REFLECTANCE TABLE!!!
 #
 # define offsets for the light structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |c.r|c.g|c.b|   |c.r|c.g|c.b|   |w.x|w.y|w.z|   |   |   |   |   |
 #  ----------------------------------------------------------------|
 #  |m.x|m.y|m.z|   |m.x|m.y|m.z|   |   |   |   |   |   |   |   |   |
 #  ----------------------------------------------------------------|
 #
 # c.r   light color, red componant    (supplied vi MOVEMEM command)
 # c.g   light color, green componant  (supplied vi MOVEMEM command)
 # c.b   light color, blue componant   (supplied vi MOVEMEM command)
 # w.x   light direction, world coords (supplied vi MOVEMEM command)
 # w.y   light direction, world coords (supplied vi MOVEMEM command)
 # w.z   light direction, world coords (supplied vi MOVEMEM command)
 # m.x   light direction, model coords (calculated by the microcode)
 # m.y   light direction, model coords (calculated by the microcode)
 # m.z   light direction, model coords (calculated by the microcode)
 # blank pad, don't care (can be any value)
 # 
 # There are 2 copies of the light color and 2 copies of the modeling
 # coordinate light direction.
 #
 # light direction is a vector pointing from the object towards the light.
 #
 # NOTE: the last light in the table is the ambient light of which only c.r,
 #       c.g, and c.b are used.
 #
 #
#define RSP_L_COL       0
#define RSP_L_DIR_VIEW  8
#define RSP_L_PAD       12
#define RSP_L_DIR       16
#define RSP_L_LEN       32

	.bound	16	/* must be quad aligned. */
RSP_L_0:
RSP_LIGHT_COL:
        .word   0x0             # light #1 color (black)
        .word   0x0             # light #1 color copy
        .word   0x0             # light #1 direction (world)
        .word   0x0             # pad
        .word   0x0             # light #1 direction (modeling)
        .word   0x0             # light #1 direction copy
 #	.word   0x0             # pad
 #	.word   0x0             # pad

VCONST3_OFFSET:
	.half	0xe001		# min clamp for lighting direction
	.half	0x1fff		# max clamp for lighting direction
	.half	4		# multiplier after clamp
	.half	0		# pad

RSP_L_1:
        .word   0xFF000000      # ambient color (red)
        .word   0xFF000000      # ambient color copy
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0             # pad
        .word   0x0             # pad
RSP_L_2:
        .word   0x0             # light #2 (uninitialized)
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0             # pad
        .word   0x0             # pad
RSP_L_3:
        .word   0x0             # light #3 (uninitialized)
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0             # pad
        .word   0x0             # pad
RSP_L_4:      			# light #4 (initialized to magic values)
        .word   0x52535020
        .word   0x53572056
        .word   0x65727369
        .word   0x6f6e3a20
        .word   0x322e3048	# 2.0H
        .word   0x2c203032	# , 02
        .word   0x2d31322d	# -12-
        .word   0x39370053	# 97
RSP_L_5:      			# light #5 (initialized to magic values)
        .word   0x47492055
        .word   0x36342047
        .word   0x46582053
        .word   0x57205445
        .word   0x414d3a20
        .word   0x5320416e
        .word   0x64657273
        .word   0x6f6e2c20
RSP_L_6:             		# light #6 (initialized to magic values)
        .word   0x53204361
        .word   0x72722c20
        .word   0x48204368
        .word   0x656e672c
        .word   0x204b204c
        .word   0x75737465
        .word   0x722c2052
        .word   0x204d6f6f
RSP_L_7:             		# light #7 (initialized to magic values)
        .word   0x72652c20
        .word   0x4e20506f
        .word   0x6f6c6579
        .word   0x2c204120
        .word   0x5372696e
        .word   0x69766173
        .word   0x616e0a00
        .word   0x00000000

	.symbol RSP_L_BASE,     (RSP_L_0)-((RSP_L_LEN)*2)
	.symbol RSP_L_NUM,      RSP_STATEP_L_LEN

 #
 #
 ############## END OF LIGHTING TABLE #############################

 ### NOTE: DO NOT PUT ANYTHING BETWEEN THE LIGHTING AND MOVEMEM TABLES

 ##################################################################
 ############## MOVEMEM TABLE #####################################
 ##################################################################
 # This is a table of locations to store quad words which have been
 # DMA'd with the MOVEMEM DMA command.  The MOVEMEM command
 # specifies an index into this table to indicate where the 4 words
 # of DMA'd data should be stored.

	.bound	2
MOVEMEM_TBL:
        .half   RSP_VIEWPORT_OFFSET     # viewport address
        .half   RSP_R_LOOKATX           # lookat X vector in world space
        .half   RSP_R_LOOKATY           # lookat Y vector in world space
        .half   RSP_L_0                 # light 0
        .half   RSP_L_1                 # light 1
        .half   RSP_L_2                 # light 2
        .half   RSP_L_3                 # light 3
        .half   RSP_L_4                 # light 4
        .half   RSP_L_5                 # light 5
        .half   RSP_L_6                 # light 6
        .half   RSP_L_7                 # light 7
	.half	RSP_STATEP_TXTR_ATTR	# Texture Attributes
	.half	RSP_CURR_MPMTX_OFFSET_2 # Matrix part 2
	.half	RSP_CURR_MPMTX_OFFSET_3 # Matrix part 3
	.half	RSP_CURR_MPMTX_OFFSET_4 # Matrix part 4
	
MOVEWORD_TBL:
	.half	RSP_CURR_MPMTX_OFFSET	# matrix IMPORTANT! Must be first! (for movemem)
	.half   RSP_L_NUM               # number of active lights * RSP_L_LEN
	.half	CLIP_SELECT		# clip lookup table
	.half	RSP_SEG_OFFSET		# segment table
	.half	RSP_FOG_FACTOR		# fog multipliers
	.half	RSP_LIGHT_COL		# light colors
	.half	RSP_POINTS_OFFSET	# points buffer
	.half	RSP_STATEP_PERSPNORM_H  # perspnorm factor
 #
 #
 ############## END OF MOVEMEM TABLE ##############################

 ##################################################################
 ############## MORE CONSTS #######################################
 ##################################################################
 #
 #
 #
 ############## END OF MORE CONSTS ################################

 ##################################################################
 ############## VIEWPORT ##########################################
 ##################################################################
 #
 # define offsets for the viewport structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |scal.x |scal.y |scal.z |       |trns.x |trns.y |trns.z |        |
 #  -----------------------------------------------------------------
 #
 # These guys have 1-bit of fraction to them. This is factored out
 # during the transform.
 #
 #
#define RSP_VIEWPORT_SX         0
#define RSP_VIEWPORT_SY         2
#define RSP_VIEWPORT_SZ         4
#define RSP_VIEWPORT_TX         8
#define RSP_VIEWPORT_TY         10
#define RSP_VIEWPORT_TZ         12

	.align	16
	.bound	16
RSP_VIEWPORT_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
 #
 #
 ############## END OF VIEWPORT ###################################

 ##################################################################
 ############## FOG FACTOR ########################################
 ##################################################################
 #
	.bound	16
RSP_FOG_FACTOR:				# NOTE: altered by MOVEWORD
	.half	0x0100	# multiplier
	.half	0x0000	# add
	.half	0x00ff	# clamp
 #
 #
 ############## END OF FOG FACTOR #################################

 ##################################################################
 ############## DISPLAY LIST STACK ################################
 ##################################################################
 #

RSP_DLSTACK_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
 #
 #
 ############## END OF DISPLAY LIST STACK #########################

 ##################################################################
 ############## END OF INITIALIZED DATA############################
 ##################################################################
	.align	16
	.bound	16
RSP_END_INITIALIZE:

 ##################################################################
 ############## MATRICES ##########################################
 ##################################################################
 #
	.bound	16	
RSP_CURR_MMTX_OFFSET:	/* 64 bytes per matrix */
        .space	64

RSP_CURR_PMTX_OFFSET:	/* 64 bytes per matrix */
	.space	64


RSP_CURR_MPMTX_OFFSET:	/* 64 bytes per matrix */
	.space	16	/* 1st quad word */
RSP_CURR_MPMTX_OFFSET_2:
	.space	16	/* 2nd quad word */
RSP_CURR_MPMTX_OFFSET_3:
	.space	16	/* 3rd quad word */
RSP_CURR_MPMTX_OFFSET_4:
	.space	16	/* 4th quad word */
      #	.space	64	/* 64 bytes per matrix */
 #
 #
 ############## END OF MATRICES ###################################

 ##################################################################
 ############## POINTS BUFFER #####################################
 ##################################################################
 #
 #
 # NOTE:
 # Since we try to always process two points at a time in the vertex
 # and shading, we should interleave pairs of points in the points
 # buffer, so that we can load pairs of things in one instruction.
 #
 # Wed Aug 17 14:44:01 PDT 1994
 #
 #
 #
 #
 # define offsets for the points buffer structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  | x.int | y.int | z.int | w.int | x.frac| y.frac| z.frac| w.frac|
 #  ----------------------------------------------------------------|
 #  | r | g | b | a |   s   |   t   | xscr  | yscr  | zscr.i|zscr.f |
 #  -----------------------------------------------------------------
 #  | 1/w.i | 1/w.f |  0c0c |flg| 00|
 #  ---------------------------------
 #
 #  depending on flag, color could be normal (nx, ny, nz).
 #
 # 32-bit 3D xyzw might be overkill; but we do need the resolution for z,
 # and certainly for intermediate computations.
 #
 #
#define RSP_PTS_X_INT           0
#define RSP_PTS_Y_INT           2
#define RSP_PTS_Z_INT           4
#define RSP_PTS_W_INT           6
#define RSP_PTS_X_FRAC          8
#define RSP_PTS_Y_FRAC          10
#define RSP_PTS_Z_FRAC          12
#define RSP_PTS_W_FRAC          14
#define RSP_PTS_R_NX            16
#define RSP_PTS_G_NY            17
#define RSP_PTS_B_NZ            18
#define RSP_PTS_A               19
#define RSP_PTS_S               20
#define RSP_PTS_T               22
#define RSP_PTS_XS              24
#define RSP_PTS_YS              26
#define RSP_PTS_ZS              28
#define RSP_PTS_ZSF             30
#define RSP_PTS_INVW_INT        32
#define RSP_PTS_INVW_FRAC       34
#define RSP_PTS_CC              36
#define RSP_PTS_FLAG            38
#define RSP_PTS_LEN             40

RSP_POINTS_OFFSET:
	.space	640	/* 40 bytes * 16 points */
 #
 #
 ############## END OF POINTS BUFFER ##############################

 ##################################################################
 ############## I/O and SCRATCH BUFFERS ###########################
 ##################################################################
 #
RSP_DLINPUT_OFFSET:
	.space	320	/* load display lists in 320 byte chunks */

 ##################################################################
 ############## SPRITE BUFFER #####################################
 ##################################################################
 #
 #
 # NOTE:
 # The sprite structure is only used for the Sprite Microcode. The
 # sprite structure data are DMA'd into the Input data area in DMEM.
 #
 # Thu Apr 18 16:09:36 PDT 1996
 #
 #
 #
 #
 # define offsets for the sprite data structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #
 #

#define RSP_SP_SOURCEP         0
#define RSP_SP_TLUTP           4
#define RSP_SP_STRIDE          8
#define RSP_SP_SUBWIDTH        10
#define RSP_SP_SUBHEIGHT       12
#define RSP_SP_SOURCETYPE      14
#define RSP_SP_SOURCEBITSIZE   15
#define RSP_SP_SOURCEOFFSETS   16
#define RSP_SP_SOURCEOFFSETT   18

#define RSP_SP_SCALEX          20
#define RSP_SP_SCALEY          22
#define RSP_SP_FLIPX           24
#define RSP_SP_FLIPY           25

#define RSP_SP_PSCREENX        26
#define RSP_SP_PSCREENY        28




RSP_INPUT_OFFSET:
	.space	256	/* 256 bytes of DMA input buffer */

 #
 #
 ############## END OF SPRITE BUFFER ##############################


RSP_YIELD_SAVE_LEN1:	/* what to save when yield occurs */
	.print	""
	.symbol RSP_YIELD_SAVE_LEN,	(RSP_YIELD_SAVE_LEN1)+(0x20)

	.dmax	(OS_YIELD_DATA_SIZE) - (31)

 #
 # WARNING! 
 # We do not use the correct DMA length in the RSP_INPUT transfer in
 # gmain.s... This means we might overwrite the first word of SETUP_TMP.
 # That's okay, SETUP_TMP is guarenteed to be trash-able at the time we
 # do this transfer.
 #
 # Don't move this around, or put anything between RSP_INPUT and SETUP_TMP
 # If you do, it might get overwritten when you least expect it.
 #

RSP_SETUP_TMP_OFFSET:
	.space	96	/* 96 bytes of setup scratch mem */

RSP_CLIP_TMP_OFFSET:
	.space	160	/* 160 bytes of clip scratch space */

RSP_OUTPUT_OFFSET:
	.space	1024	/* 1024 bytes of output buffer */

RSP_SCRATCH_OFFSET:
	.space	480	/* 12 points * 40 bytes/pt = 480 bytes of clip points */

	.symbol RSP_DLINPUT_SIZE8,	(RSP_INPUT_OFFSET)-(RSP_DLINPUT_OFFSET)
	.symbol RSP_OUTPUT_SIZE8,	(RSP_SCRATCH_OFFSET)-(RSP_OUTPUT_OFFSET)
 #
 #
 ############## END OF I/O and SCRATCH BUFFERS ####################

 ##################################################################
 ############## END OF ALLOCATED DMEM #############################
 ##################################################################
RSP_END_DMEM:

 ##################################################################
 ############## TASK HEADER ADDRESS ###############################
 ##################################################################

	.symbol RSP_TASK_OFFSET,	(0x1000)-(OS_TASK_SIZE)

 ##################################################################
 ############## CHECK END OF ALLOCATED DMEM #######################
 ##################################################################

	.dmax	4096

 ##################################################################
 ############## PRINT COMPILATION REPORT ##########################
 ##################################################################
 #
/* During compilation, report an informative message about DMEM allocation: */
#ifdef _LANGUAGE_ASSEMBLY


	.print	"----------------------------------------------------------\n"
	.print	"FILE: "
	.print	__FILE__
	.print	"                                          |\n"
	.print	"                                                          |\n"

	.print	"Total DMEM:    hex bytes                                  |\n"
	.print	"-------------- ---------                                  |\n"
	.print	"Initialized  : %3x",RSP_END_INITIALIZE
	.print	"                                        |\n"
	.print	"In Yield Buf : %3x",  RSP_YIELD_SAVE_LEN
	.print	"                                        |\n"
	.print	"Allocated    : %3x",RSP_END_DMEM
	.print	"                                        |\n"
	.print	"                                                          |\n"

	.print  "DMEM Map:               loc  l"
	.print	"en (hex bytes)              |\n"
	.print  "----------------------- ---  ---------------              |\n"


	.print	"RSP_PDATA_OFFSET      : %3x  %3x                          |\n",
		 RSP_PDATA_OFFSET, (-
		 RSP_PDATA_OFFSET  )+
		 RSP_STATE_OFFSET
	.print	"RSP_STATE_OFFSET      : %3x  %3x                          |\n",
		 RSP_STATE_OFFSET, (-
		 RSP_STATE_OFFSET  )+
		 RSP_SEG_OFFSET
	.print	"RSP_SEG_OFFSET        : %3x  %3x                          |\n",
		 RSP_SEG_OFFSET, (-
		 RSP_SEG_OFFSET  )+
		 RSP_LIGHTS_OFFSET
	.print	"RSP_LIGHTS_OFFSET     : %3x  %3x                          |\n",
		 RSP_LIGHTS_OFFSET, (-
		 RSP_LIGHTS_OFFSET  )+
		 RSP_VIEWPORT_OFFSET
	.print	"RSP_VIEWPORT_OFFSET   : %3x  %3x                          |\n",
		 RSP_VIEWPORT_OFFSET, (-
		 RSP_VIEWPORT_OFFSET  )+
		 RSP_DLSTACK_OFFSET
	.print	"RSP_DLSTACK_OFFSET    : %3x  %3x                          |\n",
		 RSP_DLSTACK_OFFSET, (-
		 RSP_DLSTACK_OFFSET  )+
		 RSP_CURR_MMTX_OFFSET
	.print	"RSP_CURR_MMTX_OFFSET  : %3x  %3x                          |\n",
		 RSP_CURR_MMTX_OFFSET, (-
		 RSP_CURR_MMTX_OFFSET  )+
		 RSP_CURR_PMTX_OFFSET
	.print	"RSP_CURR_PMTX_OFFSET  : %3x  %3x                          |\n",
		 RSP_CURR_PMTX_OFFSET, (-
		 RSP_CURR_PMTX_OFFSET  )+
		 RSP_CURR_MPMTX_OFFSET
	.print	"RSP_CURR_MPMTX_OFFSET : %3x  %3x                          |\n",
		 RSP_CURR_MPMTX_OFFSET, (-
		 RSP_CURR_MPMTX_OFFSET  )+
		 RSP_POINTS_OFFSET
	.print	"RSP_POINTS_OFFSET     : %3x  %3x                          |\n",
		 RSP_POINTS_OFFSET, (-
		 RSP_POINTS_OFFSET  )+
		 RSP_DLINPUT_OFFSET
	.print	"RSP_DLINPUT_OFFSET    : %3x  %3x                          |\n",
		 RSP_DLINPUT_OFFSET, (-
		 RSP_DLINPUT_OFFSET  )+
		 RSP_INPUT_OFFSET
	.print	"RSP_INPUT_OFFSET      : %3x  %3x                          |\n",
		 RSP_INPUT_OFFSET, (-
		 RSP_INPUT_OFFSET  )+
		 RSP_SETUP_TMP_OFFSET
	.print	"RSP_SETUP_TMP_OFFSET  : %3x  %3x                          |\n",
		 RSP_SETUP_TMP_OFFSET, (-
		 RSP_SETUP_TMP_OFFSET  )+
		 RSP_CLIP_TMP_OFFSET
	.print	"RSP_CLIP_TMP_OFFSET   : %3x  %3x                          |\n",
		 RSP_CLIP_TMP_OFFSET, (-
		 RSP_CLIP_TMP_OFFSET  )+
		 RSP_OUTPUT_OFFSET
	.print	"RSP_OUTPUT_OFFSET     : %3x  %3x                          |\n",
		 RSP_OUTPUT_OFFSET, (-
		 RSP_OUTPUT_OFFSET  )+
		 RSP_SCRATCH_OFFSET
	.print	"RSP_SCRATCH_OFFSET    : %3x  %3x                          |\n",
		 RSP_SCRATCH_OFFSET, (-
		 RSP_SCRATCH_OFFSET  )+
		 RSP_END_DMEM

	.print	"----------------------------------------------------------\n"

    .text

#   undef _DumpDMEMOffset
#else  /* _LANGUAGE_ASSEMBLY */
#endif /* _LANGUAGE_ASSEMBLY */
