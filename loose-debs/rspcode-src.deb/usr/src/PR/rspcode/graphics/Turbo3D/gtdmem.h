
/*
 * Copyright 1995, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED
 *
 * UNPUBLISHED -- Rights reserved under the copyright laws of the United
 * States.   Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure.
 *
 * U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:	
 * Use, duplication or disclosure by the Government is subject to restrictions
 * as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 * in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 * in similar or successor clauses in the FAR, or the DOD or NASA FAR
 * Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 * 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 *
 * THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 * INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 * DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 * PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 * GRAPHICS, INC.
 *
 */
	
/*
 * File:		gtdmem.h
 * Creator:		hsa@sgi.com
 * Create Date:		Thu Oct 12 13:35:50 PDT 1995
 *
 */

 #
 # gtdmem.h
 #
 # This file lays out the DMEM usage for the TURBO RSP graphics task.

#ifndef _GTDMEM_H_
#define _GTDMEM_H_	1

 #
 # IMPORTANT NOTE:
 #
 # Many of the following fields require some alignment, for the ld/st to
 # work as efficiently as possible... Add this someday...
 #
 #


/*
 * Memory layout of DMEM:
 *
 * (put pretty picture here)
 * 
 */

/*
 * Memory addressing Strategy:
 *
 * All dmem will be addressed relative to register zero which is
 * equivalent to the top of dmem.  Memory is allocated in this file by
 * adding .bytes, .halfs, .words, etc.  If alignment is required, attempt
 * to align by hand and use a .bound <byte_alignment> where
 * <byte_alignment> is the number of bytes to align to.  This will
 * supply an error message when alignment is incorrect.  To force
 * alignment use .align <byte_alignment> which will force alignment by
 * adding pad bytes.  An error will occur if dmem is overflowed.
 * 
 */

#ifndef DCACHEBASE
DCACHEBASE:
#else 
#endif

#ifndef DCACHEBASEHI
#   define DCACHEBASEHI	(DCACHEBASE/0x10000)
#else 
#endif
#ifndef DCACHEBASELO
#   define DCACHEBASELO	(DCACHEBASE&0xffff)
#else 
#endif

 #################################################################
 ############## BEGIN INITIALIZING AND DEFINING DMEM USE #########
 #################################################################

RSP_PDATA_OFFSET:

 #################################################################
 ############## QUAD CONSTANTS ###################################
 #################################################################
 #
 # Constants. Setup a bunch of constants at compile-time. Be
 # sure to #define the macros and offsets needed to access them.
 #
 #################################################################
 #
 # Initialize vconst; each element a different scalar constant...
 #
	.align	16
	.bound	16
VCONST_OFFSET:
        .half   0x0000          # 0
        .half   0x0001          # 1
        .half   0x0002          # 2
        .half   0xffff          # -1
        .half   0x4000          # 1/4.0 in fixed-point fraction
        .half   0x0004          # 4.0, for screen point scaling.
        .half   0xfffc          # mask to remove fractional screen coords.
        .half   0x0200          # 1/512.0 for pixel-packed loads
 #
 # Initialize vconst; each element a different scalar constant...
 #
	.bound	16
VCONST1_OFFSET:
        .half   0x7fff          # for setup w scale
        .half   0xfff8          # to clear lower bits for EW fracs
        .half   0x0008          # mult by 8 for LOD computation.
        .half   0x00fd          # 1/128 * 0.990 *.5 (square root correction)
        .half   0x0020          # for z scale
        .half   0x8000          # test bow-tie fix
	.half	0x01cc
        .half   0xcccc          # W multiplier(0.8). 1/w ranges from 0 to 0.8 
 #
 # Initialize OpenGL correction scale
 #
	.bound	16
VOPENGL_OFFSET:
        .half   0x0001          # x
        .half   0xffff          # y
        .half   0x0001          # z
        .half   0x0001          # w
        .half   0x0001          # x
        .half   0xffff          # y
        .half   0x0001          # z
        .half   0x0001          # w
 #
 # Initialize constant vector for Newton's iteration
 #
	.bound	16
VNEWT_OFFSET:
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # MUST BE 2 !
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # this element not used
        .half   0x0002          # MUST BE 2 !

	.bound	16
VCONST_SCREENCLAMP:
	.half	4090		# +xy clamp to +1000 (*4)
	.half	-4090		# -xy clamp to -1000 (*4)
	.half	0x7fff		# +z clamp max
	.half	0x0000		# -z clamp to 0
 #
 #
 ############## END OF CONSTANTS ##################################

 #################################################################
 ############## SCALAR CONSTANTS #################################
 #################################################################
 #
 # Constants. Setup a bunch of constants at compile-time. Be
 # sure to #define the macros and offsets needed to access them.
 #
 #################################################################
 #
 # a common necessary mask value
 #
  	.bound	4
SEGADDR_MASK_OFFSET:
          .word   0x00ffffff      # segment address mask.
 #
 #
 ############## END OF SCALAR CONSTANTS ##########################

 #################################################################
 ############## LABEL CONSTANTS ##################################
 #################################################################
 #
 # Labels for loading jump addresses
 #
 #################################################################
 #
	.bound 2

DMAWAITDL:
	.half	DMAWaitDL
 #
 #
 ############## END OF LABELS #####################################


 ######################################################################
 ############## DMEM STATE ############################################
 ######################################################################
 #
 #
	.align	8
RSP_STATE_OFFSET:
 # some state structures NOT part of the object 'state'
 #
	.bound	4
RSP_STATEP_YIELD_STORE:
	.word	0x0			# where to store yield dmem

	.bound	4
RSP_STATEP_FIFO_OUTP:
RSP_STATEP_DRAM_OUTP:
        .word   0x0                     # RSP_STATE_DRAM_OUTP

 # not used in turbo
	.bound	4
RSP_STATEP_DRAM_STACK:
        .word   0x0                     # RSP_STATE_DRAM_STACK

 # not used in turbo
	.bound	4
RSP_STATEP_MMTX_STACK_P:
        .word   0x0                     # RSP_STATE_MMTX_STACK_P

	.align	8
        .bound 8
RSP_STATEP_DRAM_OUT_LENP:		# RSP_STATE_DRAM_OUT_LENP
        .word   0x0

	.align	8
        .bound 8
RSP_STATEP_FIFO_BUF_TOP:
RSP_STATEP_DRAM_OUT_LEN:
        .word   0x0                     # RSP_STATE_DRAM_OUT_LEN
RSP_STATEP_FIFO_BUF_END:
        .word   0x0                     # is a 64-bit counter

	.bound	4
RSP_RETURN_SAVE:
        .word   0x0

    .symbol RSP_STATE_YIELD_STORE,   RSP_STATEP_YIELD_STORE-RSP_STATE_OFFSET
    .symbol RSP_STATE_DRAM_OUTP,     RSP_STATEP_DRAM_OUTP-RSP_STATE_OFFSET
    .symbol RSP_STATE_FIFO_OUTP,     RSP_STATEP_FIFO_OUTP-RSP_STATE_OFFSET
    .symbol RSP_STATE_FIFO_BUF_TOP,  RSP_STATEP_FIFO_BUF_TOP-RSP_STATE_OFFSET
    .symbol RSP_STATE_FIFO_BUF_END,  RSP_STATEP_FIFO_BUF_END-RSP_STATE_OFFSET
    .symbol RSP_STATE_DRAM_OUT_LEN,  RSP_STATEP_DRAM_OUT_LEN-RSP_STATE_OFFSET
    .symbol RSP_STATE_DRAM_OUT_LENP, RSP_STATEP_DRAM_OUT_LENP-RSP_STATE_OFFSET

PROGRAM_PAD_OFFSET:


    .print	"--------------------------------------------------------------------\n"
    .print   __FILE__
    .print   " : Total static program data initialized is %d bytes.\n", PROGRAM_PAD_OFFSET


/* 
 * everything up to this point is compiler generated and loaded
 * by the boot ucode.
 */

/*
 * the next piece is the global 'state' structure, loaded via the display
 * list. This structure must correspond with the one in gt.h
 */
 ######################################################################
 #
 # initialize RSP GLOBAL state.
 #
	.align	8
RSP_GLOB_STATE_OFFSET:

	.bound	8
RSP_STATEP_PERSPNORM:
        .half   0xffff                  # RSP_STATE_PERSPNORM
        .half   0x0	# pad
        .word   0x0	# pad

	.bound	8
RSP_GLOB_STATEP_OTHERMODE:
        .word   0x0
        .word   0x0

 # initialize memory segment table.
 #
	.bound	8
RSP_SEG_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0

 ##################################################################
 ############## VIEWPORT ##########################################
 ##################################################################
 #
 # define offsets for the viewport structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  |scal.x |scal.y |scal.z |       |trns.x |trns.y |trns.z |        |
 #  -----------------------------------------------------------------
 #
 # These guys have 1-bit of fraction to them. This is factored out
 # during the transform.
 #
#define RSP_VIEWPORT_SX         0
#define RSP_VIEWPORT_SY         2
#define RSP_VIEWPORT_SZ         4
#define RSP_VIEWPORT_TX         8
#define RSP_VIEWPORT_TY         10
#define RSP_VIEWPORT_TZ         12

	.bound	8
RSP_VIEWPORT_OFFSET:
        .word   0x0
        .word   0x0
        .word   0x0
        .word   0x0
 #
 ############## END OF VIEWPORT ###################################

	.bound	8
RSP_GLOB_DP_LISTP:
        .word   0x0

RSP_GLOB_STATE_END:

    .symbol RSP_GLOB_STATE_OTHERMODE, RSP_GLOB_STATEP_OTHERMODE-RSP_STATE_OFFSET
    .symbol RSP_GLOB_STATE_SIZE8, RSP_GLOB_STATE_END-RSP_GLOB_STATE_OFFSET
    .symbol RSP_STATE_PERSPNORM, RSP_STATEP_PERSPNORM-RSP_STATE_OFFSET

 #####################################################################
 #
 # END OF GLOBAL STATE STRUCTURE
 #
 #####################################################################

/*
 * the next piece is the 'state' structure, loaded via the display
 * list for every object. This structure must correspond with
 * the one in gt.h
 */

 ######################################################################
 #
 # initialize RSP OBJECT state.
 #
    .align 8
RSP_OBJ_STATE_OFFSET:

RSP_STATEP_RENDER:
        .half   0x0 	                # RSP_STATE_RENDER
RSP_STATEP_RENDER_L:
        .byte   0x0                     # RSP_STATE_RENDER
RSP_STATEP_TRI:
        .byte   0x0                     # RSP_STATE_RENDER

        .bound  4
RSP_STATEP_TEX_STATE:
RSP_STATEP_TEX_PAD:
        .byte   0x0
RSP_STATEP_TEX_CMD:
        .byte   0x0			# RSP_STATE_TEX_CMD
RSP_STATEP_TEX_LOD:
        .byte   0x0			# RSP_STATE_TEX_LOD
RSP_STATEP_TEX_TILE:
        .byte   0x0                     # RSP_STATE_TEX_TILE

	.bound	8
RSP_STATEP_VTX_N:
        .byte   0x0
RSP_STATEP_VTX_V0:
        .byte   0x0
RSP_STATEP_TRI_N:
        .byte   0x0
RSP_STATEP_FLAG:
        .byte   0x0

	.bound	4
RSP_RDP_CMD_OFFSET:
        .word   0x0

	.bound	8
RSP_OBJ_STATEP_OTHERMODE:
        .word   0x0
        .word   0x0

	.bound	8
RSP_CURR_MPMTX_OFFSET:
	.space	64	/* 64 bytes per matrix */
 #
 ############## END OF MATRICES ###################################

RSP_OBJ_STATE_END:

    .symbol RSP_STATE_RENDER,	RSP_STATEP_RENDER-RSP_STATE_OFFSET
    .symbol RSP_STATE_RENDER_L, RSP_STATEP_RENDER_L-RSP_STATE_OFFSET
    .symbol RSP_STATE_TRI,	RSP_STATEP_TRI-RSP_STATE_OFFSET
    .symbol RSP_STATE_TEX_CMD,	RSP_STATEP_TEX_CMD-RSP_STATE_OFFSET
    .symbol RSP_STATE_TEX_LOD,	RSP_STATEP_TEX_LOD-RSP_STATE_OFFSET
    .symbol RSP_STATE_TEX_TILE,	RSP_STATEP_TEX_TILE-RSP_STATE_OFFSET
    .symbol RSP_STATE_VTXCOUNT, RSP_STATEP_VTX_N-RSP_STATE_OFFSET
    .symbol RSP_STATE_VTXV0,	RSP_STATEP_VTX_V0-RSP_STATE_OFFSET
    .symbol RSP_STATE_TRICOUNT,	RSP_STATEP_TRI_N-RSP_STATE_OFFSET
    .symbol RSP_STATE_FLAG,	RSP_STATEP_FLAG-RSP_STATE_OFFSET
    .symbol RSP_STATE_RDP,	RSP_RDP_CMD_OFFSET-RSP_STATE_OFFSET
    .symbol RSP_STATE_OTHERMODE,RSP_OBJ_STATEP_OTHERMODE-RSP_STATE_OFFSET
    .symbol RSP_OBJ_STATE_SIZE8,RSP_OBJ_STATE_END-RSP_OBJ_STATE_OFFSET
 #
 ############## END OF RSP STATE ##################################



/*
 * This completes the object 'state' structure.
 */


 ##################################################################
 ############## END OF INITIALIZED DATA############################
 ##################################################################
	.align	16
	.bound	16
RSP_END_INITIALIZE:
    
    .print __FILE__
    .print " : Total DMEM Size Initialized is %d bytes.\n", RSP_END_INITIALIZE


 ##################################################################
 ############## POINTS BUFFER #####################################
 ##################################################################
 #
 # This structure should match the structure Vtx in gbi.h:
 #
 # define offsets for the points buffer structure:
 #
 #  bytes:
 #  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15
 #  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .
 #  -----------------------------------------------------------------
 #  | x     | y     | z     | pad   |   s   |   t   | r | g | b | a |
 #  ----------------------------------------------------------------|
 #
 # After transformation, we put screen x,y here:
 #
 #  ---------------------------------
 #  |  xs   |  ys   |  zsi  |  zsf  |
 #  ---------------------------------
 #
#define RSP_PTS_X               0
#define RSP_PTS_Y               2
#define RSP_PTS_Z               4
#define RSP_PTS_S               8
#define RSP_PTS_T              10
#define RSP_PTS_R              12
#define RSP_PTS_G              13
#define RSP_PTS_B              14
#define RSP_PTS_A              15
#define RSP_PTS_XS              0
#define RSP_PTS_YS              2
#define RSP_PTS_ZS              4
#define RSP_PTS_ZSF             6
#define RSP_PTS_LEN            16

	.align	8
RSP_POINTS_OFFSET:
	.space	1024	/* 16 bytes * 64 points */
 #
 ############## END OF POINTS BUFFER ##############################

 ##################################################################
 ############## TRIANGLE LIST #####################################
 ##################################################################
 #
	.align	8
RSP_TRIN_OFFSET:
	.space	256	/* 64 triangles, 4 bytes each */
 #
 ############## END OF TRIN BUFFER ################################


 #
 # everything above we want to save on a yield...
 #
RSP_YIELD_SAVE_LEN1:	/* what to save when yield occurs */
	.bound 8
	.symbol RSP_YIELD_SAVE_LEN,	(RSP_YIELD_SAVE_LEN1)+(0x20)

	.dmax	(OS_YIELD_DATA_SIZE) - (31)

 ##################################################################
 ############## I/O and SCRATCH BUFFERS ###########################
 ##################################################################
 #
RSP_DLINPUT_OFFSET:
	.space	240	/* 15 'objects' at a time per display list */

RSP_SETUP_TMP_OFFSET:
	.space	128	/* used for setup and dp commands */

RSP_OUTPUT_OFFSET:
	.space	1024	/* 1024 bytes of output buffer */

RSP_SCRATCH_OFFSET:
	.space	8	/* everything that's left... */

 # some sizes:
    .symbol RSP_POINTS_SIZE8,	RSP_TRIN_OFFSET-RSP_POINTS_OFFSET
    .symbol RSP_TRIN_SIZE8,	RSP_DLINPUT_OFFSET-RSP_TRIN_OFFSET
 # note: we lie about the size of setup tmp, so that we have a
 # safety margin before the output buffer. See also gtstate.s about
 # textured rectangles...
    .symbol RSP_SETUP_TMP_SIZE8,	RSP_OUTPUT_OFFSET-RSP_SETUP_TMP_OFFSET - 16
    .symbol RSP_DLINPUT_SIZE8,	RSP_SETUP_TMP_OFFSET-RSP_DLINPUT_OFFSET
    .symbol RSP_OUTPUT_SIZE8,	RSP_SCRATCH_OFFSET-RSP_OUTPUT_OFFSET
 #
 ############## END OF I/O and SCRATCH BUFFERS ####################

 ##################################################################
 ############## END OF ALLOCATED DMEM #############################
 ##################################################################
RSP_END_DMEM:
    .print __FILE__
    .print " : Total DMEM Size Allocated is %d bytes.\n", RSP_END_DMEM

 ##################################################################
 ############## TASK HEADER ADDRESS ###############################
 ##################################################################

#define RSP_TASK_OFFSET		(0x1000-OS_TASK_SIZE)

 ##################################################################
 ############## CHECK END OF ALLOCATED DMEM #######################
 ##################################################################

    .print	"DMEM ALLOCATED must be less than 4096 bytes here.\n"
    .dmax	4096

 ##################################################################
 ############## PRINT COMPILATION REPORT ##########################
 ##################################################################
 #

/* to verify state offsets: */
#include <gt.h>

/* During compilation, report an informative message about DMEM allocation: */
#   define _DumpDMEMOffset(o,p,s)  				\
    .print 	#o						\
    .print 	p						\
    .print 	"\t\t : %d\t%d bytes.\n", (DCACHEBASE + (o)), (s)

#   define _DumpStateOffset(o,p,s)  				\
    .print	"........"					\
    .print	#o						\
    .print 	p						\
    .print	"\t : %d - %d =? %d.\n", ((o) - RSP_OBJ_STATE_OFFSET), (s), (((o) - RSP_OBJ_STATE_OFFSET) - (s))

    .print	"--------------------------------------------------------------------\n"

    .print	__FILE__
    .print	" : Total DMEM Size Allocated is %d bytes\n", RSP_END_DMEM
    .print	__FILE__
    .print	" : Program data segment is at %08x.\n", DCACHEBASE+RSP_PDATA_OFFSET
    .print	__FILE__
    .print	" : DMEM Map:\n"

    _DumpDMEMOffset(RSP_PDATA_OFFSET, "", RSP_STATE_OFFSET-RSP_PDATA_OFFSET)
    _DumpDMEMOffset(RSP_STATE_OFFSET, "", RSP_POINTS_OFFSET-RSP_STATE_OFFSET)

    .print ".....Verify RSP 'C' struct offsets (LAST COLUMN MUST BE '0'):\n"

    _DumpStateOffset(RSP_STATEP_RENDER, "\t", GT_STATE_OFF_RENDSTATE)
    _DumpStateOffset(RSP_STATEP_TEX_STATE, "\t", GT_STATE_OFF_TEXSTATE)
    _DumpStateOffset(RSP_STATEP_VTX_N, "\t", GT_STATE_OFF_VTXCOUNT)
    _DumpStateOffset(RSP_STATEP_VTX_V0, "\t", GT_STATE_OFF_VTXV0)
    _DumpStateOffset(RSP_STATEP_TRI_N, "\t", GT_STATE_OFF_TRICOUNT)
    _DumpStateOffset(RSP_RDP_CMD_OFFSET, "\t", GT_STATE_OFF_RDPCMDS)
    _DumpStateOffset(RSP_OBJ_STATEP_OTHERMODE, "", GT_STATE_OFF_OTHERMODE)
    _DumpStateOffset(RSP_CURR_MPMTX_OFFSET, "\t", GT_STATE_OFF_TRANSFORM)

    _DumpDMEMOffset(RSP_POINTS_OFFSET, "", RSP_TRIN_OFFSET-RSP_POINTS_OFFSET)
    _DumpDMEMOffset(RSP_TRIN_OFFSET, "\t", RSP_DLINPUT_OFFSET-RSP_TRIN_OFFSET)
    _DumpDMEMOffset(RSP_DLINPUT_OFFSET, "", RSP_SETUP_TMP_OFFSET-RSP_DLINPUT_OFFSET)
    _DumpDMEMOffset(RSP_SETUP_TMP_OFFSET, "", RSP_OUTPUT_OFFSET-RSP_SETUP_TMP_OFFSET)
    _DumpDMEMOffset(RSP_OUTPUT_OFFSET, "", RSP_SCRATCH_OFFSET-RSP_OUTPUT_OFFSET)

    .print	"--------------------------------------------------------------------\n"

#   undef _DumpDMEMOffset
#   undef _DumpStateOffset

#endif /* _GTDMEM_H_ */
