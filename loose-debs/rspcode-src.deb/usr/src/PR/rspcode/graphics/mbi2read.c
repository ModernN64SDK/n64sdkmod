
/**************************************************************************
 *                                                                        *
 *               Copyright (C) 1994, Silicon Graphics, Inc.               *
 *                                                                        *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright  law.  They  may not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 *                                                                        *
 *************************************************************************/

/*
 * File:	mbi2read.c
 * Creator:	hsa@sgi.com
 * Create Date:	Mon Jul 18 14:57:14 PDT 1994
 *
 * This program reads in a graphics display list file intended for the RSP,
 * and prints out a 'readable' version of it.
 *
 * This is a useful exercise to develop the parsing code (in C)...
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <bstring.h>
#include <PR/mbi.h>
#include <PR/verify.h>
#include <PR/sptask.h>

#define UsageString	"<options> <binfile>"

#define TASKSZ32_MAX	4096

#ifndef TRUE
#   define TRUE		1
#endif

#ifndef FALSE
#   define FALSE	0
#endif

typedef int			bool;
/*typedef unsigned char 	 u8;*/
/*typedef unsigned short int  	u16;*/
/*typedef unsigned long int 	u32;*/

u32	TaskBuffer[TASKSZ32_MAX];	/* some max size... */

#define DRAMSIZE 1024 * 1024 * 4

u8	DRAM[DRAMSIZE];

u32	segment_base[16];

static bool	verbose = FALSE, do_nested = TRUE, exp_matrix = FALSE;
static bool	exp_mp = FALSE, row_major=FALSE, use_verifyinfo=FALSE;
static int	dl_depth=0;

static void	read_dma(u32 *bufp);
static void	read_imm(u32 *bufp);
static void	read_rdp(u32 *bufp);

/*
 * Takes a pointer in DRAM, and a length in bytes. Parses
 * the display list there, until length bytes is consumed or
 * a G_ENDDL command is found.
 */
static void
parse_DL(u32 *gfxp, u16 len)
{
    u32		readBuf[4];
    u8		op;
    int		docont = 1;

    while (docont) {


	if (gfxp >= (u32 *) &DRAM[DRAMSIZE] || gfxp < (u32 *) &DRAM[0]) {
	    printf("ERROR OCCURRED: pointing to address 0x%08X (max=0x%08X)\n",
					(int)(gfxp-(u32 *)&DRAM[0]),
					(int)(&DRAM[DRAMSIZE]-&DRAM[0]));
	    exit(1);
	}

	op = (u8) ((*gfxp & 0xff000000) >> 24);
	bcopy((char *) gfxp, (char *) &(readBuf[0]), sizeof(Gfx));

	switch (op & 0xc0) {
	    
	  case (u8) 0x00:
	    fprintf(stdout,"\tDMA : ");
	    read_dma(readBuf);
	    break;

	  case (u8) 0x80:
	    fprintf(stdout,"\tIMM : ");
	    read_imm(readBuf);
	    /*if (op == (u8) G_ENDDL || op == (char) 0xb3) {*/
	    if (op == (u8) G_ENDDL ) {
		docont = 0;
	    }
	    break;

	  case (u8) 0xc0:
	    fprintf(stdout,"\tRDP : ");
	    read_rdp(readBuf);
	    break;

	  default:
	    fprintf(stdout,"ERROR : display list is lost, op = %02x\n",op);
	    break;

	}

	fprintf(stdout,"\n");
	gfxp += (sizeof(Gfx) >> 2);
	len -= 8;
    }

    fprintf(stdout,"\n\n=============== DL Pop (%d)=============\n",
						dl_depth--);
}

/*
 * showmatrix
 *  print matrix out in nice format
 */
#define MAXPMAT 2
#define MAXMMAT 10
static float modelcurrent[16]={1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0};
static float projectioncurrent[16]={1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,0.0,1.0};
static float modelstack[MAXMMAT][16];
static float projectionstack[MAXPMAT][16];
static int modelptr=-1,projectionptr=-1;
static char *mtype[2] = { "modeling","projection" };
static char *mop[2] = { "multiply","load" };
static char *mpush[2] = { "nopush","push" };
void showmatrix(float *mtx,char b0)
{
	int i,j;
	float (*mcurrent)[16],(*mstack)[][16];
	int *mptr;
	float result[16];

	printf("\t\tparam = %s  %s  %s\n",mtype[b0&1],mop[(b0>>1)&1],
							mpush[(b0>>2)&1]);
	for (i=0; i<4; i++) {
	printf("\t");
	for (j=0; j<4; j++) {
		if (row_major)
			printf("%12.5f ",mtx[i + (j*4)]);
		else
			printf("%12.5f ",mtx[j + (i*4)]);
	}
	printf("\n");
	}
	
	/* 
	 * PUSH MATRIX ON STACK?
	 */
	if (b0 & 4) {
		mcurrent= (b0 & 1) ? &projectioncurrent : &modelcurrent;
		mstack= (b0 & 1) ? 
				(float (*)[][16]) &projectionstack : 
				(float (*)[][16]) &modelstack;
		mptr= (b0 & 1) ? &projectionptr : &modelptr;

		if ((*mptr)++ >= ((b0 & 1) ? MAXPMAT : MAXMMAT)) {
			printf("WARNING!! too many %s matrices on stack\n",
				mtype[b0&1]);
			(*mptr)--;
			return;
		}
		for (i=0; i<16; i++) (*mstack)[*mptr][i] = (*mcurrent)[i];
	}

	/*
	 * MULTPIPLY MATRIX WITH CURRENT?
	 */
	mcurrent= (b0 & 1) ? &projectioncurrent : &modelcurrent;
	if (!(b0 & 2)) {
		for (i=0;i<4;i++) {
		for (j=0;j<4;j++) {
			result[i + (j*4)] = 
				(*mcurrent)[i+(0*4)] * (mtx)[0+(j*4)] +
				(*mcurrent)[i+(1*4)] * (mtx)[1+(j*4)] +
				(*mcurrent)[i+(2*4)] * (mtx)[2+(j*4)] +
				(*mcurrent)[i+(3*4)] * (mtx)[3+(j*4)];
		}
		}
		for (i=0; i<16;i++) (*mcurrent)[i]=result[i];
	} else {
		for (i=0; i<16;i++) (*mcurrent)[i]=mtx[i];
	}
/*----------------------------------------*/
/*
		printf("\t\tRESULT current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",result[i + (j*4)]);
			else
				printf("%12.5f ",result[j + (i*4)]);
		}
		printf("\n");
		}
		printf("\t\tMCURRENT current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",(*mcurrent)[i + (j*4)]);
			else
				printf("%12.5f ",(*mcurrent)[j + (i*4)]);
		}
		printf("\n");
		}
*/
/*----------------------------------------*/

	for (i=0;i<4;i++) {
	for (j=0;j<4;j++) {
		result[i + (j*4)] = 
			projectioncurrent[i+(0*4)] * modelcurrent[0+(j*4)] +
			projectioncurrent[i+(1*4)] * modelcurrent[1+(j*4)] +
			projectioncurrent[i+(2*4)] * modelcurrent[2+(j*4)] +
			projectioncurrent[i+(3*4)] * modelcurrent[3+(j*4)];
	}
	}

	if (exp_mp) {
		printf("\t\tPROJECTION current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",projectioncurrent[i + (j*4)]);
			else
				printf("%12.5f ",projectioncurrent[j + (i*4)]);
		}
		printf("\n");
		}
	
		printf("\t\tMODEL current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",modelcurrent[i + (j*4)]);
			else
				printf("%12.5f ",modelcurrent[j + (i*4)]);
		}
		printf("\n");
		}
	}

	printf("\t\tCONCATENATED:\n");
	for (i=0; i<4; i++) {
	printf("\t");
	for (j=0; j<4; j++) {
		if (row_major)
			printf("%12.5f ",result[i + (j*4)]);
		else
			printf("%12.5f ",result[j + (i*4)]);
	}
	printf("\n");
	}


}

popmatrix(int b0)
{
	int i,j;
	float (*mcurrent)[16],(*mstack)[][16];
	int *mptr;
	float result[16];

	mcurrent= (b0 & 1) ? &projectioncurrent : &modelcurrent;
	mstack= (b0 & 1) ? 
			(float (*)[][16]) &projectionstack : 
			(float (*)[][16]) &modelstack;
	mptr= (b0 & 1) ? &projectionptr : &modelptr;

	printf("\t\t Popping %s stack\n",mtype[b0&1]);
	if ((*mptr) < 0) {
		printf("WARNING!! Popped too many matrices off the %s stack\n",
			mtype[b0&1]);
		return;
	}
	for (i=0; i<16; i++) (*mcurrent)[i] = (*mstack)[*mptr][i];
	(*mptr)--;

	printf("\t\tPopped:\n");
	for (i=0; i<4; i++) {
	printf("\t");
	for (j=0; j<4; j++) {
		if (row_major)
			printf("%12.5f ",(*mcurrent)[i + (j*4)]);
		else
			printf("%12.5f ",(*mcurrent)[j + (i*4)]);
	}
	printf("\n");
	}
/*----------------------------------------*/
/*
		printf("\t\tRESULT current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",result[i + (j*4)]);
			else
				printf("%12.5f ",result[j + (i*4)]);
		}
		printf("\n");
		}
		printf("\t\tMCURRENT current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",(*mcurrent)[i + (j*4)]);
			else
				printf("%12.5f ",(*mcurrent)[j + (i*4)]);
		}
		printf("\n");
		}
*/
/*----------------------------------------*/

	for (i=0;i<4;i++) {
	for (j=0;j<4;j++) {
		result[i + (j*4)] = 
			projectioncurrent[i+(0*4)] * modelcurrent[0+(j*4)] +
			projectioncurrent[i+(1*4)] * modelcurrent[1+(j*4)] +
			projectioncurrent[i+(2*4)] * modelcurrent[2+(j*4)] +
			projectioncurrent[i+(3*4)] * modelcurrent[3+(j*4)];
	}
	}

	if (exp_mp) {
		printf("\t\tPROJECTION current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",projectioncurrent[i + (j*4)]);
			else
				printf("%12.5f ",projectioncurrent[j + (i*4)]);
		}
		printf("\n");
		}
	
		printf("\t\tMODEL current:\n");
		for (i=0; i<4; i++) {
		printf("\t");
		for (j=0; j<4; j++) {
			if (row_major)
				printf("%12.5f ",modelcurrent[i + (j*4)]);
			else
				printf("%12.5f ",modelcurrent[j + (i*4)]);
		}
		printf("\n");
		}
	}

	printf("\t\tCONCATENATED:\n");
	for (i=0; i<4; i++) {
	printf("\t");
	for (j=0; j<4; j++) {
		if (row_major)
			printf("%12.5f ",result[i + (j*4)]);
		else
			printf("%12.5f ",result[j + (i*4)]);
	}
	printf("\n");
	}

}

float numprint(int num, int s, int i, int f)
{
	s = (s>=0) ? (num & (1<<s)) : 0;
	s = s ? -1 : 1;
	num = num & ((1<<(i+f))-1);
	return (float) s * ((float) num / ((float) (1<<(f))));
}

/*
 * Parse and dump a DMA-type display list command.
 */
static void
read_dma(u32 *bufp)
{
    u32		addr, *data, *gfxp;
    u32		dati,datf;
    u8		seg_id;
    u16		len;
    char	op, b0, b1;
    float	mtx[16];
    int		i;
    Vtx_t	*vp;
    int		index,movemem[4];
    float	f;

    op = ((*bufp & 0xff000000) >> 24);

    /* DMA op addressing is all the same: */
    seg_id = (u8) ((bufp[1] & 0x0f000000) >> 24);
    addr = segment_base[seg_id] + (bufp[1] & 0x00ffffff);
    len = (u16) (bufp[0] & 0x0000ffff);

    switch (op) {

      case (char) G_SPNOOP:
	fprintf(stdout,"\tSPNOOP ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_MTX:
	fprintf(stdout,"\tMTX ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	b0 = (char) ((bufp[0] & 0x00ff0000) >> 16);
	fprintf(stdout,"\t\tparam = %02x len = %d ptr = %08x\n", b0, len, addr);
	if (verbose) {
#define NEW_MTX
#ifdef NEW_MTX
	    data = (u32 *) &(DRAM[addr]);
	    i=0;
	    while (len > 0) {
		fprintf(stdout,"\t\t\t%08x\n",*data);
		data++;
		len -= 4;
	    }

	    i=0;
	    data = (u32 *) &(DRAM[addr]);
	    while (i<16) {
	    	datf = data[8];
	    	dati = *(data++);
		printf("\t%04X %04X\n\t%04X %04X\n",((dati>>16) &0xffff),
				((datf>>16) &0xffff),((dati) &0xffff),((datf) &0xffff));

		if (dati & 0x80000000)
		    mtx[i++] = -(float) ((-((dati & 0xffff0000) | ((datf & 0xffff0000)>>16)))&0x7fffffff)/65536.0;
		else
		    mtx[i++] = (float) ((dati & 0x7fff0000) | ((datf & 0xffff0000)>>16))/65536.0;

		if (dati & 0x8000)
		    mtx[i++] = -(float) ((-(((dati & 0x7fff)<<16) | (datf & 0xffff)))&0x7fffffff)/65536.0;
		else
		    mtx[i++] = (float) (((dati & 0x7fff)<<16) | (datf & 0xffff))/65536.0;
	    }
#else /* NEW_MTX */
	    data = (u32 *) &(DRAM[addr]);
	    i=0;
	    while (len > 0) {
		fprintf(stdout,"\t\t\t%08x\n",*data);
		mtx[i]=((float)*data);
		if (*data & 0x80000000) 
			mtx[i] = -((float) ((-(*data))&0x7FFFFFFF));
                mtx[i++] /= 65536.0;
		data++;
		len -= 4;
	    }
#endif /* NEW_MTX */

	    if (exp_matrix) showmatrix(mtx,b0);
	}
	break;

      case (char) G_MOVEMEM:
	b0 = (char) ((bufp[0] & 0x00f00000) >> 20);
	b1 = (char) ((bufp[0] & 0x000f0000) >> 16);;
	index = (char) ((bufp[0] & 0x00ff0000) >> 16);
	if (verbose) {
	    data = (u32 *) &(DRAM[addr]);
	    for(i=0; i<4; i++) {
		movemem[i]=*data;
		data++;
	    }
	}
	switch(index) {
	  case G_MV_VIEWPORT:
		fprintf(stdout,"\tVIEWPORT ");
		fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
		fprintf(stdout,"\t\tlen = %d ptr = %08x\n",len, addr);
		if (len != 16) fprintf(stdout,
		     "ERROR : length %d invalid for VIEWPORT command.\n",len);
		if (verbose) {
		f=numprint((movemem[0]>>16)&0xffff,15,13,2);
		fprintf(stdout,"\t\t\tX scale = %.2f",f);
		f=numprint((movemem[2]>>16)&0xffff,15,13,2);
		fprintf(stdout,"\tX translate = %.2f\n",f);
		f=numprint((movemem[0])&0xffff,15,13,2);
		fprintf(stdout,"\t\t\tY scale = %.2f",f);
		f=numprint((movemem[2])&0xffff,15,13,2);
		fprintf(stdout,"\tY translate = %.2f\n",f);
		f=numprint((movemem[1]>>16)&0xffff,15,13,2);
		fprintf(stdout,"\t\t\tZ scale = %.2f",f);
		f=numprint((movemem[3]>>16)&0xffff,15,13,2);
		fprintf(stdout,"\tZ translate = %.2f\n",f);
		}
		break;
	  case G_MV_LOOKATY:
		fprintf(stdout,"\tLOOKAT Y  ");
		fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
		fprintf(stdout,"\t\tlen = %d ptr = %08x\n",
				len, addr);
		if (len != 16) fprintf(stdout,
		     "ERROR : length %d invalid for LOOKATY command.\n",len);
		if (movemem[0] != 0x00800000 || movemem[1] != 0x00800000) 
		   fprintf(stdout,
		   "ERROR : first 2 LOOKAT_X words must be 0x00800000 [0x%08X 0x%08X]\n",
			movemem[0],movemem[1]);
		if (verbose) {
		f=numprint((movemem[2]>>24)&0xff,7,0,7);
		fprintf(stdout,"\t\t\tx = %.3f",f);
		f=numprint((movemem[2]>>16)&0xff,7,0,7);
		fprintf(stdout,"\ty = %.3f",f);
		f=numprint((movemem[2]>>8)&0xff,7,0,7);
		fprintf(stdout,"\tz = %.3f\n",f);
		}
		break;
	  case G_MV_LOOKATX:
		fprintf(stdout,"\tLOOKAT X  ");
		fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
		fprintf(stdout,"\t\tlen = %d ptr = %08x\n",
				len, addr);
		if (len != 16) fprintf(stdout,
		     "ERROR : length %d invalid for LOOKATX command.\n",len);
		if (movemem[0] != 0 || movemem[1] != 0) fprintf(stdout,
		    "ERROR : first 2 LOOKAT_X words must be 0x00000000 [0x%08X 0x%08X]\n",
			movemem[0],movemem[1]);
		if (verbose) {
		f=numprint((movemem[2]>>24)&0xff,7,0,7);
		fprintf(stdout,"\t\t\tx = %.3f",f);
		f=numprint((movemem[2]>>16)&0xff,7,0,7);
		fprintf(stdout,"\ty = %.3f",f);
		f=numprint((movemem[2]>>8)&0xff,7,0,7);
		fprintf(stdout,"\tz = %.3f\n",f);
		}
		break;
	  case G_MWO_NUMLIGHT:
		fprintf(stdout,"\tNUM_LIGHTS");
		fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
		fprintf(stdout,"\t\tlen = %d ptr = %08x\n",
				len, addr);
		if (len != 8) fprintf(stdout,
		     "ERROR : length %d invalid for NUM_LIGHTS command.\n",len);
		if (verbose) {
		f=numprint((movemem[0]>>24)&0xff,-1,8,0);
		if ((movemem[0]&0xffff)/32-1 == 1) 
		   fprintf(stdout,"\t\t\tLight 1 will be on.  ");
		else
		   fprintf(stdout,"\t\t\tLights 1-%d will be on.  ",
			(movemem[0]&0xffff)/32-1);
		fprintf(stdout,"Light %d is the ambient light.\n",
			(movemem[0]&0xffff)/32);
		}
		break;
	  case G_MV_L0:
	  case G_MV_L1:
	  case G_MV_L2:
	  case G_MV_L3:
	  case G_MV_L4:
	  case G_MV_L5:
	  case G_MV_L6:
	  case G_MV_L7:
		fprintf(stdout,"\tLIGHT    ");
		fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
		fprintf(stdout,"\t\tlen = %d ptr = %08x light #%d\n",
				len, addr,(index-G_MV_L0)/2+1);
		if (len != 16) fprintf(stdout,
		     "ERROR : length %d invalid for LIGHT command.\n",len);
		if ((movemem[0]&0xFFFFFF00) != (movemem[1]&0xFFFFFF00)) 
		    fprintf(stdout,
		        "ERROR : colors do not match: 0x%08X != 0x%08X\n",
			movemem[0],movemem[1]);
		if (verbose) {
		f=numprint((movemem[0]>>24)&0xff,-1,8,0);
		fprintf(stdout,"\t\t\tred = %.0f  ",f);
		f=numprint((movemem[0]>>16)&0xff,-1,8,0);
		fprintf(stdout,"\tgreen = %.0f",f);
		f=numprint((movemem[0]>>8)&0xff,-1,8,0);
		fprintf(stdout,"\tblue = %.0f\n",f);

		f=numprint((movemem[2]>>24)&0xff,7,0,7);
		fprintf(stdout,"\t\t\tx = %.3f",f);
		f=numprint((movemem[2]>>16)&0xff,7,0,7);
		fprintf(stdout,"\ty = %.3f",f);
		f=numprint((movemem[2]>>8)&0xff,7,0,7);
		fprintf(stdout,"\tz = %.3f\n",f);
		}
		break;
	  default:
		fprintf(stdout,
			"ERROR : invalid MOVEMEM command: 0x%02X\n",index);
		break;
	}
	break;

      case (char) G_VTX:
	fprintf(stdout,"\tVTX ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	b0 = (char) ((bufp[0] & 0x00f00000) >> 20);
	b1 = (char) ((bufp[0] & 0x000f0000) >> 16);;
	fprintf(stdout,"\t\tn = %d v0 = %d len = %d ptr = %08x\n", 
		b0, b1, len, addr);
	if (verbose) {
	    data = (u32 *) &(DRAM[addr]);
	    while (len > 0) {

		vp = (Vtx_t *) data;
		fprintf(stdout,"\t\t\t%08x ===(pos:  %d %d %d)\n",
			data[0],vp->ob[0],vp->ob[1],vp->ob[2]);
		fprintf(stdout,"\t\t\t%08x\n",data[1]);
		fprintf(stdout,"\t\t\t%08x    (txtr: %04hx %04hx)\n",
			data[2],vp->tc[0],vp->tc[1]);
		fprintf(stdout,"\t\t\t%08x    (colr: %02x %02x %02x %02x)\n",
			data[3],vp->cn[0],vp->cn[1],vp->cn[2],vp->cn[3]);

		data += 4;
		len -= 16;
	    }
	}
	break;

      case (char) G_DL:
	fprintf(stdout,"\tDL ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	b0 = (char) ((bufp[0] & 0x00ff0000) >> 16);
	fprintf(stdout,"\t\tparam = %02x len = %d ptr = %08x\n", b0, len, addr);
	gfxp = (u32 *) &(DRAM[addr]);
	fprintf(stdout,"\n=============== DL Push (%d)=============\n\n",
						++dl_depth);
	if (do_nested)
	    parse_DL(gfxp, len);
	else
	    fprintf(stdout,"\n\n=============== DL Pop (%d)=============\n",
						dl_depth--);
	break;

      default:
	fprintf(stdout,"\tUNKNOWN DMA %02x ",op);
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;
    }
}

/*
 * Parse and dump a IMM-type display list command.
 */
static void
read_imm(u32 *bufp)
{
    char	op, b0, b1, b2, b3;
    int		i0, i1;

    op = ((*bufp & 0xff000000) >> 24);

    switch (op) {

      case (char) G_TRI1:
	fprintf(stdout,"\tTRI1 ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	b0 = (char) ((bufp[1] & 0xff000000) >> 24);
	b1 = (char) ((bufp[1] & 0x00ff0000) >> 16);
	b2 = (char) ((bufp[1] & 0x0000ff00) >>  8);
	b3 = (char) ((bufp[1] & 0x000000ff));
	fprintf(stdout,"\t\tflag = %02x v0 = %d v1 = %d v2 = %d\n", 
		b0, b1, b2, b3);
	break;

      case (char) G_POPMTX:
	fprintf(stdout,"\tPOPMTX ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	b0 = (char) (bufp[1] & 0x000000ff);
	fprintf(stdout,"\t\tparam = %d \n", b0);
	if (exp_matrix) popmatrix(b0);
	break;

      case (char) G_MWO_SEGMENT_0:
	fprintf(stdout,"\tSEGMENT ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	b0 = (char) ((bufp[1] & 0x0f000000) >> 24);
	segment_base[b0] = bufp[1] & 0x00ffffff;
	fprintf(stdout,"\t\tid = %d base = %08x\n", b0, segment_base[b0]);
	break;

      case (char) G_TEXTURE:
	fprintf(stdout,"\tTEXTURE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int) (bufp[0] & 0x0000ffff);
	i1 = (int) ((bufp[1] & 0xffff0000) >> 16);
	b0 = (char) ((bufp[1] & 0x0000ff00) >> 8);
	b1 = (char) (bufp[1] & 0x000000ff);
	fprintf(stdout,"\t\tnum = %d on = %d, s-scale = %04x t-scale = %04x\n",
		b0, b1, i0, i1);
	break;

      case (char) G_SETOTHERMODE_H:
	fprintf(stdout,"\tSETOTHERMODE_H ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	fprintf(stdout,"\t\tw0 = %08x w1 = %08x\n", 
		(bufp[0] & 0x00ffffff), bufp[1]);
	break;

      case (char) G_SETOTHERMODE_L:
	fprintf(stdout,"\tSETOTHERMODE_L ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	fprintf(stdout,"\t\tw0 = %08x w1 = %08x\n", 
		(bufp[0] & 0x00ffffff), bufp[1]);
	break;

      case (char) G_RDPHALF_1:
	fprintf(stdout,"\tRDPHALF_1 ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	fprintf(stdout,"\t\tS=%.2f  T=%.2f\n", 
		(0x80000000&bufp[1])?((float)((bufp[1]>>16)&0x7fff)/-32.0):
					((float)((bufp[1]>>16)&0x7fff)/32.0),
		(0x8000&bufp[1])?((float)((bufp[1])&0x7fff)/-32.0):
					((float)((bufp[1])&0x7fff)/32.0));
	break;

      case (char) G_RDPHALF_2:
	fprintf(stdout,"\tRDPHALF_2 ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	fprintf(stdout,"\t\tDsDx=%.4f  DtDy=%.4f\n", 
		(0x80000000&bufp[1])?((float)((bufp[1]>>16)&0x7fff)/-1024.0):
					((float)((bufp[1]>>16)&0x7fff)/1024.0),
		(0x8000&bufp[1])?((float)((bufp[1])&0x7fff)/-1024.0):
					((float)((bufp[1])&0x7fff)/1024.0));
	break;

/*      case (char) 0xb3:	/* hack for now... */
      case (char) G_ENDDL:
	fprintf(stdout,"\tENDDL ");
	fprintf(stdout,"\t\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETGEOMETRYMODE:
	fprintf(stdout,"\tSETGEOMETRYMODE ");
	fprintf(stdout,"\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	fprintf(stdout,"\t\tmode = %04x \n", (bufp[1] & 0x0000ffff));
	break;

      case (char) G_CLEARGEOMETRYMODE:
	fprintf(stdout,"\tCLEARGEOMETRYMODE ");
	fprintf(stdout,"\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	fprintf(stdout,"\t\tmode = %04x \n", (bufp[1] & 0x0000ffff));
	break;

      case (char) G_PERSPNORMALIZE:
	fprintf(stdout,"\tPERSPNORMALIZE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      default:
	fprintf(stdout,"\tUNKNOWN IMM %02x ",op);
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;
    }
}

/*
 * Parse and dump a RDP-type display list command.
 */
static void
read_rdp(u32 *bufp)
{
    u8		seg_id;
    u32		addr;
    int		i0, i1, i2, i3;
    char	op, b0;

    op = ((*bufp & 0xff000000) >> 24);

    switch (op) {

      case (char) G_NOOP:
	fprintf(stdout,"\tNOOP ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETCIMG:
	fprintf(stdout,"\tSETCIMG ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int) ((bufp[0] & 0x00fff000) >> 12);
	i1 = (int) ((bufp[0] & 0x00000fff));
	b0 = (char)  ((bufp[0] & 0xfc000000) >> 26);
	seg_id = (u8) ((bufp[1] & 0x0f000000) >> 24);
	addr = segment_base[seg_id] + (bufp[1] & 0x00ffffff);
	fprintf(stdout,"\t\tw = %d h = %d t = %d ptr = %08x\n", 
		i0, i1, b0, addr);
	break;

      case (char) G_SETZIMG:
	fprintf(stdout,"\tSETZIMG ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int) ((bufp[0] & 0x00fff000) >> 12);
	i1 = (int) ((bufp[0] & 0x00000fff));
	b0 = (char)  ((bufp[0] & 0xfc000000) >> 26);
	seg_id = (u8) ((bufp[1] & 0x0f000000) >> 24);
	addr = segment_base[seg_id] + (bufp[1] & 0x00ffffff);
	fprintf(stdout,"\t\tw = %d h = %d t = %d ptr = %08x\n", 
		i0, i1, b0, addr);
	break;

      case (char) G_SETTIMG:
	fprintf(stdout,"\tSETTIMG ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int) ((bufp[0] & 0x00ff0000) >> 16);
	i1 = (int) ((bufp[0] & 0x00000fff));
	b0 = (char)  ((bufp[0] & 0xfc000000) >> 26);
	seg_id = (u8) ((bufp[1] & 0x0f000000) >> 24);
	addr = segment_base[seg_id] + (bufp[1] & 0x00ffffff);
	fprintf(stdout,"\t\tfmt = %d sz = %d w = %d ptr = %08x\n", 
		(i0 >> 5), ((i0 >> 3) & 0x3), i1, b0, addr);
	break;

      case (char) G_SETCOMBINE:
	fprintf(stdout,"\tSETCOMBINE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETENVCOLOR:
	fprintf(stdout,"\tSETENVCOLOR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00ffffff));
	i1 = (int)  ((bufp[1] & 0xffffffff));
	fprintf(stdout,"\t\tt = %08x c = %08x\n", i0, i1);
	break;

      case (char) G_SETPRIMCOLOR:
	fprintf(stdout,"\tSETPRIMCOLOR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00ffffff));
	i1 = (int)  ((bufp[1] & 0xffffffff));
	fprintf(stdout,"\t\tt = %08x c = %08x\n", i0, i1);
	break;

      case (char) G_SETBLENDCOLOR:
	fprintf(stdout,"\tSETBLENDCOLOR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00ffffff));
	i1 = (int)  ((bufp[1] & 0xffffffff));
	fprintf(stdout,"\t\tt = %08x c = %08x\n", i0, i1);
	break;

      case (char) G_SETFOGCOLOR:
	fprintf(stdout,"\tSETFOGCOLOR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00ffffff));
	i1 = (int)  ((bufp[1] & 0xffffffff));
	fprintf(stdout,"\t\tt = %08x c = %08x\n", i0, i1);
	break;

      case (char) G_SETFILLCOLOR:
	fprintf(stdout,"\tSETFILLCOLOR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00ffffff));
	i1 = (int)  ((bufp[1] & 0xffffffff));
	fprintf(stdout,"\t\tt = %08x c = %08x\n", i0, i1);
	break;

      case (char) G_FILLRECT:
	fprintf(stdout,"\tFILLRECT ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00fff000) >> 12);
	i1 = (int)  ((bufp[0] & 0x00000fff));
	i2 = (int)  ((bufp[1] & 0x00fff000) >> 12);
	i3 = (char) ((bufp[1] & 0x00000fff));
	fprintf(stdout,"\t\tx0 = %d y0 = %d x1 = %d y1 = %d\n",i0,i1,i2,i3);
	break;

      case (char) G_SETTILE:
	fprintf(stdout,"\tSETTILE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_LOADTILE:
	fprintf(stdout,"\tLOADTILE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_LOADBLOCK:
	fprintf(stdout,"\tLOADBLOCK ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETTILESIZE:
	fprintf(stdout,"\tSETTILESIZE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_LOADTLUT:
	fprintf(stdout,"\tLOADTLUT ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_RDPSETOTHERMODE:
	fprintf(stdout,"\tRDPSETOTHERMODE ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETPRIMDEPTH:
	fprintf(stdout,"\tSETPRIMDEPTH ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETSCISSOR:
	fprintf(stdout,"\tSETSCISSOR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETCONVERT:
	fprintf(stdout,"\tSETCONVERT ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETKEYR:
	fprintf(stdout,"\tSETKEYR ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_SETKEYGB:
	fprintf(stdout,"\tSETKEYGB ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_RDPFULLSYNC:
	fprintf(stdout,"\tRDPFULLSYNC ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_RDPTILESYNC:
	fprintf(stdout,"\tRDPTILESYNC ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_RDPPIPESYNC:
	fprintf(stdout,"\tRDPPIPESYNC ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_RDPLOADSYNC:
	fprintf(stdout,"\tRDPLOADSYNC ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;

      case (char) G_TEXRECTFLIP:
	fprintf(stdout,"\tTEXRECTFLIP ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00fff000) >> 12);
	i1 = (int)  ((bufp[0] & 0x00000fff));
	i2 = (int)  ((bufp[1] & 0x00fff000) >> 12);
	i3 = (char) ((bufp[1] & 0x00000fff));
	fprintf(stdout,"\t\tx0 = %d y0 = %d x1 = %d y1 = %d\n",i0,i1,i2,i3);
	break;

      case (char) G_TEXRECT:
	fprintf(stdout,"\tTEXRECT ");
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	i0 = (int)  ((bufp[0] & 0x00fff000) >> 12);
	i1 = (int)  ((bufp[0] & 0x00000fff));
	i2 = (int)  ((bufp[1] & 0x00fff000) >> 12);
	i3 = (char) ((bufp[1] & 0x00000fff));
	fprintf(stdout,"\t\tx0 = %d y0 = %d x1 = %d y1 = %d\n",i0,i1,i2,i3);
	break;

      default:
	fprintf(stdout,"\tUNKNOWN %02x ",op);
	fprintf(stdout,"\t\t\t\t%08x %08x\n",bufp[0],bufp[1]);
	break;
    }
}

/*
 * main routine.
 */
int
main(int argc, char *argv[])
{
    FILE	*in;
    u32		*gfxp;
    int		i, len;
    char	filename[50];
    OSTask_t	task;

    while ((argc > 1) && (argv[1][0] == '-')) {
	switch(argv[1][1]) {

	  case 'i':
	    use_verifyinfo=TRUE;
	    break;

	  case 'c':
	    row_major = TRUE;
	    exp_matrix = TRUE;
	    verbose = TRUE;
	    break;

	  case 'p':
	    exp_mp = TRUE;
	    exp_matrix = TRUE;
	    verbose = TRUE;
	    break;

	  case 'm':
	    exp_matrix = TRUE;
	    verbose = TRUE;
	    break;

	  case 'n':
	    do_nested = FALSE;
	    break;

	  case 'v':
	    verbose = TRUE;
	    break;

	  default:
	    fprintf(stderr,"%s : unknown argument [%s].\n",argv[0],argv[1]);
	    break;
	}
	argc--;
	argv++;
    }

    if (argc < 2) {
	fprintf(stderr,"usage: %s %s.\n",argv[0],UsageString);
	fprintf(stderr,"OPTIONS:\n");
	fprintf(stderr,"  -v  verbose (show DMA'd data)\n");
	fprintf(stderr,"  -n  nesting off\n");
	fprintf(stderr,"  -m  show matrices in floating point\n");
	fprintf(stderr,"  -p  also show modeling and projection matrices\n");
	fprintf(stderr,"  -c  turn column major off (see matrices row major)\n");
	exit(-1);
    }

    strcpy(filename,argv[1]);
    strcat(filename,".mem");
    if ((in=fopen(filename,"r"))==NULL) {
        if ((in=fopen(argv[1],"r"))==NULL) {
	    fprintf(stderr,"can't open file [%s] or [%s].\n",filename,argv[1]);
	    exit(-1);
	}
    }

    fprintf(stderr,"loading DRAM data.");
    gfxp = (u32 *) &(DRAM[0]);
    i = 0;
    while (!feof(in)) {
	if ((i % 1048576) == 0)
	    fprintf(stderr,".");
	fread(gfxp, sizeof(u32), 1, in);
	gfxp++;
	i += 4;
    }
    fclose(in);
    fprintf(stderr,"done.\n");

    if (use_verifyinfo) {
        gfxp = (u32 *) &(DRAM[VERIFY_INFO_PHYSADDR + 0]);
        i = (int) *gfxp;
        gfxp = (u32 *) &(DRAM[VERIFY_INFO_PHYSADDR + 4]);
        len = (int) *gfxp;
    } else {
    	strcpy(filename,argv[1]);
    	strcat(filename,".tsk");
        if ((in=fopen(filename,"r"))==NULL) {
	    fprintf(stderr,"can't open file [%s].\n",filename);
	    fprintf(stderr,"To mbi2read a file with verifyinfo use the -i flag\n");
	    exit(-1);
	}
	fread(&task, sizeof(OSTask), 1, in);
        fclose(in);

        i = (int) task.data_ptr;
        len = (int) task.data_size;
	printf("data_ptr=%x   task.data_size=%x\n",task.data_ptr,task.data_size);
	/* len = 10000; */	
    }

    fprintf(stdout,"\n\t\t\tReadable dump of [%s]:\n\n",argv[1]);
    fprintf(stdout,"TASK : dl = %08x len = %d ucode = %08x type = %08x\n",
	    i, len, 0, 0);
    fprintf(stdout,
	    "------------------------------------------------------------------------------\n");
    fprintf(stdout,"GFX Display List:\n\n");


    /* extract only the offset into 2 MB memory */
    i = i&0x3fffff;
    gfxp = (u32 *) &(DRAM[i]);
    parse_DL(gfxp, len);

}
