
/*
 * setup.c
 *
 * a short test program to test the polygon setup algorithm
 * for the RSP.
 *
 * Wed May 18 14:40:25 PDT 1994
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bstring.h>
#include <math.h>

#include <gl.h>
#include <PRimage.h>


#ifndef true
#   define true		1
#endif
#ifndef false
#   define false	0
#endif
#define Min(a,b)	((a > b) ? (b) : (a))
#define Max(a,b)	((a < b) ? (b) : (a))
#define Clamp255(a)	((a < 256) ? (a) : 255)
#define Clamp255f(a)	(((a) < 0x00010000) ? (0x00000000) :		\
			 (((a) < 0x01000000) ? (a) : 0x00ff0000))
#define FRAC_ONE	(0x00010000)
#define XRES	640
#define YRES	480
#define DIR_FLAG	0x0080

#define STL_PREC                (1 << 21)
#define W_PREC                  ((unsigned)(1 << 31))
#define Z_PREC                  (1 << 16)
#define RGBA_PREC               (1 << 16)

/*
#define PLEQ_SCALE_LOG	(6)
*/
#define PLEQ_SCALE_LOG	(0)


typedef int		bool;
typedef unsigned char	u8;
typedef unsigned short int	u16;
typedef short int	i16;
typedef long int	i32;

typedef struct xy_st {
    i16		x, y;	/* S11.2 */
    u8		r, g, b, a;
    i16		s, t;	/* S10.5 */
    i32		z;
} point_td;

typedef struct rgb_st {
    u8		r, g, b, a;
} rgb_td;

/*
 * This structure mimic's the RDP edge coefficients.
 */
typedef struct edge_st {
    u8		command;	/* what kind */
    u8		flag;		/* pad:3, dir:1, tile:4 */
    i16		yLow;		/* S11.2 precision */
    i16		yMid;		/* S11.2 precision */
    i16		yHigh;		/* S11.2 precision */
    i32		xLow;		/* S15.16 */
    i32		DxXLDy;		/* S15.16 */
    i32		xHigh;		/* S15.16 */
    i32		DxXHDy;		/* S15.16 */
    i32		xMid;		/* S15.16 */
    i32		DxXMDy;		/* S15.16 */
    i32		r, g, b, a;
    i32		dxr, dxg, dxb, dxa;	/* x change */
    i32		der, deg, deb, dea;	/* major edge change */
    i32		dyr, dyg, dyb, dya;	/* y change */
    i32		s, t;
    i32		dxs, dxt;	/* x change */
    i32		des, det;	/* major edge change */
    i32		dys, dyt;	/* y change */
    i32		z;
    i32		dxz;
    i32		dez;
    i32		dyz;
} setup_td;

char		output_fname[80];
rgb_td		image[YRES][XRES];

unsigned short rbuf[8192];
unsigned short gbuf[8192];
unsigned short bbuf[8192];
unsigned short abuf[8192];

/*
static int	init_min_r = 0, init_min_g = 0, init_min_b = 255;
static int	init_mid_r = 255, init_mid_g = 255, init_mid_b = 255;
static int	init_max_r = 0, init_max_g = 255, init_max_b = 0;
*/
static int	init_min_r = 0, init_min_g = 0, init_min_b = 255;
static int	init_mid_r = 31, init_mid_g = 0, init_mid_b = 255;
static int	init_max_r = 31, init_max_g = 31, init_max_b = 255;

point_td	pointList[32];

/*
 * Fixed point divide.
 */
i32
FixDiv(i32 a, i32 b)
{
    float	af, bf, cf;
    i32		val;

    af = (float) ((float) a / (float) 65536.0);
    bf = (float) ((float) b / (float) 65536.0);
    if (bf == 0.0)
	cf = 0.0;
    else
	cf = af / bf;
    val = (i32) (cf * 65536.0);
    return(val);
}

/*
 * Fixed point multiply.
 */
i32
FixMult(i32 a, i32 b)
{
    float	af, bf, cf;
    i32		val;

    af = (float) ((float) a / (float) 65536.0);
    bf = (float) ((float) b / (float) 65536.0);
    cf = af * bf;
    if (cf > 32767.0 || cf < -32767.0) {
	if ((af < 0  && bf >= 0) || (af >= 0 && bf < 0)) {
	    val = 0x80000000;	/* big negative */
	} else {
	    val = 0x7fffffff;	/* big positive */
	}
    } else
	val = (i32) (cf * 65536.0);
    return(val);
}

void
dump_setup(setup_td *s)
{
    fprintf(stdout,"\n\t    Edge coefficients:	\t\tcmd = %02x\n",s->command);
    fprintf(stdout,"\t\tdir = %d level = %d tile = %d\n",
	    ((s->flag & 0x80) >> 7), 
	    ((s->flag & 0x38) >> 3), 
	    ((s->flag & 0x07)));
    fprintf(stdout,"\t\tYL =     %04hx\tYM =        %04hx\tYH =        %04hx\n",
	    s->yLow, s->yMid, s->yHigh);
    fprintf(stdout,"\t\t     %8.3f\t        %8.3f\t        %8.3f\n",
	    (float)s->yLow/4.0, (float)s->yMid/4.0, (float)s->yHigh/4.0);
    fprintf(stdout,"\t\tXL = %08x\tDxLDy = %08x\n",
	    s->xLow, s->DxXLDy);
    fprintf(stdout,"\t\t     %8.3f\t        %11.6f\n",
	    ((float)s->xLow / 65536.0), ((float)s->DxXLDy / 65536.0));
    fprintf(stdout,"\t\tXH = %08x\tDxHDy = %08x\n",
	    s->xHigh, s->DxXHDy);
    fprintf(stdout,"\t\t     %8.3f\t        %11.6f\n",
	    ((float)s->xHigh / 65536.0), ((float)s->DxXHDy / 65536.0));
    fprintf(stdout,"\t\tXM = %08x\tDxMDy = %08x\n",
	    s->xMid, s->DxXMDy);
    fprintf(stdout,"\t\t     %8.3f\t        %11.6f\n",
	    ((float)s->xMid / 65536.0), ((float)s->DxXMDy / 65536.0));





    fprintf(stdout,"\n\t    Shade coefficients:\n");
    fprintf(stdout,"\t\t  red %08x green %08x  blue %08x alpha %08x\n",
	    s->r, s->g, s->b, s->a);
    fprintf(stdout,"\t\t     R  %8.6f\t        G  %8.6f\n", 
	    ((float)s->r/65536.0),
	    ((float)s->g/65536.0));
    fprintf(stdout,"\t\t     B  %8.6f\t        A  %8.6f\n", 
	    ((float)s->b/65536.0),
	    ((float)s->a/65536.0));
    fprintf(stdout,"\n");

    fprintf(stdout,"\t\t DrDx %08x  DgDx %08x  DbDx %08x  DaDx %08x\n",
	    s->dxr, s->dxg, s->dxb, s->dxa);
    fprintf(stdout,"\t\t  dRdX  %8.6f\t     dGdX  %8.6f\n", 
	    ((float)s->dxr/65536.0),
	    ((float)s->dxg/65536.0));
    fprintf(stdout,"\t\t  dBdX  %8.6f\t     dBdX  %8.6f\n", 
	    ((float)s->dxb/65536.0),
	    ((float)s->dxa/65536.0));
    fprintf(stdout,"\n");


    fprintf(stdout,"\t\t DrDe %08x  DgDe %08x  DbDe %08x  DaDe %08x\n",
	    s->der, s->deg, s->deb, s->dea);
    fprintf(stdout,"\t\t  dRdE  %8.6f\t     dGdE  %8.6f\n", 
	    ((float)s->der/65536.0),
	    ((float)s->deg/65536.0));
    fprintf(stdout,"\t\t  dBdE  %8.6f\t     dAdE  %8.6f\n", 
	    ((float)s->deb/65536.0),
	    ((float)s->dea/65536.0));
    fprintf(stdout,"\n");

    fprintf(stdout,"\t\t DrDy %08x  DgDy %08x  DbDy %08x  DaDy %08x\n",
	    s->dyr, s->dyg, s->dyb, s->dya);

    fprintf(stdout,"\t\t  dRdY  %8.6f\t     dGdY  %8.6f\n", 
	    ((float)s->dyr/65536.0),
	    ((float)s->dyg/65536.0));
    fprintf(stdout,"\t\t  dBdY  %8.6f\t     dAdY  %8.6f\n", 
	    ((float)s->dyb/65536.0),
	    ((float)s->dya/65536.0));
    fprintf(stdout,"\n");



/*
    fprintf(stdout,"\n\t    Texture coefficients:\n");
    fprintf(stdout,"\t\t  S %08x  T %08x  W %08x  L %08x\n", 
	    s->s, s->t, 0, 0);
    fprintf(stdout,"\t\t     S  %8.6f\t        T  %8.6f\n", 
	    (float) s->s / STL_PREC, (float) s->t / STL_PREC);
    fprintf(stdout,"\t\t     W  %8.6f\t        L  %8.6f\n", 
	    (float) 0 / W_PREC, (float) 0 / STL_PREC);
    fprintf(stdout,"\n");
    fprintf(stdout,"\t\t  dSdX %08x  dTdX %08x  dWdX %08x  dLdX %08x\n", 
	    s->dxs, s->dxt, 0, 0);
    fprintf(stdout,"\t\t  dSdX  %8.6f\t     dTdX  %8.6f\n", 
	    (float) s->dxs / STL_PREC, (float) s->dxt / STL_PREC);
    fprintf(stdout,"\t\t  dWdX  %8.6f\t     dLdX  %8.6f\n", 
	    (float) 0 / W_PREC, (float) 0 / STL_PREC);
    fprintf(stdout,"\n");
    fprintf(stdout,"\t\t  dSdE %08x  dTdE %08x  dWdE %08x  dLdE %08x\n", 
	    s->des, s->det, 0, 0);
    fprintf(stdout,"\t\t  dSdE  %8.6f\t     dTdE  %8.6f\n", 
	    (float) s->des / STL_PREC, (float) s->det / STL_PREC);
    fprintf(stdout,"\t\t  dWdE  %8.6f\t     dLdE  %8.6f\n", 
	    (float) 0 / W_PREC, (float) 0 / STL_PREC);
    fprintf(stdout,"\n");
    fprintf(stdout,"\t\t  dSdY %08x  dTdY %08x  dWdY %08x  dLdY %08x\n", 
	    s->dys, s->dyt, 0, 0);
    fprintf(stdout,"\t\t  dSdY  %8.6f\t     dTdY  %8.6f\n", 
	    (float) s->dys / STL_PREC, (float) s->dyt / STL_PREC);
    fprintf(stdout,"\t\t  dWdY  %8.6f\t     dLdY  %8.6f\n", 
	    (float) 0 / W_PREC, (float) 0 / STL_PREC);

    fprintf(stdout,"\n\t    Z-buffer coefficients:\n");
    fprintf(stdout,"\t\t  Z %08x  dZdX %08x  dZdE %08x  dZdY %08x\n", 
	    s->z, s->dxz, s->dez, s->dyz);
    fprintf(stdout,"\t\t     Z  %8.6f\t     dZdX  %8.6f\n", 
	    (float)   s->z / 65536.0, (float) s->dxz / 65536.0);
    fprintf(stdout,"\t\t  dZdE  %8.6f\t     dZdY  %8.6f\n", 
	    (float) s->dez / 65536.0, (float) s->dyz / 65536.0);
*/

}

i32
pleq_coef(i32 axi, i32 ayi, i32 bxi, i32 byi, 
	  i32 *axo, i32 *ayo, i32 *bxo, i32 *byo)
{
    i32	r, inv_r;

    r = axi*byi - ayi*bxi;

    fprintf(stderr,"r = %08x %08x*%08x - %08x*%08x\n",
	    r,axi,byi,ayi,bxi);

    r >>= (PLEQ_SCALE_LOG + 2);

    inv_r = FixDiv(FRAC_ONE, r);

    *axo = axi;
    *ayo = ayi;
    *bxo = bxi;
    *byo = byi;

/*
    fprintf(stderr,"r = %08x\n",r);

    *axo = FixMult(axi, inv_r);
    *ayo = FixMult(ayi, inv_r);
    *bxo = FixMult(bxi, inv_r);
    *byo = FixMult(byi, inv_r);
*/

    return (inv_r);
}

void
pleq_dxdy(i32 inv_r, i32 ax, i32 ay, i32 bx, i32 by, i32 ac, i32 bc, i32 *cx, i32 *cy)
{
/*
    *cx = FixMult(ay, ac) - FixMult(by, bc);
*/
    *cx = FixMult(by, ac) - FixMult(ay, bc);
    *cy = FixMult(ax, bc) - FixMult(bx, ac);

    fprintf(stderr,"cx : %08x = %08x * %08x - %08x * %08x\n",
	    *cx,ay,ac,by,bc);

    *cx = FixMult(*cx, inv_r);
    *cy = FixMult(*cy, inv_r);

/*
    *cx >>= PLEQ_SCALE_LOG;
    *cy >>= PLEQ_SCALE_LOG;
*/
}

/*
 * Function that does the setup, filling in a setup structure.
 * Input points in any order.
 */
static void
do_setup(setup_td *setup, point_td *min_p, point_td *mid_p, point_td *max_p)
{
    point_td	*tmp_p;
    i32		Hdx, Mdx, Ldx, Hdy, Mdy, Ldy, r;
    i32		ax, ay, bx, by;
    i32		dxr, dyr, dxg, dyg, dxb, dyb, dxa, dya, dxs, dys, dxt, dyt;
    i32		dxz, dyz;

    bzero(setup, sizeof(setup_td));

    /* sort in y: */
    if (min_p->y > mid_p->y) {
	tmp_p = mid_p;	mid_p = min_p;	min_p = tmp_p;
    }
    if (mid_p->y > max_p->y) {
	tmp_p = max_p;	max_p = mid_p;	mid_p = tmp_p;
	if (min_p->y > mid_p->y) {
	    tmp_p = mid_p;  mid_p = min_p;  min_p = tmp_p;
	}
    }

    /* colors for debugging only... */
/*
    min_p->r = 0; min_p->g = 255;   min_p->b = 0;	min_p->a = 255;
    mid_p->r = 255;   mid_p->g = 0; mid_p->b = 0;	mid_p->a = 255;
    max_p->r = 0;   max_p->g = 0;   max_p->b = 255;	max_p->a = 255;
*/
/*
    min_p->r = init_min_r;    min_p->g = init_min_g;    min_p->b = init_min_b;
    mid_p->r = init_mid_r;    mid_p->g = init_mid_g;    mid_p->b = init_mid_b;
    max_p->r = init_max_r;    max_p->g = init_max_g;    max_p->b = init_max_b;

    init_min_r = 0;    init_min_g = 0;    init_min_b = 255;
    init_mid_r = 255;    init_mid_g = 0;    init_mid_b = 0;
    init_max_r = 0;    init_max_g = 255;    init_max_b = 0;
*/
/*
    init_min_r = 0;    init_min_g = 0;    init_min_b = 255;
    init_mid_r = 0;    init_mid_g = 31;    init_mid_b = 255;
    init_max_r = 31;    init_max_g = 31;    init_max_b = 255;
*/

    /* edge deltas: */
    Ldx = max_p->x - mid_p->x;		Ldy = max_p->y - mid_p->y;
    Mdx = mid_p->x - min_p->x;		Mdy = mid_p->y - min_p->y;
    Hdx = max_p->x - min_p->x;		Hdy = max_p->y - min_p->y;

    r = pleq_coef(Hdx, Hdy, Mdx, Mdy, &ax, &ay, &bx, &by);
    /* sign of r (after sort) is left/right direction */

    setup->DxXLDy = FixDiv(Ldx, Ldy);	/* guarenteed to be safe */
    setup->DxXMDy = FixDiv(Mdx, Mdy);
    setup->DxXHDy = FixDiv(Hdx, Hdy);
    setup->DxXLDy &= 0xfffffff8;	/* clear lower bits to match ew */
    setup->DxXMDy &= 0xfffffff8;
    setup->DxXHDy &= 0xfffffff8;

    /* left-major or right-major? */
    setup->flag = (setup->flag & ~DIR_FLAG);/* left major,  dir = 0 */
    if (r < 0)
	setup->flag = (setup->flag | DIR_FLAG);	/* right major, dir = 1 */
	
    setup->yLow  = max_p->y;	/* setup y's are S11.2 */
    setup->yMid  = mid_p->y;
    setup->yHigh = min_p->y;

    setup->xLow =  (i32)mid_p->x << 14;	/* setup x's are S15.16 */
    setup->xMid =  (i32)min_p->x << 14;
    setup->xHigh = (i32)min_p->x << 14;

    /* adjust xHigh and xMid up to integer y */
    setup->xHigh = (setup->xHigh - 
		    FixMult(setup->DxXHDy, (setup->yHigh & 0x00000003) << 14));
    setup->xMid  = (setup->xMid - 
		    FixMult(setup->DxXMDy, (setup->yHigh & 0x00000003) << 14));
    /* setup->xLow = max_p->y; already on the grid */

    /* attribute deltas: */
    dxr = max_p->r - min_p->r;    dyr = mid_p->r - min_p->r;
    dxg = max_p->g - min_p->g;    dyg = mid_p->g - min_p->g;
    dxb = max_p->b - min_p->b;    dyb = mid_p->b - min_p->b;
    dxa = max_p->a - min_p->a;    dya = mid_p->a - min_p->a;
    dxs = max_p->s - min_p->s;    dys = mid_p->s - min_p->s;
    dxt = max_p->t - min_p->t;    dyt = mid_p->t - min_p->t;
    dxz = max_p->z - min_p->z;    dyz = mid_p->z - min_p->z;
    dxr <<= 16;    dyr <<= 16;
    dxg <<= 16;    dyg <<= 16;
    dxb <<= 16;    dyb <<= 16;
    dxa <<= 16;    dya <<= 16;
    dxs <<= 16;    dys <<= 16;
    dxt <<= 16;    dyt <<= 16;

/*
    fprintf(stderr,"minz = %08x midz = %08x maxz = %08x\n",
	    min_p->z, mid_p->z, max_p->z);
    fprintf(stderr,"dxz = %08x dyz = %08x\n",dxz,dyz);
*/

    /* plane equation attributes: */
    pleq_dxdy(r, ax, ay, bx, by, dxr, dyr, &(setup->dxr), &(setup->dyr));
    pleq_dxdy(r, ax, ay, bx, by, dxg, dyg, &(setup->dxg), &(setup->dyg));
    pleq_dxdy(r, ax, ay, bx, by, dxb, dyb, &(setup->dxb), &(setup->dyb));
    pleq_dxdy(r, ax, ay, bx, by, dxa, dya, &(setup->dxa), &(setup->dya));
    pleq_dxdy(r, ax, ay, bx, by, dxs, dys, &(setup->dxs), &(setup->dys));
    pleq_dxdy(r, ax, ay, bx, by, dxt, dyt, &(setup->dxt), &(setup->dyt));
    pleq_dxdy(r, ax, ay, bx, by, dxz, dyz, &(setup->dxz), &(setup->dyz));

/*
    fprintf(stderr,"pleq: r = %08x dxz = %08x dyz = %08x\n",
	    r, setup->dxz,setup->dyz);
*/

    /* convert to edge slope: */
    setup->der = setup->dyr + FixMult(setup->dxr, setup->DxXHDy);
    setup->deg = setup->dyg + FixMult(setup->dxg, setup->DxXHDy);
    setup->deb = setup->dyb + FixMult(setup->dxb, setup->DxXHDy);
    setup->dea = setup->dya + FixMult(setup->dxa, setup->DxXHDy);
    setup->des = setup->dys + FixMult(setup->dxs, setup->DxXHDy);
    setup->det = setup->dyt + FixMult(setup->dxt, setup->DxXHDy);
    setup->dez = setup->dyz + FixMult(setup->dxz, setup->DxXHDy);

    /* adjust attributes: */
    setup->r = Clamp255f(((i32)min_p->r << 16) - 
			 FixMult(setup->der, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxr, (setup->xHigh & 0xffff)));
    setup->g = Clamp255f(((i32)min_p->g << 16) - 
			 FixMult(setup->deg, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxg, (setup->xHigh & 0xffff)));
    setup->b = Clamp255f(((i32)min_p->b << 16) - 
			 FixMult(setup->deb, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxb, (setup->xHigh & 0xffff)));
    setup->a = Clamp255f(((i32)min_p->a << 16) -
			 FixMult(setup->dea, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxa, (setup->xHigh & 0xffff)));
    setup->s = (((i32)min_p->s << 16) -
			 FixMult(setup->des, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxs, (setup->xHigh & 0xffff)));
    setup->t = (((i32)min_p->t << 16) -
			 FixMult(setup->det, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxt, (setup->xHigh & 0xffff)));
    setup->z = (((i32)min_p->z) -
			 FixMult(setup->dez, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxz, (setup->xHigh & 0xffff)));

    setup->z   <<= 5;
    setup->dxz <<= 5;
    setup->dyz <<= 5;
    setup->dez <<= 5;

}


/*
 * Function that does the setup for lines, filling in a setup structure.
 * Input 2 points in any order.
 */
static void
do_line(setup_td *setup, point_td *min_p, point_td *max_p)
{
    point_td	*tmp_p;
    i32		Hdx, Hdy, r;
    i32		ax, ay, bx, by;
    i32		dxr, dyr, dxg, dyg, dxb, dyb, dxa, dya, dxs, dys, dxt, dyt;
    i32		dxz, dyz;
    i32		xoff = 0;

    bzero(setup, sizeof(setup_td));

    /* sort in x: */
    if (min_p->x > max_p->x) {
	tmp_p = max_p;	max_p = min_p;	min_p = tmp_p;
    }

    /* sort in y: */
    if (min_p->y > max_p->y) {
	tmp_p = max_p;	max_p = min_p;	min_p = tmp_p;
    }

    /* edge deltas: */
    Hdx = max_p->x - min_p->x;
    Hdy = max_p->y - min_p->y;
    setup->DxXHDy = FixDiv(Hdx, Hdy);
    setup->DxXHDy &= 0xfffffff8;
    setup->DxXMDy = setup->DxXHDy;

    /* left-major or right-major? */
    setup->flag = (setup->flag & ~DIR_FLAG);/* left major,  dir = 0 */
    if ((Hdx < 0) && (Hdx < Hdy)) {
	setup->flag = (setup->flag | DIR_FLAG); /* right major, dir = 1 */
    }
	
    setup->yLow  = max_p->y;	/* setup y's are S11.2 */
    setup->yMid  = max_p->y;
    setup->yHigh = min_p->y;

    setup->xMid =  (i32)min_p->x << 14;	/* setup x's are S15.16 */
    setup->xHigh = (i32)min_p->x << 14;
    setup->xLow = (i32)max_p->x << 14;

    if (Hdx == 0 && (setup->flag & DIR_FLAG)) {
	xoff = 0xffff8000;
    } else if (Hdx == 0) {
	xoff = 0x00008000;
    }

    /* do width */
    setup->xHigh = setup->xHigh + FixMult(0x00008000, setup->DxXHDy) + xoff;
    setup->xMid  = setup->xMid  - FixMult(0x00008000, setup->DxXHDy) - xoff;

    /* special case horizontal lines... */
    if (Hdy == 0) {
	setup->DxXHDy = 0x00000000;
	setup->xMid =  (i32)max_p->x << 14;	/* setup x's are S15.16 */
	setup->xHigh = (i32)min_p->x << 14;
	setup->xLow = (i32)max_p->x << 14;
	setup->yLow  = max_p->y;	/* setup y's are S11.2 */
	setup->yMid  = max_p->y - (0x01 << 2);
	setup->yHigh = min_p->y - (0x01 << 2);
	setup->flag = (setup->flag | DIR_FLAG); /* right major, dir = 1 */
    }

    /* adjust xHigh and xMid up to integer y */
    setup->xHigh = (setup->xHigh - 
		    FixMult(setup->DxXHDy, (setup->yHigh & 0x00000003) << 14));
    setup->xMid  = (setup->xMid - 
		    FixMult(setup->DxXMDy, (setup->yHigh & 0x00000003) << 14));

    /* attribute deltas: */
    dxr = max_p->r - min_p->r;
    dxg = max_p->g - min_p->g;
    dxb = max_p->b - min_p->b;
    dxa = max_p->a - min_p->a;
    dxs = max_p->s - min_p->s;
    dxt = max_p->t - min_p->t;
    dxz = max_p->z - min_p->z;
    dxr <<= 16;
    dxg <<= 16;
    dxb <<= 16;
    dxa <<= 16;
    dxs <<= 16;
    dxt <<= 16;

    setup->dyr = FixDiv(dxr, (Hdy << 14));
    setup->dyg = FixDiv(dxg, (Hdy << 14));
    setup->dyb = FixDiv(dxb, (Hdy << 14));
    setup->dya = FixDiv(dxa, (Hdy << 14));

    setup->dxr = FixDiv(dxr, (Hdx << 14));
    setup->dxg = FixDiv(dxg, (Hdx << 14));
    setup->dxb = FixDiv(dxb, (Hdx << 14));
    setup->dxa = FixDiv(dxa, (Hdx << 14));

#if 0
    if (Hdx >= Hdy) {
	setup->der = setup->dxr;
	setup->deg = setup->dxg;
	setup->deb = setup->dxb;
	setup->dea = setup->dxa;
    } else {
	setup->der = setup->dyr;
	setup->deg = setup->dyg;
	setup->deb = setup->dyb;
	setup->dea = setup->dya;
    }
#endif
	setup->der = setup->dyr;
	setup->deg = setup->dyg;
	setup->deb = setup->dyb;
	setup->dea = setup->dya;

    setup->r = (min_p->r << 16);
    setup->g = (min_p->g << 16);
    setup->b = (min_p->b << 16);
    setup->a = (min_p->a << 16);

#if 0
    /* convert to edge slope: */
    setup->der = setup->dyr + FixMult(setup->dxr, setup->DxXHDy);
    setup->deg = setup->dyg + FixMult(setup->dxg, setup->DxXHDy);
    setup->deb = setup->dyb + FixMult(setup->dxb, setup->DxXHDy);
    setup->dea = setup->dya + FixMult(setup->dxa, setup->DxXHDy);
    setup->des = setup->dys + FixMult(setup->dxs, setup->DxXHDy);
    setup->det = setup->dyt + FixMult(setup->dxt, setup->DxXHDy);
    setup->dez = setup->dyz + FixMult(setup->dxz, setup->DxXHDy);
#endif

#if 0
    /* adjust attributes: */
    setup->r = Clamp255f(((i32)min_p->r << 16) - 
			 FixMult(setup->der, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxr, (setup->xHigh & 0xffff)));
    setup->g = Clamp255f(((i32)min_p->g << 16) - 
			 FixMult(setup->deg, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxg, (setup->xHigh & 0xffff)));
    setup->b = Clamp255f(((i32)min_p->b << 16) - 
			 FixMult(setup->deb, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxb, (setup->xHigh & 0xffff)));
    setup->a = Clamp255f(((i32)min_p->a << 16) -
			 FixMult(setup->dea, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxa, (setup->xHigh & 0xffff)));
    setup->s = (((i32)min_p->s << 16) -
			 FixMult(setup->des, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxs, (setup->xHigh & 0xffff)));
    setup->t = (((i32)min_p->t << 16) -
			 FixMult(setup->det, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxt, (setup->xHigh & 0xffff)));
    setup->z = (((i32)min_p->z) -
			 FixMult(setup->dez, (setup->yHigh & 0x0003) << 14) -
			 FixMult(setup->dxz, (setup->xHigh & 0xffff)));
#endif

#if 0
    setup->z   <<= 5;
    setup->dxz <<= 5;
    setup->dyz <<= 5;
    setup->dez <<= 5;
#endif

}


/*
 * Function which rasterizes a triangle, from the setup structure
 * provided.
 */
static void
do_rasterize(setup_td *setup)
{
    i32		i, y, x1, x2, yLow, yMid, yHigh, xMajor, xMinor, minorDx;
    i32		tr, tg, tb, r, g, b, incr;
    bool	right, low = true;

    dump_setup(setup);

    if (setup->flag & DIR_FLAG) {
	right = true;
    } else {
	right = false;
    }

    y       = ((i32)setup->yHigh << 14) & 0xffff0000;
    yLow    = ((i32)setup->yLow << 14);
    yMid    = ((i32)setup->yMid << 14);
    yHigh   = ((i32)setup->yHigh << 14);
    xMajor  = setup->xHigh;
    xMinor  = setup->xMid;
    minorDx = setup->DxXMDy;
    r = setup->r;    g = setup->g;    b = setup->b;

    while (y <= yHigh) {	/* skip leading frac pixels... */
	y += FRAC_ONE;
	xMajor += setup->DxXHDy;
	xMinor += minorDx;

	if (y >= yMid && low) {	/* change to new edge */
	    xMinor = setup->xLow;
	    minorDx = setup->DxXLDy;
	    low = false;
	}
    }

    while (y <= yLow) {

	if (y >= yMid && low) {	/* change to new edge */
	    xMinor = setup->xLow;
	    minorDx = setup->DxXLDy;
	    low = false;
	}

	/* simulate mask at begining of edge walk */
	x1 = xMajor;
	x2 = xMinor;
	if (right) {
	    incr = 1;
	    if (xMajor > xMinor) {
		x1 = x2 = 0;
	    }
	} else {
	    incr = -1;
	    if (xMinor > xMajor) {
		x1 = x2 = 0;
	    }
	}

	tr = r;		tg = g;		tb = b;
	for (i=(x1>>16); i !=(x2>>16) && i > 1 && i < XRES; i += incr) {
	    if (i < 1 || i >= XRES || (y>>16) >= YRES || (y>>16) < 1) {
		/* do nothing */
	    } else {
		if (right) {
		    tr = Clamp255f(tr + setup->dxr);
		    tg = Clamp255f(tg + setup->dxg);
		    tb = Clamp255f(tb + setup->dxb);
		} else {
		    tr = Clamp255f(tr - setup->dxr);
		    tg = Clamp255f(tg - setup->dxg);
		    tb = Clamp255f(tb - setup->dxb);
		}
		image[(y)>>16][i].r = (u8) ((unsigned)tr >> 16); 
		image[(y)>>16][i].g = (u8) ((unsigned)tg >> 16); 
		image[(y)>>16][i].b = (u8) ((unsigned)tb >> 16);
	    }
  	}
	if ((x2>>16) < 1 || (x2>>16) >= XRES || (y>>16) >= YRES || (y>>16) < 1) {
	} else {
	    image[(y)>>16][(x2>>16)].r = (u8) ((unsigned)tr >> 16); 
	    image[(y)>>16][(x2>>16)].g = (u8) ((unsigned)tg >> 16); 
	    image[(y)>>16][(x2>>16)].b = (u8) ((unsigned)tb >> 16);
	}

	xMajor += setup->DxXHDy;
	xMinor += minorDx;
	y += FRAC_ONE;
	r += setup->der;
	g += setup->deg;
	b += setup->deb;
    }
}

int
main(int argc, char *argv[])
{
    IMAGE	*sgi_image;
    FILE	*in = NULL, *out = NULL;
    point_td	orig_verts[3];
    setup_td	setup, *s;
    float	x0, y0, x1, y1, x2, y2;
    int		i, j, rcolor = 0, x, y, r, g, b, a, ts, tt, tz;
    int		cmd_peek, point_cnt = 0, v0, v1, v2;
    int		rdp_buffer[2];
    u16		shade_buffer[32];
    char	line[80], cmd_c;
    int		do_image = 0, row, col;

    strcpy(output_fname, "setup.pbm");
    while ((argc > 1) && (argv[1][0] == '-')) {
	switch(argv[1][1]) {

	  case 'c':
	    rcolor = 1;
	    break;

	  case 'i':
	    do_image = 1;
	    break;

	  case 'o':
	    strcpy(output_fname, argv[2]);
	    argc--;
	    argv++;
	    break;

	  case 'r':
	    if ((in=fopen(argv[2],"r")) == NULL) {
		fprintf(stderr,"wanker.\n");
		exit(1);
	    }
	    argc--;
	    argv++;
	    break;

	  default:
	    fprintf(stderr,"unknown option [%s]\n", argv[1]);
	    break;

	}
	argc--;
	argv++;
    }

    for (i=0; i<YRES; i++) {
	for (j=0; j<XRES; j++) {
	    image[i][j].r = (u8) 25;
	    image[i][j].g = (u8) 25;
	    image[i][j].b = (u8) 25;
	}
    }

    if (do_image) {
/*
	for (i=0; i<32; i++) {
	    for (j=0; j<32; j++) {
		if ((j % 8) == 0) {
		    image[i][j].r = (u8) 255 - (j/8 * 64);
		    image[i][j].g = (u8) 25 + (j/8 * 64);
		    image[i][j].b = (u8) 25;
		}
		image[i][j].a = (u8)(255.0 * (((i+1)/32.0)/2+((j+1)/32.0)/2));
	    }
	}

	for (i=0; i<32; i++) {
	    if ((i % 8) == 0) {
		for (j=0; j<32; j++) {
		    image[i][j].r = (u8) 25;
		    image[i][j].g = (u8) 25 + (i/8 * 64);
		    image[i][j].b = (u8) 255 - (i/8 * 64);
		}
	    }
	}

    for (i=0; i<YRES; i++) {
	for (j=0; j<XRES; j++) {
	    image[i][j].r = (u8) 0;
	    image[i][j].g = (u8) 0;
	    image[i][j].b = (u8) 0;
	}
    }
*/

/*
	for (i=0; i<32; i++) {
	    for (j=0; j<32; j++) {
		if (((i % 2) == 0) && ((j % 2) == 1) ||
		    ((i % 2) == 1) && ((j % 2) == 0)) {
		    image[i][j].r = (u8) 255;
		    image[i][j].g = (u8) 255;
		    image[i][j].b = (u8) 255;
		}
	    }
	}
*/

/*
	for (i=0; i<32; i++) {
	    for (j=0; j<32; j++) {
		if (((i % 2) == 0) && ((j % 2) == 1) ||
		    ((i % 2) == 1) && ((j % 2) == 0)) {
		    image[i][j].r = (u8) 255;
		    image[i][j].g = (u8) 255;
		    image[i][j].b = (u8) 255;
		}
	    }
	}
*/
	/* phong texture: */
	for (i=0; i<32; i++) {
	    for (j=0; j<32; j++) {
		image[i][j].r = (u8) 0;
		image[i][j].g = (u8) 0;
		image[i][j].b = (u8) 0;
	    }
	}
	for (i=0; i<32; i++) {
	    for (j=0; j<32; j++) {
		x0 = (i-16)*(i-16) + (j-16)*(j-16);
		x0 = sqrt(x0);

/*
 * bulls-eye pattern:
 *
		if (fabs(x0) < 4.0) {
		    image[31-i][j].r = 255;
		    image[31-i][j].g = 0;
		    image[31-i][j].b = 0;
		} else if (fabs(x0) < 8.0) {
		    image[31-i][j].r = 0;
		    image[31-i][j].g = 255;
		    image[31-i][j].b = 0;
		} else if (fabs(x0) < 12.0) {
		    image[31-i][j].r = 0;
		    image[31-i][j].g = 0;
		    image[31-i][j].b = 255;
		} else {
		    image[31-i][j].r = 255;
		    image[31-i][j].g = 255;
		    image[31-i][j].b = 0;
		}
 */

		x0 = 1.0 - (x0/16.0);
		x0 = pow(x0, 10.0);
		ts = (x0 * 255);
		ts = (ts > 255 ? 255 : (ts < 0 ? 0 : ts));

		row = (31-i + 8) % 32;
		row = (row < 0) ? row + 31 : row;
		col = (j - 8) % 32;
		image[row][col].r = (u8) ts;
		image[row][col].g = (u8) ts;
		image[row][col].b = (u8) ts;

		image[31-i][j].a = (u8) 255;
	    }
	}

	sgi_image = iopen("txtr.rgba","w",RLE(1),4,32,32,4);
	for (i=0; i<32; i++) {
	    for (j=0; j<32; j++) {
		rbuf[j] = image[i][j].r;
		gbuf[j] = image[i][j].g;
		bbuf[j] = image[i][j].b;
		abuf[j] = image[i][j].a;
	    }
	    putrow(sgi_image, rbuf, 32-1-i, 0);
	    putrow(sgi_image, gbuf, 32-1-i, 1);
	    putrow(sgi_image, bbuf, 32-1-i, 2);
	    putrow(sgi_image, abuf, 32-1-i, 3);
	}
	iclose(sgi_image);
	exit(1);
    }

    s = &setup;

    if (in != NULL) {

	while (1) {

	    cmd_peek = fgetc(in);
	    ungetc(cmd_peek, in);
	    if (cmd_peek == 0xcc) {

		fread((char *)s, 32, 1, in);
		if (feof(in))
		    break;

		fread((char *)&(shade_buffer[0]), sizeof(u16), 32, in);

		s->r = shade_buffer[0] << 16;    s->r |= shade_buffer[8];
		s->g = shade_buffer[1] << 16;    s->g |= shade_buffer[9];
		s->b = shade_buffer[2] << 16;    s->b  |= shade_buffer[10];
		s->a = shade_buffer[3] << 16;    s->a |= shade_buffer[11];

		s->dxr = shade_buffer[4] << 16;  s->dxr |= shade_buffer[12];
		s->dxg = shade_buffer[5] << 16;  s->dxg |= shade_buffer[13];
		s->dxb = shade_buffer[6] << 16;  s->dxb |= shade_buffer[14];
		s->dxa = shade_buffer[7] << 16;  s->dxa |= shade_buffer[15];

		s->der = shade_buffer[16] << 16; s->der |= shade_buffer[24];
		s->deg = shade_buffer[17] << 16; s->deg |= shade_buffer[25];
		s->deb = shade_buffer[18] << 16; s->deb |= shade_buffer[26];
		s->dea = shade_buffer[19] << 16; s->dea |= shade_buffer[27];

		s->dyr = shade_buffer[20] << 16; s->dyr |= shade_buffer[28];
		s->dyg = shade_buffer[21] << 16; s->dyg |= shade_buffer[29];
		s->dyb = shade_buffer[22] << 16; s->dyb |= shade_buffer[30];
		s->dya = shade_buffer[23] << 16; s->dya |= shade_buffer[31];

/*
		if (s->flag == 0) {
		    s->dxr >>= 1;
		    s->dxg >>= 1;
		    s->dxb >>= 1;
		    s->dxa >>= 1;

		    s->der >>= 1;
		    s->deg >>= 1;
		    s->deb >>= 1;
		    s->dea >>= 1;

		    s->dyr >>= 1;
		    s->dyg >>= 1;
		    s->dyb >>= 1;
		    s->dya >>= 1;
		}
*/

		do_rasterize(s);
	    } else {
		fread((char *)&(rdp_buffer[0]), sizeof(int), 2, in);
		if (feof(in))
		    break;
	    }
	}
    } else {

	while (fgets(line, 80, stdin) != NULL) {

	    if (line[0] == 'v') {		/* new point */
		sscanf(line, "%c %x %x %x %x %x %x %x %x %x",
		       &cmd_c, &x, &y, &r, &g, &b, &a, &ts, &tt, &tz);
		pointList[point_cnt].x = x;
		pointList[point_cnt].y = y;
		pointList[point_cnt].r = r;
		pointList[point_cnt].g = g;
		pointList[point_cnt].b = b;
		pointList[point_cnt].a = a;
		pointList[point_cnt].s = ts;
		pointList[point_cnt].t = tt;
		pointList[point_cnt].z = tz;
		point_cnt++;
	    } else if (line[0] == 't') {	/* new triangle */
		sscanf(line, "%c %d %d %d",
		       &cmd_c, &v0, &v1, &v2);
		do_setup(s, &(pointList[v0]), &(pointList[v1]), 
			 &(pointList[v2]));
		do_rasterize(s);
	    } else if (line[0] == 'l') {	/* new line */
		sscanf(line, "%c %d %d",
		       &cmd_c, &v0, &v1);
		do_line(s, &(pointList[v0]), &(pointList[v1]));
		do_rasterize(s);
	    }
	}
    }

    sgi_image = iopen("setup.rgb","w",RLE(1),3,XRES/2,YRES/2,3);
    for (i=0; i<(YRES/2); i++) {
	for (j=0; j<XRES/2; j++) {
	    rbuf[j] = image[i][j].r;
	    gbuf[j] = image[i][j].g;
	    bbuf[j] = image[i][j].b;
	}
	putrow(sgi_image, rbuf, YRES/2-1-i, 0);
	putrow(sgi_image, gbuf, YRES/2-1-i, 1);
	putrow(sgi_image, bbuf, YRES/2-1-i, 2);
    }
    iclose(sgi_image);

#if 0
    /* all done, output image... */
    if ((out=fopen(output_fname, "w"))==NULL) {
	fprintf(stderr,"could not open file [%s].\n",output_fname);
	exit(-1);
    }
    fprintf(out,"P6\n%d %d\n255\n",XRES/2,YRES/2);

    for (i=0; i<YRES/2; i++) {
	for (j=0; j<XRES/2; j++) {
	    fputc(image[i][j].r, out);
	    fputc(image[i][j].g, out);
	    fputc(image[i][j].b, out);
	}
    }
#endif
}

