#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void useage(void)
{
	printf("Useage:\n");
	printf("  sortdata [-l | -i]\n");
	printf("     reads standard input and writes standard output\n");
	printf("     -l writes #defines for all labels\n");
	printf("     -i writes .word/.byte/.half etc for each occurance\n");
}

int dolabels=0, wasincomment=0;
int linenum=0;

int getline(char *buf)
{
        int c;

        c=getchar();

        if (c==EOF) return 0;
        while (c!='\n' && c!=EOF) {
                *(buf++)=c;
                c=getchar();
        }
        *buf='\0';
	linenum++;
        return 1;
}

int checkLabel(char *buf,char *labelname)
{
	char *c;
	int incomment;

	incomment=wasincomment;
	for (c=buf; *c!='\0' && *c!=' ' && *c!='\t'; c++) {
		if (incomment) {
			if (*c=='*' && *(c+1)=='/') {
				incomment=0;
				c++;
			}
		} else {
			if (*c=='/' && *(c+1)=='*') {
				incomment=1; 
				c++;
			} else {
				if (*c=='#') return 0;
				*(labelname)='\0';
				if (*c==':') return 1;
				*(labelname++)=*c;
			}
		}
	}
	return 0;
}
int checkWord(char *buf,char *dotword)
{
	char *c;
	int incomment;

	incomment=wasincomment;
	for (c=buf; *c!='\0'; c++) {
		if (incomment) {
			if (*c=='*' && *(c+1)=='/') {
				incomment=0;
				c++;
			}
		} else {
			if (*c=='/' && *(c+1)=='*') {
				incomment=1; 
				c++;
			} else {
				if (*c=='#' && c!=buf) return 0;
				if (!strncmp(dotword,c,strlen(dotword)))
					return 1;
			}
		}
	}
	return 0;
}
int checkcomment(char *buf)
{
	char *c;
	int incomment;

	incomment=wasincomment;
	for (c=buf; *c!='\0'; c++) {
		if (incomment) {
			if (*c=='*' && *(c+1)=='/') {
				incomment=0;
				c++;
			}
		} else {
			if (*c=='/' && *(c+1)=='*') {
				incomment=1; 
				c++;
			}
		}
	}
	return incomment;
}
void dolabel(char *buf,char *labelname,int current)
{
	int n;
	char spc[31];

	n=30-strlen(labelname);
	if (n<1) n=1;
	spc[n]='\0';
	while(--n>=0) spc[n]=' ';

	if (dolabels)
		printf("#define %s%s0x%04X\n",labelname,spc,current);
	else 
		printf(" ### %s%s0x%04X\n",labelname,spc,current);
	
}
void doData(char *buf)
{
	if (!dolabels)
		printf("%s\n",buf);
}
void doLine(char *buf)
{
	printf("%s\n",buf);
}
int doGetWordNum(char *buf,char *word)
{
	char *c;
	int num;

	for (c=buf; *c!='\0'; c++) {
		if (!strncmp(word,c,strlen(word))) break;
	}
	while (*c!=' ' && *c!= '\t'  && *c!= '\0') c++;
	while (*c==' ' || *c== '\t') c++;

	if (*c=='\0') {
		printf("errprint(ERROR: %s missing argument. LINE %d\n)\n",
								word,linenum);
		printf("xxxxxm4exit 1\n");
		return 0;
	}

	sscanf(c,"%i",&num);

	if (!num) {
		printf("errprint(ERROR: %s argument 0 or non-numeric. LINE %d\n)\n", word,linenum);
		printf("xxxxxm4exit 1\n");
		return 0;
	}
	return num;
}
void doMax(char *buf,int current)
{
	int num;

	if (!(num=doGetWordNum(buf,".max")))
		return;

	if (current > num) {
		printf("errprint(ERROR: ALLOCATED MEMORY TOO LARGE (0x%X > 0x%X). LINE %d\n)\n", current,num,linenum);
		printf("xxxxxm4exit 1\n");
		return;
	} else {
		printf(" ### ALLOCATED MEMORY (0x%X) DOES NOT EXCEED 0x%X HERE\n",current,num);
	}
}
void doMin(char *buf,int current)
{
	int num;

	if (!(num=doGetWordNum(buf,".min")))
		return;

	if (current < num) {
		printf("errprint(ERROR: ALLOCATED MEMORY TOO SMALL (0x%X < 0x%X). LINE %d\n)\n", current,num,linenum);
		printf("xxxxxm4exit 1\n");
		return;
	} else {
		printf(" ### ALLOCATED MEMORY (0x%X) IS AT LEAST 0x%X HERE\n",current,num);
	}
}
void doBound(char *buf,int current)
{
	int num;

	if (!(num=doGetWordNum(buf,".bound")))
		return;

	if (current % num) {
		printf("errprint(ERROR: NOT ALIGNED TO %d BYTE BOUNDARY(0x%X). LINE %d\n)\n", num,current,linenum);
		printf("xxxxxm4exit 1\n");
		return;
	} else {
		printf(" ### ALIGNED TO %d BYTE BOUNDARY HERE\n",num);
	}
}
int doAlign(char *buf,int current)
{
	int num;

	if (!(num=doGetWordNum(buf,".align")))
		return;

	while (current % num) {
		if (!dolabels)
			printf("	.byte	0		# ALIGN PAD\n");
		current++;
	}

	return current;
}
int doSpace(char *buf,int current)
{
	int num;

	if (!(num=doGetWordNum(buf,".space")))
		return;

	return current+num;
}
int killPrint(char *buf1,char *word)
{
	char *c1,*c2;
	char buf2[1000];
	int killParen(char *buf, int n);

	strcpy(buf2,buf1);

	c1=buf1;
	for (c2=buf2; *c2!='\0'; c2++) {
		if (!strncmp(word,c2,strlen(word))) break;
		*(c1++)= *c2;
	}
	while (*c2!='(')
		*(c1++)= *(c2++);
	*(c1++)='(';
	*(c1++)=')';
	*(c1++)='\0';

	return killParen(c2+1,1);
}
int killParen(char *buf, int n)
{
	while (n>0 && *buf!='\0') {
		if (*buf=='(') n++;
		if (*buf==')') n--;
		buf++;
	}
	return n;
}

int main(int argc, char *argv[])
{
	int c;
	char linebuf1[1000];
	char linebuf2[1000];
	char *linec,*dotc;
	int  current=0;
#define MAXSTACK 100
	int savestack[MAXSTACK], checkstack[MAXSTACK];
	int savep=0,checkp=0;
	int oldcur,nparen;

	if (argc != 2) {
		useage();
		exit(1);
	}
	dolabels 	= argv[1][0];
	if (dolabels == '-') 
		dolabels 	= argv[1][1];
	switch (dolabels) {
		case 'l' : 
			dolabels = 1;
			break;
		case 'i' : 
			dolabels = 0;
			break;
		default :
			useage();
			exit(1);
	}

	if (dolabels) {
		printf("\n");
		printf("#ifndef _gdmem_labels_h_\n");
		printf("#define _gdmem_labels_h_ 1\n");
		printf("\n");
		printf(" #\n");
		printf(" # gdmem_labels.h\n");
		printf(" #\n");
		printf(" # THIS FILE WAS AUTOMATICALLY GENERATED BY\n");
		printf(" # THE SORTDATA.C PROGRAM\n");
		printf(" #\n");
		printf(" # DO NOT EDIT\n");
		printf(" #\n");
	} else {
		printf("\n");
		printf("#ifndef _gdmem_init_h_\n");
		printf("#define _gdmem_init_h_ 1\n");
		printf("\n");
		printf(" #\n");
		printf(" # gdmem_init.h\n");
		printf(" #\n");
		printf(" # THIS FILE WAS AUTOMATICALLY GENERATED BY\n");
		printf(" # THE SORTDATA.C PROGRAM\n");
		printf(" #\n");
		printf(" # DO NOT EDIT\n");
		printf(" #\n");
	}


	while(getline(linebuf1)) {
		if (checkWord(linebuf1,"errprint")) {
			if (!dolabels)
				doLine(linebuf1);
			else {
				nparen=killPrint(linebuf1,"errprint");
				doLine(linebuf1);
				while(nparen>0) {
					if (!getline(linebuf1)) break;
					nparen=killParen(linebuf1,nparen);
				}
			}
		} else if (!strncmp(linebuf1,"#define",strlen("#define"))) {
			if (dolabels)
				doLine(linebuf1);
		} else if (!strncmp(linebuf1,"#if",strlen("#if"))) {
			doLine(linebuf1);
			savestack[savep++]=current;
			checkstack[checkp++]=-1;
			if (savep>MAXSTACK || checkp>MAXSTACK) {
				printf("errprint(SORTDATA ERROR: TOO MANY ifdef LEVELS. LINE %d\n)\n",linenum);
				printf("xxxxxm4exit 1\n");
				exit(1);
			}
		} else if (!strncmp(linebuf1,"#else",strlen("#else"))) {
			doLine(linebuf1);
			if (savep<1 || checkp<1) {
				printf("errprint(SORTDATA ERROR: ELSE WITH NO IF. LINE %d\n)\n",linenum);
				printf("xxxxxm4exit 1\n");
				exit(1);
			}
			oldcur=checkstack[--checkp];
			if (oldcur!= -1 && oldcur!=current) {
				printf("errprint(ERROR: Number of words declared in 2 parts of #ifdef were not equal. LINE %d\n)\n",linenum);
				printf("xxxxxm4exit 1\n");
			}
			checkstack[checkp++]=current;
			current = savestack[savep-1];
		} else if (!strncmp(linebuf1,"#endif",strlen("#endif"))) {
			doLine(linebuf1);
			if (savep<1 || checkp<1) {
				printf("errprint(SORTDATA ERROR: ENDIF WITH NO IF. LINE %d\n)\n",linenum);
				printf("xxxxxm4exit 1\n");
				exit(1);
			}
			oldcur=checkstack[--checkp];
			if (oldcur==-1) {
				printf("errprint(ERROR: #ifdef without #else (ifdef & else allocations must match) LINE %d\n)\n",linenum);
				printf("xxxxxm4exit 1\n");
			}
			if (oldcur!= -1 && oldcur!=current) {
				printf("errprint(ERROR: Number of words declared in 2 parts of #ifdef were not equal. LINE %d\n)\n",linenum);
				printf("xxxxxm4exit 1\n");
			}
			savep--;
		} else if (checkLabel(linebuf1,linebuf2)) {
			dolabel(linebuf1,linebuf2,current);
		} else if (checkWord(linebuf1,".word")) {
			doData(linebuf1);
			current += 4;
		} else if (checkWord(linebuf1,".half")) {
			doData(linebuf1);
			current += 2;
		} else if (checkWord(linebuf1,".byte")) {
			doData(linebuf1);
			current += 1;
		} else if (checkWord(linebuf1,".align")) {
			current=doAlign(linebuf1,current);
		} else if (checkWord(linebuf1,".bound")) {
			doBound(linebuf1,current);
		} else if (checkWord(linebuf1,".max")) {
			doMax(linebuf1,current);
		} else if (checkWord(linebuf1,".min")) {
			doMin(linebuf1,current);
		} else if (checkWord(linebuf1,".space")) {
			current=doSpace(linebuf1,current);
		} else {
			doLine(linebuf1);
		}
		wasincomment=checkcomment(linebuf1);
	}

	if (dolabels) {
		printf("\n");
		printf("#endif /* _gdmem_labels_h_ */\n");
	} else {
		printf("\n");
		printf("#endif /* _gdmem_init_h_ */\n");
	}

	exit(0);
}
