/*
 * Clipping test program -- LK
 *
 * $Id: cliptst.c,v 1.1.1.1 2002/05/02 03:29:10 blythe Exp $
 *
 * $Log: cliptst.c,v $
 * Revision 1.1.1.1  2002/05/02 03:29:10  blythe
 * nintendo n64os20j source
 *
 * Revision 1.3  1994/08/26 17:55:23  acorn
 * Added features to the cliptst program:
 *    show modeling spcace, homogenious clip space in 3 views, clip space after
 *         divide, and screen space.
 *    allow more diverse manipulation of object, view, and transformation.
 *    allow dumping of triangle including matrix, vertices and triangle in a
 *         format useable by the rsp simulator in a file (cliptst.dump)
 *
 * Revision 1.2  1994/08/02  00:59:24  lk
 * Changed dump format from ASCII to binary.
 *
 * Revision 1.4  1994/07/26  23:00:52  lk
 * Added ability to dump the triangle data; holding the left shift key displays
 * the triangle in color.
 *
 * Revision 1.3  1994/07/26  18:08:40  lk
 * Added vertex structure, converted more to fixed point, and broke down
 * polygon into triangles when drawing.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/device.h>

#define MAXV		16
#define SHIFT		16
#define FRAC		(1 << SHIFT)
#define MASK		(FRAC - 1)
#define MKFIX(i,f)	(((i) << SHIFT) | (f))
#define MKFLT(i,f)	((i) + (f) / (float)FRAC)
#define MKINT(r)	(((int) (r*65536))>>16)
#define MKFRAC(r)	(((int) (r*65536))&0xFFFF)
#define DUMPFN		"clip.tst"
#define MAX(a,b)	((a>b) ? a:b)
#define MIN(a,b)	((a<b) ? a:b)

struct vertex {
	float		xmod;
	float		ymod;
	float		zmod;
	float		xhom;
	float		yhom;
	float		zhom;
	float		whom;
	short		xint;
	short		yint;
	short		zint;
	short		wint;
	unsigned short	xfrac;
	unsigned short	yfrac;
	unsigned short	zfrac;
	unsigned short	wfrac;
	unsigned short	xscr;
	unsigned short	yscr;
	unsigned short	s;			/* S11.4		*/
	unsigned short	t;			/* S11.4		*/
	unsigned char	cc;
	unsigned char	flag;
	unsigned char	a;
	unsigned char	b;			/* nz			*/
	unsigned char	g;			/* ny			*/
	unsigned char	r;			/* nx			*/
	unsigned short	pad;
};

struct vertex	vert[16];	/* Vertex area of dmem */
struct vertex	temp[18];	/* Temporary area of dmem -- XXX how big? */

typedef signed long	i32;

long	winid,winidx,winidy,winidz,winidm,winids;
float	vazim, vinc, vdist;
float	vtransx=0, vtransy=0, vtransz=0;
float	coordmax;
int		calctri=1,maketri=1, fixmax=0;
int	dump;
float	modscale=1000,scrnscale=1;

float	trisize, trix, triy, triz, triaz=0, triinc=0;

float	peyez, peyex=0, peyey=0;
float	pright,pleft,ptop,pbottom,pnear,pfar;
Matrix	pmat,imat;


/* function prototypes */
void doxform(struct vertex *v);



void init (void)
{
	vazim = 0;
	vinc = 0;
	vdist = 10*modscale;

	trisize = 0.18*modscale;
	trix = 0*modscale;
	triy = 0*modscale;
	triz = 0*modscale;

	dump = 0;


	peyez = 5.0*modscale;
	pnear = 4.0*modscale;
	pfar = 6.0*modscale;
	pright = 1.0*modscale;
	pleft = -1.0*modscale;
	ptop = 1.0*modscale;
	pbottom = -1.0*modscale;
}

void printmatrix(Matrix m)
{
	printf("%5.2f %5.2f %5.2f %5.2f\n",m[0][0], m[0][1], m[0][2], m[0][3]);
	printf("%5.2f %5.2f %5.2f %5.2f\n",m[1][0], m[1][1], m[1][2], m[1][3]);
	printf("%5.2f %5.2f %5.2f %5.2f\n",m[2][0], m[2][1], m[2][2], m[2][3]);
	printf("%5.2f %5.2f %5.2f %5.2f\n",m[3][0], m[3][1], m[3][2], m[3][3]);
	printf("\n");
}

void printpoints(void)
{
	printf("v1 mod: %3.3f, %3.3f, %3.3f   clip: %04hX.%04hX, %04hX.%04hX, %04hX.%04hX, %04hX.%04hX\n",
			vert[0].xmod, vert[0].ymod, vert[0].zmod, vert[0].xint, vert[0].xfrac, 
			vert[0].yint, vert[0].yfrac, vert[0].zint, vert[0].zfrac, vert[0].wint, 
			vert[0].wfrac);
	printf("v2 mod: %3.3f, %3.3f, %3.3f   clip: %04hX.%04hX, %04hX.%04hX, %04hX.%04hX, %04hX.%04hX\n",
			vert[1].xmod, vert[1].ymod, vert[1].zmod, vert[1].xint, vert[1].xfrac, 
			vert[1].yint, vert[1].yfrac, vert[1].zint, vert[1].zfrac, vert[1].wint, 
			vert[1].wfrac);
	printf("v3 mod: %3.3f, %3.3f, %3.3f   clip: %04hX.%04hX, %04hX.%04hX, %04hX.%04hX, %04hX.%04hX\n",
			vert[2].xmod, vert[2].ymod, vert[2].zmod, vert[2].xint, vert[2].xfrac, 
			vert[2].yint, vert[2].yfrac, vert[2].zint, vert[2].zfrac, vert[2].wint, 
			vert[2].wfrac);
	printf("\n");
}

void invertmatrix(Matrix om, Matrix im)
{
	int i,j,k;
	float mult;
	Matrix m;

	for (i=0;i<4;i++)
		for(j=0;j<4;j++) {
			if (i==j) im[i][j]=1;
			else im[i][j]=0;
			m[i][j]=om[i][j];
		}

	for(i=0;i<3;i++) {
		for(j=i+1;j<4;j++) {
			mult = m[j][i]/m[i][i];
			m[j][i] = 0;
			for(k=i+1;k<4;k++) {
				m[j][k] -= mult*m[i][k];
			}
			for(k=0; k<4;k++) {
				im[j][k] -= mult*im[i][k];
			}
		}
	}

	for (i=3;i>0;i--) {
		for (j=i-1;j>=0; j--) {
			mult = m[j][i]/m[i][i];
			m[j][i]=0;
			for (k=3;k>=0;k--) {
				im[j][k] -= mult*im[i][k];
			}
		}
	}

	for (i=0;i<4;i++) {
		mult=1/m[i][i];
		m[i][i]=1.0;
		for (j=0;j<4;j++) {
			im[i][j] *= mult;
		}
	}

}

void makematrix(void)
{

	pmat[0][0] = scrnscale*2*pnear/(pright-pleft);
	pmat[0][1] = 0;
	pmat[0][2] = 0;
	pmat[0][3] = 0;
	pmat[1][0] = 0;
	pmat[1][1] = scrnscale*2*pnear/(ptop-pbottom);;
	pmat[1][2] = 0;
	pmat[1][3] = 0;
	pmat[2][0] = 0;
	pmat[2][1] = 0;
	pmat[2][2] = -scrnscale*((pfar+pnear)/(pfar-pnear));
	pmat[2][3] = scrnscale* ( (-2.0*pfar*pnear/(pfar-pnear)) + 
								(peyez*(pfar+pnear)/(pfar-pnear)) );
	pmat[3][0] = 0;
	pmat[3][1] = 0;
	pmat[3][2] = -1;
	pmat[3][3] = peyez;

	invertmatrix(pmat,imat);
}

void initgraphics (void)
{
	foreground ();
	prefposition(0,500,524,1024);
	winid = winopen ("World Coordinates");
	winconstraints();
	doublebuffer ();
	zbuffer (FALSE);
	RGBmode ();
	gconfig ();
	qdevice (ESCKEY);
	qdevice (LEFTMOUSE);
	qdevice (MIDDLEMOUSE);
	qdevice (RIGHTMOUSE);
	qdevice (SPACEKEY);
	qdevice (DKEY);
	qdevice (FKEY);
	qdevice (VKEY);
	qdevice (RKEY);
	qdevice (PKEY);
	qdevice (TKEY);
	qdevice (HKEY);
	perspective (450, 1, 2*scrnscale, 2000*scrnscale);

	foreground ();
	prefposition(518,1018,524,1024);
	winidm = winopen ("Modelling Coordinates");
	winconstraints();
	doublebuffer ();
	zbuffer (FALSE);
	RGBmode ();
	gconfig ();
	perspective (450, 1, 2*modscale, 2000*modscale);

	foreground ();
	prefposition(0,256,202,458);
	winidx = winopen ("X vs W view");
	winconstraints();
	doublebuffer ();
	zbuffer (FALSE);
	RGBmode ();
	gconfig ();

	foreground ();
	prefposition(274,530,202,458);
	winidy = winopen ("Y vs W view");
	winconstraints();
	doublebuffer ();
	zbuffer (FALSE);
	RGBmode ();
	gconfig ();

	foreground ();
	prefposition(539,795,202,458);
	winidz = winopen ("Z vs W view");
	winconstraints();
	doublebuffer ();
	zbuffer (FALSE);
	RGBmode ();
	gconfig ();

	foreground ();
	prefposition(804,1060,202,458);
	winids = winopen ("Screen view");
	winconstraints();
	doublebuffer ();
	zbuffer (FALSE);
	RGBmode ();
	gconfig ();

	winset(winid);
	makematrix();
}

void bgncomp(long wid)
{
	float	v[3];

	winset(wid);
	cpack (0x00000000);
	clear ();
	zclear ();

	pushmatrix ();
	ortho(-1.3, 1.3, -1.3, 1.3, -1.3, 1.3);

	/* draw axis */
	cpack (0x00ffffff);

	bgnline ();
	v[0] = -1;  v[1] = 0;  v[2] = 0;  v3f (v);
	v[0] = 1;  v[1] = 0;  v[2] = 0; v3f (v);
	endline ();

	bgnline ();
	v[0] = 0;  v[1] = -1;  v[2] = 0;  v3f (v);
	v[0] = 0;  v[1] = 1;  v[2] = 0; v3f (v);
	endline ();

	/* draw diagonals */
	cpack (0x00ffff00);

	bgnline ();
	v[0] = -1;  v[1] = -1;  v[2] = 0;  v3f (v);
	v[0] = 1;  v[1] = 1;  v[2] = 0; v3f (v);
	endline ();

	bgnline ();
	v[0] = -1;  v[1] = 1;  v[2] = 0;  v3f (v);
	v[0] = 1;  v[1] = -1;  v[2] = 0; v3f (v);
	endline ();
}

void bgndraw (void)
{
	float	v[3];
/*	float rfov;*/
	float nf;
	unsigned int cn=0x00ffffff, cf=0x00404040;

	cpack (0x00000000);
	clear ();
	zclear ();

	pushmatrix ();
	lookat ((vdist*sin(vazim/1800.0*M_PI)*cos(vinc/1800.0*M_PI)+vtransx)/
																(modscale/scrnscale),
		(vdist*sin(vinc/1800.0*M_PI)+vtransy)/
																(modscale/scrnscale),
		(vdist*cos(vazim/1800.0*M_PI)*cos(vinc/1800.0*M_PI)+vtransz)/
																(modscale/scrnscale),
		vtransx/(modscale/scrnscale), 
		vtransy/(modscale/scrnscale), 
		vtransz/(modscale/scrnscale), 
		0);

	/*
	 * Draw culling box.
	 */


	bgnclosedline ();
	cpack (cn);
	v[0] = 1;  v[1] = 1;  v[2] = 1;  v3f (v);
	v[0] = -1; v[1] = 1;  v[2] = 1;  v3f (v);
	v[0] = -1; v[1] = -1; v[2] = 1;  v3f (v);
	v[0] = 1;  v[1] = -1; v[2] = 1;  v3f (v);
	endclosedline ();

	bgnclosedline ();
	cpack (cf);
	v[0] = 1;  v[1] = 1;  v[2] = -1; v3f (v);
	v[0] = -1; v[1] = 1;  v[2] = -1; v3f (v);
	v[0] = -1; v[1] = -1; v[2] = -1; v3f (v);
	v[0] = 1;  v[1] = -1; v[2] = -1; v3f (v);
	endclosedline ();

	bgnline ();
	cpack (cn);
	v[0] = 1;  v[1] = 1;  v[2] = 1;  v3f (v);
	cpack (cf);
	v[0] = 1;  v[1] = 1;  v[2] = -1; v3f (v);
	endline ();

	bgnline ();
	cpack (cn);
	v[0] = -1; v[1] = 1;  v[2] = 1;  v3f (v);
	cpack (cf);
	v[0] = -1; v[1] = 1;  v[2] = -1; v3f (v);
	endline ();

	bgnline ();
	cpack (cn);
	v[0] = -1; v[1] = -1; v[2] = 1;  v3f (v);
	cpack (cf);
	v[0] = -1; v[1] = -1; v[2] = -1; v3f (v);
	endline ();

	bgnline ();
	cpack (cn);
	v[0] = 1;  v[1] = -1; v[2] = 1;  v3f (v);
	cpack (cf);
	v[0] = 1;  v[1] = -1; v[2] = -1; v3f (v);
	endline ();

	winset(winidm);
	cpack (0x00000000);
	clear ();
	zclear ();

	
	pushmatrix ();
	lookat (vdist*sin(vazim/1800.0*M_PI)*cos(vinc/1800.0*M_PI)+vtransx,
		vdist*sin(vinc/1800.0*M_PI)+vtransy,
		vdist*cos(vazim/1800.0*M_PI)*cos(vinc/1800.0*M_PI)+vtransz,
		vtransx, vtransy, vtransz, 0);

	cpack (0x00ff00ff);
	bgnclosedline ();
	v[0] = peyex;  v[1] = peyey+0.10*modscale;  v[2] = peyez;  v3f (v);
	v[0] = peyex+0.07*modscale;  v[1] = peyey+0.07*modscale;  v[2] = peyez;  v3f (v);
	v[0] = peyex+0.10*modscale;  v[1] = peyey;  v[2] = peyez;  v3f (v);
	v[0] = peyex+0.07*modscale;  v[1] = peyey-0.07*modscale;  v[2] = peyez;  v3f (v);
	v[0] = peyex;  v[1] = peyey-0.10*modscale;  v[2] = peyez;  v3f (v);
	v[0] = peyex-0.07*modscale;  v[1] = peyey-0.07*modscale;  v[2] = peyez;  v3f (v);
	v[0] = peyex-0.10*modscale;  v[1] = peyey;  v[2] = peyez;  v3f (v);
	v[0] = peyex-0.07*modscale;  v[1] = peyey+0.07*modscale;  v[2] = peyez;  v3f (v);
	endclosedline ();

/*
	rfov = pfov * M_PI / 180.0;
	cpack (0x00ffffff);
	bgnclosedline ();		/* asume peyex = peyey = 0.0 * /
	v[0] = paspect*pnear*tan(rfov/2); v[1]= pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	v[0] =-paspect*pnear*tan(rfov/2); v[1]= pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	v[0] =-paspect*pnear*tan(rfov/2); v[1]=-pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	v[0] = paspect*pnear*tan(rfov/2); v[1]=-pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	endclosedline ();
	bgnclosedline ();
	v[0] = paspect*pfar*tan(rfov/2); v[1] = pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] =-paspect*pfar*tan(rfov/2); v[1] = pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] =-paspect*pfar*tan(rfov/2); v[1] =-pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] = paspect*pfar*tan(rfov/2); v[1] =-pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	endclosedline ();
	bgnline ();
	v[0] = paspect*pfar*tan(rfov/2); v[1] = pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] = paspect*pnear*tan(rfov/2); v[1]= pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	endline ();
	bgnline ();
	v[0] =-paspect*pfar*tan(rfov/2); v[1] = pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] =-paspect*pnear*tan(rfov/2); v[1]= pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	endline ();
	bgnline ();
	v[0] =-paspect*pfar*tan(rfov/2); v[1] =-pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] =-paspect*pnear*tan(rfov/2); v[1]=-pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	endline ();
	bgnline ();
	v[0] = paspect*pfar*tan(rfov/2); v[1] =-pfar*tan(rfov/2); v[2] = peyez-pfar; v3f(v);
	v[0] = paspect*pnear*tan(rfov/2); v[1]=-pnear*tan(rfov/2); v[2]= peyez-pnear; v3f(v);
	endline ();
*/

	bgnclosedline ();		/* asume peyex = peyey = 0.0 */
	cpack (cn);
	v[0] = pleft; v[1]= ptop; v[2]= peyez-pnear; v3f(v);
	v[0] = pright; v[1]= ptop; v[2]= peyez-pnear; v3f(v);
	v[0] = pright; v[1]= pbottom; v[2]= peyez-pnear; v3f(v);
	v[0] = pleft; v[1]= pbottom; v[2]= peyez-pnear; v3f(v);
	endclosedline ();
	
	nf = pfar/pnear;

	bgnclosedline ();
	cpack (cf);
	v[0] = pleft*nf; v[1]= ptop*nf; v[2]= peyez-pfar; v3f(v);
	v[0] = pright*nf; v[1]= ptop*nf; v[2]= peyez-pfar; v3f(v);
	v[0] = pright*nf; v[1]= pbottom*nf; v[2]= peyez-pfar; v3f(v);
	v[0] = pleft*nf; v[1]= pbottom*nf; v[2]= peyez-pfar; v3f(v);
	endclosedline ();

	bgnline ();
	cpack (cn);
	v[0] = pleft; v[1]= pbottom; v[2]= peyez-pnear; v3f(v);
	cpack (cf);
	v[0] = pleft*nf; v[1]= pbottom*nf; v[2]= peyez-pfar; v3f(v);
	endline ();

	bgnline ();
	cpack (cn);
	v[0] = pright; v[1]= pbottom; v[2]= peyez-pnear; v3f(v);
	cpack (cf);
	v[0] = pright*nf; v[1]= pbottom*nf; v[2]= peyez-pfar; v3f(v);
	endline ();

	bgnline ();
	cpack (cn);
	v[0] = pright; v[1]= ptop; v[2]= peyez-pnear; v3f(v);
	cpack (cf);
	v[0] = pright*nf; v[1]= ptop*nf; v[2]= peyez-pfar; v3f(v);
	endline ();

	bgnline ();
	cpack (cn);
	v[0] = pleft; v[1]= ptop; v[2]= peyez-pnear; v3f(v);
	cpack (cf);
	v[0] = pleft*nf; v[1]= ptop*nf; v[2]= peyez-pfar; v3f(v);
	endline ();


	bgncomp(winidx);
	bgncomp(winidy);
	bgncomp(winidz);

		/* screen view window */
	winset(winids);
	cpack (0x00000000);
	clear ();
	zclear ();

	pushmatrix ();
	ortho(-1.1, 1.1, -1.1, 1.1, -10.1, 10.1);

	bgnclosedline ();
	cpack (cn);
	v[0] = 1;  v[1] = 1;  v[2] = 0;  v3f (v);
	v[0] = -1; v[1] = 1;  v[2] = 0;  v3f (v);
	v[0] = -1; v[1] = -1; v[2] = 0;  v3f (v);
	v[0] = 1;  v[1] = -1; v[2] = 0;  v3f (v);
	endclosedline ();



	winset(winid);
}

void drawcomp (struct vertex *v1, struct vertex *v2, struct vertex *v3,int axis,
								long wid,int col)
{
	float			v[3];
	int				tricolor;
	float			*vs;

	winset(wid);

	cpack (col);
	tricolor = getbutton (LEFTSHIFTKEY);

	bgnclosedline ();

	if (tricolor) {
		RGBcolor (v1->r, v1->g, v1->b);
	}
	vs = &v1->xhom;
	v[0] = v1->whom/coordmax;
	v[1] = vs[axis]/coordmax;
	v[2] = 0.0;
	v3f (v);
	
	if (tricolor) {
		RGBcolor (v2->r, v2->g, v2->b);
	}
	vs = &v2->xhom;
	v[0] = v2->whom/coordmax;
	v[1] = vs[axis]/coordmax;
	v[2] = 0.0;
	v3f (v);
	
	if (tricolor) {
		RGBcolor (v3->r, v3->g, v3->b);
	}
	vs = &v3->xhom;
	v[0] = v3->whom/coordmax;
	v[1] = vs[axis]/coordmax;
	v[2] = 0.0;
	v3f (v);
	
	endclosedline ();

	winset(winid);
}

void drawtriangle (struct vertex *v1, struct vertex *v2, struct vertex *v3,
	int col)
{
	float		v[3];
	int		tricolor;

	/*
	 * Draw triangle.
	 */

	cpack (col);

	tricolor = getbutton (LEFTSHIFTKEY);

	bgnclosedline ();
	if (tricolor) {
		RGBcolor (v1->r, v1->g, v1->b);
	}
	v[0] = MKFLT (v1->xint, v1->xfrac);
	v[1] = MKFLT (v1->yint, v1->yfrac);
	v[2] = MKFLT (v1->zint, v1->zfrac);
	v3f (v);
	if (tricolor) {
		RGBcolor (v2->r, v2->g, v2->b);
	}
	v[0] = MKFLT (v2->xint, v2->xfrac);
	v[1] = MKFLT (v2->yint, v2->yfrac);
	v[2] = MKFLT (v2->zint, v2->zfrac);
	v3f (v);
	if (tricolor) {
		RGBcolor (v3->r, v3->g, v3->b);
	}
	v[0] = MKFLT (v3->xint, v3->xfrac);
	v[1] = MKFLT (v3->yint, v3->yfrac);
	v[2] = MKFLT (v3->zint, v3->zfrac);
	v3f (v);
	endclosedline ();

	winset(winidm);
	cpack (col);

	bgnclosedline ();
	if (tricolor) {
		RGBcolor (v1->r, v1->g, v1->b);
	}
	v[0] = v1->xmod;
	v[1] = v1->ymod;
	v[2] = v1->zmod;
	v3f (v);
	if (tricolor) {
		RGBcolor (v2->r, v2->g, v2->b);
	}
	v[0] = v2->xmod;
	v[1] = v2->ymod;
	v[2] = v2->zmod;
	v3f (v);
	if (tricolor) {
		RGBcolor (v3->r, v3->g, v3->b);
	}
	v[0] = v3->xmod;
	v[1] = v3->ymod;
	v[2] = v3->zmod;
	v3f (v);
	endclosedline ();

	drawcomp(v1, v2, v3, 0, winidx,col);
	drawcomp(v1, v2, v3, 1, winidy,col);
	drawcomp(v1, v2, v3, 2, winidz,col);


	winset(winids);
	cpack (col);

	bgnpolygon ();
	if (tricolor) {
		RGBcolor (v1->r, v1->g, v1->b);
	}
	v[0] = MKFLT (v1->xint, v1->xfrac);
	v[1] = MKFLT (v1->yint, v1->yfrac);
	v[2] = MKFLT (v1->zint, v1->zfrac);
	v3f (v);
	if (tricolor) {
		RGBcolor (v2->r, v2->g, v2->b);
	}
	v[0] = MKFLT (v2->xint, v2->xfrac);
	v[1] = MKFLT (v2->yint, v2->yfrac);
	v[2] = MKFLT (v2->zint, v2->zfrac);
	v3f (v);
	if (tricolor) {
		RGBcolor (v3->r, v3->g, v3->b);
	}
	v[0] = MKFLT (v3->xint, v3->xfrac);
	v[1] = MKFLT (v3->yint, v3->yfrac);
	v[2] = MKFLT (v3->zint, v3->zfrac);
	v3f (v);
	endpolygon ();

	winset(winid);
}

void drawstats (int numv, int numt)
{
	char	str[128];

	pushmatrix ();
	ortho2 (0, 512, 512, 0);
	cpack (0x00ffffff);

	sprintf (str, "Number of vertices: %d", numv);
	cmov2i (10, 15);
	charstr (str);

	sprintf (str, "Number of triangles: %d", numt);
	cmov2i (10, 30);
	charstr (str);

	popmatrix ();
}


void endcomp(long wid)
{
	float	v[3];

	winset(wid);

	popmatrix ();
	swapbuffers ();
}

void enddraw (void)
{
	popmatrix ();
	swapbuffers ();

	winset(winidm);
	popmatrix ();
	swapbuffers ();

	endcomp(winidx);
	endcomp(winidy);
	endcomp(winidz);

	winset(winids);
	popmatrix ();
	swapbuffers ();

	winset(winid);
}

void sendword(FILE *fp, unsigned int w)
{
	char c[4];
	
	c[3] = (w) & 0xFF;
	c[2] = (w>>8) & 0xFF;
	c[1] = (w>>16) & 0xFF;
	c[0] = (w>>24) & 0xFF;
	fprintf(fp,"%c%c%c%c",c[0],c[1],c[2],c[3]);
}
void sendhalf(FILE *fp, unsigned int w)
{
	char c[2];
	
	c[1] = (w) & 0xFF;
	c[0] = (w>>8) & 0xFF;
	fprintf(fp,"%c%c",c[0],c[1]);
}
void sendbyte(FILE *fp, unsigned int w)
{
	char c;
	
	c = (w) & 0xFF;
	fprintf(fp,"%c",c);
}

void dumptask(void)
{
	FILE *fp;

	printf("Dumping an rsp task with all data to draw the current triangle...\n");
	if (!(fp=fopen("cliptst.dump","w"))) {
		printf("...could not open cliptst.dump\n");
		return;
	}

		/* send the task header */
#define DISPLAY_LIST		0x00000018	/* right after task header */
#define DISPLAY_LIST_LEN	0x00000048
#define DISPLAY_LIST_TYPE	0x01000001
#define UCODE_ADDR			0x00001000	/* store code here later */
#define UCODE_DATA			0x00003000	/* store data here later */
#define UCODE_DATA_SIZE		0x00000100
#define SEG0_ADDR			(DISPLAY_LIST+DISPLAY_LIST_LEN)
#define SEG0				0x00
	sendword(fp,DISPLAY_LIST);
	sendword(fp,DISPLAY_LIST_LEN);
	sendword(fp,DISPLAY_LIST_TYPE);
	sendword(fp,UCODE_ADDR);
	sendword(fp,UCODE_DATA);
	sendword(fp,UCODE_DATA_SIZE);

		/* send the display list */
	sendword(fp,0xbc000000);		/* segment command */
	sendword(fp,SEG0 | SEG0_ADDR);	/* segment0 = where data starts */
	sendword(fp,0x00030040);		/* projection matrix */
	sendword(fp,0x00000000);		/* first thing in data segment */
	sendword(fp,0x00020040);		/* model matrix (identity) */
	sendword(fp,0x00000040);		/* 2nd thing in data segment */
	sendword(fp,0xfc434c86);		/* setcombine mode */
	sendword(fp,0xf4ffffff);		/*   combine mode (copied from rotate.dump) */
	sendword(fp,0xf7000000);		/* set fill color */
	sendword(fp,0x0000ffff);		/* fill color (cyan(?)) */
	sendword(fp,0x02000010);		/* viewport */
	sendword(fp,0x00000080);		/* 3rd thing in data segment */
	sendword(fp,0xfc434c86);		/* setcombine mode */
	sendword(fp,0xf4ffffff);		/*   combine mode (copied from rotate.dump) */
	sendword(fp,0x03300030);		/* vertex command (3 vertices) (v0=0) */
	sendword(fp,0x00000090);		/* 4th thing in data segment */
	sendword(fp,0xbf000000);		/* triangle command */
	sendword(fp,0x00000102);		/*   use vtx 0,1,2 */

		/* send data segment 0 */
	sendword(fp,(int)(pmat[0][0]*65536));	/* projection matrix */
	sendword(fp,(int)(pmat[0][1]*65536));
	sendword(fp,(int)(pmat[0][2]*65536));
	sendword(fp,(int)(pmat[0][3]*65536));
	sendword(fp,(int)(pmat[1][0]*65536));
	sendword(fp,(int)(-pmat[1][1]*65536));
	sendword(fp,(int)(pmat[1][2]*65536));
	sendword(fp,(int)(pmat[1][3]*65536));
	sendword(fp,(int)(pmat[2][0]*65536));
	sendword(fp,(int)(pmat[2][1]*65536));
	sendword(fp,(int)(pmat[2][2]*65536));
	sendword(fp,(int)(pmat[2][3]*65536));
	sendword(fp,(int)(pmat[3][0]*65536));
	sendword(fp,(int)(pmat[3][1]*65536));
	sendword(fp,(int)(pmat[3][2]*65536));
	sendword(fp,(int)(pmat[3][3]*65536));

	sendword(fp,0x00010000);				/* model matrix (identity) */
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00010000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00010000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00000000);
	sendword(fp,0x00010000);

	sendword(fp,0x014000f0);				/* viewport (copied from rotate.dump) */
	sendword(fp,0x00000140);
	sendword(fp,0x00f00000);
	sendword(fp,0x00000000);

	sendhalf(fp,(int)vert[0].xmod);	/* x */		/* vertex 1 */
	sendhalf(fp,(int)vert[0].ymod); /* y */
	sendhalf(fp,(int)vert[0].zmod);	/* z */
	sendhalf(fp,0x0000);			/* flag */
	sendword(fp,0x00000000);		/* s, t */
	sendbyte(fp,(int)vert[0].r);	/* r */
	sendbyte(fp,(int)vert[0].g);	/* g */
	sendbyte(fp,(int)vert[0].b);	/* b */
	sendbyte(fp,(int)vert[0].a);	/* a */

	sendhalf(fp,(int)vert[1].xmod);	/* x */		/* vertex 2 */
	sendhalf(fp,(int)vert[1].ymod); /* y */
	sendhalf(fp,(int)vert[1].zmod);	/* z */
	sendhalf(fp,0x0000);			/* flag */
	sendword(fp,0x00000000);		/* s, t */
	sendbyte(fp,(int)vert[1].r);	/* r */
	sendbyte(fp,(int)vert[1].g);	/* g */
	sendbyte(fp,(int)vert[1].b);	/* b */
	sendbyte(fp,(int)vert[1].a);	/* a */

	sendhalf(fp,(int)vert[2].xmod);	/* x */		/* vertex 3 */
	sendhalf(fp,(int)vert[2].ymod); /* y */
	sendhalf(fp,(int)vert[2].zmod);	/* z */
	sendhalf(fp,0x0000);			/* flag */
	sendword(fp,0x00000000);		/* s, t */
	sendbyte(fp,(int)vert[2].r);	/* r */
	sendbyte(fp,(int)vert[2].g);	/* g */
	sendbyte(fp,(int)vert[2].b);	/* b */
	sendbyte(fp,(int)vert[2].a);	/* a */

	fflush(fp);
	fclose(fp);
	printf("...done\n");
}

void printhelp(void)
{
printf("   HELP\n");
printf("   -------------------------------------------------\n");
printf("   PRESS H       Print this help message\n");
printf("\n");
printf("   BUTTONS\n");
printf("   -------------------------------------------------\n");
printf("   LEFT SHIFT    turn vertex colors on\n");
printf("   TAB KEY       mouse controls frustum\n");
printf("   LEFT CTRL     mouse controls object\n");
printf("   NONE OF ABOVE mouse controls view\n");
printf("\n");
printf("   MOUSE\n");
printf("   -------------------------------------------------\n");
printf("   LEFT BUTTON   rotate on the Y and X axis\n");
printf("   MIDDLE BUTTON translate along the X and Y axis\n");
printf("   RIGH BUTTON   left/right= translate Z axis    up/down=uniform scale\n");
printf("\n");
printf("   PRINTING\n");
printf("   -------------------------------------------------\n");
printf("   T KEY         print transform matrices\n");
printf("   P KEY         print points in modelling (world) and clip space\n");
printf("\n");
printf("   MOVING VERTICES IN CLIPSPACE\n");
printf("   -------------------------------------------------\n");
printf("   X KEY         move point in the w/x plane\n");
printf("   Y KEY         move point in the w/y plane\n");
printf("   Z KEY         move point in the w/z plane\n");
printf("   LEFT MOUSE    moves vertex 1\n");
printf("   MIDDLE MOUSE  moves vertex 2\n");
printf("   RIGHT MOUSE   moves vertex 3\n");
printf("   R KEY         recalculate clip coords from model coords generated from\n");
printf("                      inverse transformed clip coordinates.\n");
printf("   M KEY         move point modelling coords in x/y\n");
printf("   N KEY         move point modelling coords in x/z\n");
printf("\n");
printf("   OTHER KEYS\n");
printf("   -------------------------------------------------\n");
printf("   F KEY         Fix the coordinate system in the x/w, y/w, and z/w windows\n");
printf("   V KEY         Vary the coordinate system (default)\n");
printf("   D KEY         Dump a task with mtrx, vtx, and tri data to file cliptst.dump\n");
printf("\n");
}

int getinput (void)
{
	int		dev;
	short		val;
	static long	leftdownx = -1, leftdowny = -1;
	static long	middledownx = -1, middledowny = -1;
	static long	rightdownx = -1, rightdowny = -1;
	static float oldazim, oldinc;
	static float oldvdist, oldvtransx, oldvtransy, oldvtransz;
	static float oldtrix, oldtriy, oldtriz, oldtrisize;
	static float oldtriaz, oldtriinc;
	static float oldpeyez, oldpright, oldpleft, oldptop, oldpbottom, oldpnear, oldpfar;
	static int	didhelp=0;
	static int	view_rot=0, view_trans=0, view_scale=0;
	static int	frus_rot=0, frus_trans=0, frus_scale=0;
	static int	obj_rot=0, obj_trans=0, obj_scale=0;
	static float oldxhom1,oldyhom1,oldzhom1,oldwhom1;
	static float oldxhom2,oldyhom2,oldzhom2,oldwhom2;
	static float oldxhom3,oldyhom3,oldzhom3,oldwhom3;
	static int	movx1=0,movy1=0,movz1=0;
	static int	movx2=0,movy2=0,movz2=0;
	static int	movx3=0,movy3=0,movz3=0;
	static int	movmx1=0,movmy1=0;
	static int	movmx2=0,movmy2=0;
	static int	movmx3=0,movmy3=0;

	if (qtest ()) {
		dev = qread (&val);
		if (dev == ESCKEY && val == 0) {
			return 0;
		}
		if (dev == SPACEKEY && val == 1) {
			dump = 1;
		}
		if (dev == DKEY && val == 1) dumptask();
		if (dev == FKEY && val == 1) fixmax=1;
		if (dev == VKEY && val == 1) fixmax=0;
		if (dev == RKEY && val == 1) {
			doxform(&vert[0]);
			doxform(&vert[1]);
			doxform(&vert[2]);
		}
		if (dev == PKEY && val == 1) {
/*			if (!didhelp)	*/
				printpoints();
/*			didhelp=1;
		} else {
			didhelp=0;	*/
		}
		if (dev == TKEY && val == 1) {
/*			if (!didhelp)	*/
				printf("\n   MODELLING->CLIP MATRIX\n");
				printmatrix(pmat);
				printf("\n   INVERSE MATRIX\n");
				printmatrix(imat);
/*			didhelp=1;
		} else {
			didhelp=0;	*/
		}
		if (dev == HKEY && val == 1) {
/*			if (!didhelp)	*/
				printhelp();
/*			didhelp=1;
		} else {
			didhelp=0;	*/
		}

		if (dev == LEFTMOUSE) {
			if (val == 1) {
				leftdownx = getvaluator (MOUSEX);
				leftdowny = getvaluator (MOUSEY);
				if (getbutton(TABKEY)) {
					oldpeyez = peyez;
					frus_rot=1;
				} else if (getbutton(LEFTCTRLKEY)) {
					oldtriaz=triaz;
					oldtriinc=triinc;
					obj_rot=1;
					calctri=1;
					maketri=1;
				} else if (getbutton(XKEY)) {
					oldxhom1=vert[0].xhom;
					oldwhom1=vert[0].whom;
					movx1=1;
					calctri=0;
				} else if (getbutton(YKEY)) {
					oldyhom1=vert[0].yhom;
					oldwhom1=vert[0].whom;
					movy1=1;
					calctri=0;
				} else if (getbutton(ZKEY)) {
					oldzhom1=vert[0].zhom;
					oldwhom1=vert[0].whom;
					movz1=1;
					calctri=0;
				} else if (getbutton(MKEY)) {
					oldxhom1=vert[0].xmod;
					oldyhom1=vert[0].ymod;
					movmx1=1;
					maketri=0;
				} else if (getbutton(NKEY)) {
					oldxhom1=vert[0].xmod;
					oldzhom1=vert[0].zmod;
					movmy1=1;
					maketri=0;
				} else {
					oldazim = vazim;
					oldinc = vinc;
					view_rot=1;
				}
			} else {
				view_rot=0;
				frus_rot=0;
				obj_rot=0;
				movmx1=0;
				movmy1=0;
				movx1=0;
				movy1=0;
				movz1=0;
			}
		}
		if (dev == MIDDLEMOUSE) {
			if (val == 1) {
				middledownx = getvaluator (MOUSEX);
				middledowny = getvaluator (MOUSEY);
				if (getbutton(TABKEY)) {
					oldptop=ptop;
					oldpbottom=pbottom;
					oldpright=pright;
					oldpleft=pleft;
					frus_trans=1;
				} else if (getbutton(LEFTCTRLKEY)) {
					oldtrix = trix;
					oldtriy = triy;
					obj_trans=1;
					calctri=1;
					maketri=1;
				} else if (getbutton(XKEY)) {
					oldxhom2=vert[1].xhom;
					oldwhom2=vert[1].whom;
					movx2=1;
					calctri=0;
				} else if (getbutton(YKEY)) {
					oldyhom2=vert[1].yhom;
					oldwhom2=vert[1].whom;
					movy2=1;
					calctri=0;
				} else if (getbutton(ZKEY)) {
					oldzhom2=vert[1].zhom;
					oldwhom2=vert[1].whom;
					movz2=1;
					calctri=0;
				} else if (getbutton(MKEY)) {
					oldxhom2=vert[1].xmod;
					oldyhom2=vert[1].ymod;
					movmx2=1;
					maketri=0;
				} else if (getbutton(NKEY)) {
					oldxhom2=vert[1].xmod;
					oldzhom2=vert[1].zmod;
					movmy2=1;
					maketri=0;
				} else {
					oldvtransx = vtransx;
					oldvtransy = vtransy;
					view_trans=1;
				}
			} else {
				view_trans=0;
				frus_trans=0;
				obj_trans=0;
				movmx2=0;
				movmy2=0;
				movx2=0;
				movy2=0;
				movz2=0;
			}
		}
		if (dev == RIGHTMOUSE) {
			if (val == 1) {
				rightdownx = getvaluator (MOUSEX);
				rightdowny = getvaluator (MOUSEY);
				if (getbutton(TABKEY)) {
					oldpnear=pnear;
					oldpfar=pfar;
					frus_scale=1;
				} else if (getbutton(LEFTCTRLKEY)) {
					oldtrisize = trisize;
					oldtriz = triz;
					obj_scale=1;
					calctri=1;
					maketri=1;
				} else if (getbutton(XKEY)) {
					oldxhom3=vert[2].xhom;
					oldwhom3=vert[2].whom;
					movx3=1;
					calctri=0;
				} else if (getbutton(YKEY)) {
					oldyhom3=vert[2].yhom;
					oldwhom3=vert[2].whom;
					movy3=1;
					calctri=0;
				} else if (getbutton(ZKEY)) {
					oldzhom3=vert[2].zhom;
					oldwhom3=vert[2].whom;
					movz3=1;
					calctri=0;
				} else if (getbutton(MKEY)) {
					oldxhom3=vert[2].xmod;
					oldyhom3=vert[2].ymod;
					movmx3=1;
					maketri=0;
				} else if (getbutton(NKEY)) {
					oldxhom3=vert[2].xmod;
					oldzhom3=vert[2].zmod;
					movmy3=1;
					maketri=0;
				} else {
					oldvtransz = vtransz;
					oldvdist = vdist;
					view_scale=1;
				}
			} else {
				view_scale=0;
				frus_scale=0;
				obj_scale=0;
				movmx3=0;
				movmy3=0;
				movx3=0;
				movy3=0;
				movz3=0;
			}
		}
	}

	if (view_rot) {
		vazim = oldazim + leftdownx - getvaluator (MOUSEX);
		vinc = oldinc + leftdowny - getvaluator (MOUSEY);
	}
	if (obj_rot) {
		triaz = oldtriaz + leftdownx - getvaluator (MOUSEX);
		triinc = oldtriinc + leftdowny - getvaluator (MOUSEY);
	}
	if (frus_rot) {
		peyez = oldpeyez + (getvaluator (MOUSEX) - leftdownx)*0.0018*modscale;
	}
	if (obj_trans) {
		trix = oldtrix + (getvaluator (MOUSEX) - middledownx)*0.0018*modscale;
		triy = oldtriy + (getvaluator (MOUSEY) - middledowny)*0.0018*modscale;
	}
	if (frus_trans) {
		pright = oldpright + (getvaluator (MOUSEX) - middledownx)*0.0018*modscale;
		pleft = oldpleft - (getvaluator (MOUSEX) - middledownx)*0.0018*modscale;
		ptop = oldptop + (getvaluator (MOUSEY) - middledowny)*0.0018*modscale;
		pbottom = oldpbottom - (getvaluator (MOUSEY) - middledowny)*0.0018*modscale;
	}
	if (view_trans) {
		vtransx = oldvtransx - (getvaluator (MOUSEX) - middledownx)*0.0018*modscale;
		vtransy = oldvtransy - (getvaluator (MOUSEY) - middledowny)*0.0018*modscale;
	}
	if (obj_scale) {
		triz = oldtriz + (getvaluator (MOUSEX) - rightdownx)*0.0018*modscale;
		trisize = oldtrisize + (getvaluator (MOUSEY) - rightdowny)*0.0018/5*modscale;
	}
	if (view_scale) {
		vtransz = oldvtransz + (getvaluator (MOUSEX) - rightdownx)*0.0018*modscale;
		vdist = oldvdist - (getvaluator (MOUSEY) - rightdowny)*0.0018*modscale;
	}
	if (frus_scale) {
		pnear = oldpnear + (getvaluator (MOUSEX) - rightdownx)*0.0018*modscale;
		pfar = oldpfar - (getvaluator (MOUSEY) - rightdowny)*0.0018*modscale;
	}

	if (movmx1) {
		vert[0].xmod = oldxhom1 + (getvaluator (MOUSEX) - leftdownx)*0.018*modscale;
		vert[0].ymod = oldyhom1 + (getvaluator (MOUSEY) - leftdowny)*0.018*modscale;
	}
	if (movmx2) {
		vert[1].xmod = oldxhom2 + (getvaluator (MOUSEX) - middledownx)*0.018*modscale;
		vert[1].ymod = oldyhom2 + (getvaluator (MOUSEY) - middledowny)*0.018*modscale;
	}
	if (movmx3) {
		vert[2].xmod = oldxhom3 + (getvaluator (MOUSEX) - rightdownx)*0.018*modscale;
		vert[2].ymod = oldyhom3 + (getvaluator (MOUSEY) - rightdowny)*0.018*modscale;
	}
	if (movmy1) {
		vert[0].xmod = oldxhom1 + (getvaluator (MOUSEX) - leftdownx)*0.018*modscale;
		vert[0].zmod = oldzhom1 + (getvaluator (MOUSEY) - leftdowny)*0.018*modscale;
	}
	if (movmy2) {
		vert[1].xmod = oldxhom2 + (getvaluator (MOUSEX) - middledownx)*0.018*modscale;
		vert[1].zmod = oldzhom2 + (getvaluator (MOUSEY) - middledowny)*0.018*modscale;
	}
	if (movmy3) {
		vert[2].xmod = oldxhom3 + (getvaluator (MOUSEX) - rightdownx)*0.018*modscale;
		vert[2].zmod = oldzhom3 + (getvaluator (MOUSEY) - rightdowny)*0.018*modscale;
	}

	if (movx1) {
		vert[0].xhom = oldxhom1 + (getvaluator (MOUSEY) - leftdowny)*0.018;
		vert[0].whom = oldwhom1 + (getvaluator (MOUSEX) - leftdownx)*0.018;
	}
	if (movx2) {
		vert[1].xhom = oldxhom2 + (getvaluator (MOUSEY) - middledowny)*0.018;
		vert[1].whom = oldwhom2 + (getvaluator (MOUSEX) - middledownx)*0.018;
	}
	if (movx3) {
		vert[2].xhom = oldxhom3 + (getvaluator (MOUSEY) - rightdowny)*0.018;
		vert[2].whom = oldwhom3 + (getvaluator (MOUSEX) - rightdownx)*0.018;
	}
	if (movy1) {
		vert[0].yhom = oldyhom1 + (getvaluator (MOUSEY) - leftdowny)*0.018;
		vert[0].whom = oldwhom1 + (getvaluator (MOUSEX) - leftdownx)*0.018;
	}
	if (movy2) {
		vert[1].yhom = oldyhom2 + (getvaluator (MOUSEY) - middledowny)*0.018;
		vert[1].whom = oldwhom2 + (getvaluator (MOUSEX) - middledownx)*0.018;
	}
	if (movy3) {
		vert[2].yhom = oldyhom3 + (getvaluator (MOUSEY) - rightdowny)*0.018;
		vert[2].whom = oldwhom3 + (getvaluator (MOUSEX) - rightdownx)*0.018;
	}
	if (movz1) {
		vert[0].zhom = oldzhom1 + (getvaluator (MOUSEY) - leftdowny)*0.018;
		vert[0].whom = oldwhom1 + (getvaluator (MOUSEX) - leftdownx)*0.018;
	}
	if (movz2) {
		vert[1].zhom = oldzhom2 + (getvaluator (MOUSEY) - middledowny)*0.018;
		vert[1].whom = oldwhom2 + (getvaluator (MOUSEX) - middledownx)*0.018;
	}
	if (movz3) {
		vert[2].zhom = oldzhom3 + (getvaluator (MOUSEY) - rightdowny)*0.018;
		vert[2].whom = oldwhom3 + (getvaluator (MOUSEX) - rightdownx)*0.018;
	}


	makematrix();

	return 1;
}

unsigned char gen_clip_codes (struct vertex *v)
{
	/*
	 * Clip codes are packed as follows:
	 *
	 *   Bit 0:  On if x <= -w
	 *   Bit 1:  On if x >= w
	 *   Bit 2:  On if y <= -w
	 *   Bit 3:  On if y >= w
	 *   Bit 4:  On if z <= -w
	 *   Bit 5:  On if z >= w
	 */

	unsigned char	cc;
	i32		x, y, z, w;

	x = MKFIX (v->xint, v->xfrac);
	y = MKFIX (v->yint, v->yfrac);
	z = MKFIX (v->zint, v->zfrac);
	w = MKFIX (v->wint, v->wfrac);

	cc = 0;

	if (x <= -w) {
		cc |= 1;
	}
	if (x >= w) {
		cc |= 2;
	}
	if (y <= -w) {
		cc |= 4;
	}
	if (y >= w) {
		cc |= 8;
	}
	if (z <= -w) {
		cc |= 16;
	}
	if (z >= w) {
		cc |= 32;
	}

	return cc;
}

void maketriangle (int v1, int v2, int v3)
{
	struct vertex	*v;
	float	x,y,z;

	if (!fixmax)
		coordmax=0;

	if (maketri) {
		v = &vert[v1];
		x = 5 * trisize;
		y = 5 * trisize;
		z = 5 * trisize;
		v->ymod = (y*cos(triinc*M_PI/180) + z*sin(triinc*M_PI/180)+triy);
		z 		= z*cos(triinc*M_PI/180) + y*sin(triinc*M_PI/180);
		v->xmod = (x*cos(triaz*M_PI/180) + z*sin(triaz*M_PI/180)+trix);
		v->zmod = (z*cos(triaz*M_PI/180) + x*sin(triaz*M_PI/180)+triz);
	/*	v->xint = 5 * trisize + trix;
		v->yint = 5 * trisize + triy;
		v->zint = 5 * trisize + triz;
		v->wint = 1000;
		v->xfrac = 0;
		v->yfrac = 0;
		v->zfrac = 0;
		v->wfrac = 0;	*/
		v->xscr = 0;			/* Should be set here		*/
		v->yscr = 0;			/* Should be set here		*/
		v->s = 0;
		v->t = 0;
	/*	v->cc = gen_clip_codes (v);*/
		v->flag = 0;
		v->a = 255;
		v->b = 0;
		v->g = 0;
		v->r = 255;
		v->pad = 0;
	
		v = &vert[v2];
		x = 3 * trisize;
		y = 4 * trisize;
		z = -3 * trisize;
		v->ymod = (y*cos(triinc*M_PI/180) + z*sin(triinc*M_PI/180)+triy);
		z 		= z*cos(triinc*M_PI/180) + y*sin(triinc*M_PI/180);
		v->xmod = (x*cos(triaz*M_PI/180) + z*sin(triaz*M_PI/180)+trix);
		v->zmod = (z*cos(triaz*M_PI/180) + x*sin(triaz*M_PI/180)+triz);
	/*	v->xint = 3 * trisize + trix;
		v->yint = 4 * trisize + triy;
		v->zint = -3 * trisize + triz;
		v->wint = 1000;
		v->xfrac = 0;
		v->yfrac = 0;
		v->zfrac = 0;
		v->wfrac = 0; 	*/
		v->xscr = 0;			/* Should be set here		*/
		v->yscr = 0;			/* Should be set here		*/
		v->s = 0;
		v->t = 0;
	/*	v->cc = gen_clip_codes (v);*/
		v->flag = 0;
		v->a = 255;
		v->b = 0;
		v->g = 255;
		v->r = 0;
		v->pad = 0;
	
		v = &vert[v3];
		x = -5 * trisize;
		y = -3 * trisize;
		z = 1 * trisize;
		v->ymod = (y*cos(triinc*M_PI/180) + z*sin(triinc*M_PI/180)+triy);
		z 		= z*cos(triinc*M_PI/180) + y*sin(triinc*M_PI/180);
		v->xmod = (x*cos(triaz*M_PI/180) + z*sin(triaz*M_PI/180)+trix);
		v->zmod = (z*cos(triaz*M_PI/180) + x*sin(triaz*M_PI/180)+triz);
	/*	v->wint = 1000;
		v->xfrac = 0;
		v->yfrac = 0;
		v->zfrac = 0;
		v->wfrac = 0;	*/
		v->xscr = 0;			/* Should be set here		*/
		v->yscr = 0;			/* Should be set here		*/
		v->s = 0;
		v->t = 0;
	/*	v->cc = gen_clip_codes (v);*/
		v->flag = 0;
		v->a = 255;
		v->b = 255;
		v->g = 0;
		v->r = 0;
		v->pad = 0;
	}
}

void doxform(struct vertex *v)
{
	v->xhom = pmat[0][0]*v->xmod + pmat[0][1]*v->ymod + pmat[0][2]*v->zmod + pmat[0][3];
	v->yhom = pmat[1][0]*v->xmod + pmat[1][1]*v->ymod + pmat[1][2]*v->zmod + pmat[1][3];
	v->zhom = pmat[2][0]*v->xmod + pmat[2][1]*v->ymod + pmat[2][2]*v->zmod + pmat[2][3];
	v->whom = pmat[3][0]*v->xmod + pmat[3][1]*v->ymod + pmat[3][2]*v->zmod + pmat[3][3];
}

void xformtriangle(struct vertex *v)
{
	int		x,y,z;
	float w;


  if (calctri) {  /* calculate clip coordinates (homogeneous) from modelling coords */
/*
	v->xhom = pmat[0][0]*v->xmod + pmat[0][1]*v->ymod + pmat[0][2]*v->zmod + pmat[0][3];
	v->yhom = pmat[1][0]*v->xmod + pmat[1][1]*v->ymod + pmat[1][2]*v->zmod + pmat[1][3];
	v->zhom = pmat[2][0]*v->xmod + pmat[2][1]*v->ymod + pmat[2][2]*v->zmod + pmat[2][3];
	v->whom = pmat[3][0]*v->xmod + pmat[3][1]*v->ymod + pmat[3][2]*v->zmod + pmat[3][3];
*/
		/* integer modelling coordinates: */
	x=(int)v->xmod;
	y=(int)v->ymod;
	z=(int)v->zmod;
	v->xhom = pmat[0][0]*x + pmat[0][1]*y + pmat[0][2]*z + pmat[0][3];
	v->yhom = pmat[1][0]*x + pmat[1][1]*y + pmat[1][2]*z + pmat[1][3];
	v->zhom = pmat[2][0]*x + pmat[2][1]*y + pmat[2][2]*z + pmat[2][3];
	v->whom = pmat[3][0]*x + pmat[3][1]*y + pmat[3][2]*z + pmat[3][3];
  } else {			/* calculate modelling coords from clip coordinates (homogeneous) */
	v->xmod = imat[0][0]*v->xhom + imat[0][1]*v->yhom + imat[0][2]*v->zhom + 
																	imat[0][3]*v->whom;
	v->ymod = imat[1][0]*v->xhom + imat[1][1]*v->yhom + imat[1][2]*v->zhom + 
																	imat[1][3]*v->whom;
	v->zmod = imat[2][0]*v->xhom + imat[2][1]*v->yhom + imat[2][2]*v->zhom + 
																	imat[2][3]*v->whom;
	w 		= imat[3][0]*v->xhom + imat[3][1]*v->yhom + imat[3][2]*v->zhom + 
																	imat[3][3]*v->whom;

	/* divide by w */
	v->xmod = v->xmod / w;
	v->ymod = v->ymod / w;
	v->zmod = v->zmod / w;
  }

	v->xint = MKINT(v->xhom);
	v->xfrac = MKFRAC(v->xhom);

	v->yint = MKINT(v->yhom);
	v->yfrac = MKFRAC(v->yhom);

	v->zint = MKINT(v->zhom);
	v->zfrac = MKFRAC(v->zhom);

	v->wint = MKINT(v->whom);
	v->wfrac = MKFRAC(v->whom);



	if (!fixmax) {
		coordmax = MAX(coordmax,fabs(v->xhom));
		coordmax = MAX(coordmax,fabs(v->yhom));
		coordmax = MAX(coordmax,fabs(v->zhom));
		coordmax = MAX(coordmax,fabs(v->whom));
	}
}

/*
 * Fixed point divide.
 */

i32 Div (i32 a, i32 b)
{
	double		af, bf, cf;

	af = (double)a / FRAC;
	bf = (double)b / FRAC;

	if (bf == 0) {
		cf = 0;
	} else {
		cf = af / bf;
	}

	return (i32)(cf * FRAC);
}

/*
 * Fixed point multiply.
 */

i32 Mult (i32 a, i32 b)
{
	double		af, bf, cf;
	i32		val;

	af = (double)a / FRAC;
	bf = (double)b / FRAC;
	cf = af * bf;
	if (cf > 32767 || cf < -32767) {
		if ((af < 0 && bf >= 0) || (af >= 0 && bf < 0)) {
			val = 0x80000000;   /* big negative */
		} else {
			val = 0x7fffffff;   /* big positive */
		}
	} else {
		val = (i32)(cf * FRAC);
	}

	return val;
}

void dividevertex (struct vertex *v)
{
	i32		pt, w;

	w = MKFIX (v->wint, v->wfrac);

	pt = MKFIX (v->xint, v->xfrac);
	pt = Div (pt, w);
	v->xint = pt >> SHIFT;
	v->xfrac = pt & MASK;

	pt = MKFIX (v->yint, v->yfrac);
	pt = Div (pt, w);
	v->yint = pt >> SHIFT;
	v->yfrac = pt & MASK;

	pt = MKFIX (v->zint, v->zfrac);
	pt = Div (pt, w);
	v->zint = pt >> SHIFT;
	v->zfrac = pt & MASK;

	v->wint = 1;
	v->wfrac = 0;
}

void dumpvertex (int f, struct vertex *v)
{
	write (f, v, sizeof (struct vertex));
#if 0
	fprintf (f, "0x%04x ", (int)(unsigned short)v->xint);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->xfrac);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->yint);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->yfrac);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->zint);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->zfrac);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->wint);
	fprintf (f, "0x%04x ", (int)(unsigned short)v->wfrac);
	fprintf (f, "\n");
#endif
}

void cliptriangle (int v1, int v2, int v3)
{
	int	cc_clip, s, n, i, j, plane, flag, axis, inside, last_in;
	int	on, os;
	int	in, out;
	i32	d, pi, po, wi, wo, wone;
	float df;

	cc_clip = 0;
	cc_clip |= vert[v1].cc;
	cc_clip |= vert[v2].cc;
	cc_clip |= vert[v3].cc;

	temp[0] = vert[v1];
	temp[1] = vert[v2];
	temp[2] = vert[v3];

	if (cc_clip == 0) {
		dividevertex (&temp[v1]);
		dividevertex (&temp[v2]);
		dividevertex (&temp[v3]);
		drawtriangle (&temp[v1], &temp[v2], &temp[v3], 0x000000ff);
		return;
	}

	s = 0;	/* Start vertex */
	n = 3;  /* Number of vertices */

	for (plane = 0; plane < 6; plane++) {
		flag = 1 << plane;
		if (!(flag & cc_clip)) {
			/* This plane not cut by anyone */
			continue;
		}
		cc_clip = 0;		/* We'll rebuild this from scratch */
		axis = plane >> 1;	/* Which axis we're dealing with   */
		j = s + n - 1;		/* Previous vertex		   */
		inside = !(temp[j].cc & flag); /* If last vertex is inside */
		os = 9 - s;
		on = os;
		for (i = s; i < s + n; i++) {
			last_in = inside;
			inside = !(temp[i].cc & flag);
			if (inside ^ last_in) { /* We've crossed the plane */
				/* Always clip in-to-out so shared edges have
				   the same vertex. */
				if (inside) {
					in = i;
					out = j;
				} else {
					in = j;
					out = i;
				}
				wi = MKFIX (temp[in].wint, temp[in].wfrac);
				wo = MKFIX (temp[out].wint, temp[out].wfrac);
				wone = 1 << SHIFT;
				switch (axis) {
					case 0: pi = MKFIX (temp[in].xint,
							temp[in].xfrac);
						po = MKFIX (temp[out].xint,
							temp[out].xfrac);
						break;	
					case 1: pi = MKFIX (temp[in].yint,
							temp[in].yfrac);
						po = MKFIX (temp[out].yint,
							temp[out].yfrac);
						break;	
					case 2: pi = MKFIX (temp[in].zint,
							temp[in].zfrac);
						po = MKFIX (temp[out].zint,
							temp[out].zfrac);
						break;	
				}
				if (!(plane & 1)) { /* Negative w plane	   */
					wi = -wi;
					wo = -wo;
					wone = -1 << SHIFT;
				}

				/*d = Div (wi - pi - wone, po - pi - wo + wi);*/
				d = Div (wi - pi , po - pi - wo + wi);

				pi = MKFIX (temp[in].xint, temp[in].xfrac);
				po = MKFIX (temp[out].xint, temp[out].xfrac);
				pi = Mult (po - pi, d) + pi;
				temp[on].xint = pi >> SHIFT;
				temp[on].xfrac = pi & MASK;

				pi = MKFIX (temp[in].yint, temp[in].yfrac);
				po = MKFIX (temp[out].yint, temp[out].yfrac);
				pi = Mult (po - pi, d) + pi;
				temp[on].yint = pi >> SHIFT;
				temp[on].yfrac = pi & MASK;

				pi = MKFIX (temp[in].zint, temp[in].zfrac);
				po = MKFIX (temp[out].zint, temp[out].zfrac);
				pi = Mult (po - pi, d) + pi;
				temp[on].zint = pi >> SHIFT;
				temp[on].zfrac = pi & MASK;

				pi = MKFIX (temp[in].wint, temp[in].wfrac);
				po = MKFIX (temp[out].wint, temp[out].wfrac);
				pi = Mult (po - pi, d) + pi;
				temp[on].wint = pi >> SHIFT;
				temp[on].wfrac = pi & MASK;

				pi = MKFIX (temp[in].r, 0);
				po = MKFIX (temp[out].r, 0);
				temp[on].r = (Mult (po - pi, d) + pi) >> SHIFT;

				pi = MKFIX (temp[in].g, 0);
				po = MKFIX (temp[out].g, 0);
				temp[on].g = (Mult (po - pi, d) + pi) >> SHIFT;

				pi = MKFIX (temp[in].b, 0);
				po = MKFIX (temp[out].b, 0);
				temp[on].b = (Mult (po - pi, d) + pi) >> SHIFT;

				pi = MKFIX (temp[in].a, 0);
				po = MKFIX (temp[out].a, 0);
				temp[on].a = (Mult (po - pi, d) + pi) >> SHIFT;

				pi = MKFIX (temp[in].s, 0);
				po = MKFIX (temp[out].s, 0);
				temp[on].s = (Mult (po - pi, d) + pi) >> SHIFT;

				pi = MKFIX (temp[in].t, 0);
				po = MKFIX (temp[out].t, 0);
				temp[on].t = (Mult (po - pi, d) + pi) >> SHIFT;

					/* This is for the fancy graphics output only */
				df = ((float) d) /65535;
				temp[on].xmod = temp[in].xmod + df*(temp[out].xmod-temp[in].xmod);
				temp[on].ymod = temp[in].ymod + df*(temp[out].ymod-temp[in].ymod);
				temp[on].zmod = temp[in].zmod + df*(temp[out].zmod-temp[in].zmod);
				temp[on].xhom = temp[in].xhom + df*(temp[out].xhom-temp[in].xhom);
				temp[on].yhom = temp[in].yhom + df*(temp[out].yhom-temp[in].yhom);
				temp[on].zhom = temp[in].zhom + df*(temp[out].zhom-temp[in].zhom);
				temp[on].whom = temp[in].whom + df*(temp[out].whom-temp[in].whom);
				

				temp[on].cc = gen_clip_codes (&temp[on]);
				cc_clip |= temp[on].cc;
				on++;
			}
			if (inside) {	/* This is a good point -- keep it */
				temp[on] = temp[i];
				cc_clip |= temp[on].cc;
				on++;
			}
			j = i;
		}
		n = on - os;
		s = os;
	}

	if (dump) {
		int	f;

		f = open (DUMPFN, O_WRONLY | O_CREAT | O_TRUNC, 0666);
		if (f == -1) {
			perror (DUMPFN);
			return;
		}

		dumpvertex (f, &vert[v1]);
		dumpvertex (f, &vert[v2]);
		dumpvertex (f, &vert[v3]);
		for (i = s; i < s + n; i++) {
			dumpvertex (f, &temp[i]);
		}
		close (f);
		dump = 0;
	}

	for (i = s; i < s + n; i++) {
		dividevertex (&temp[i]);
	}

	for (i = s + 1; i < s + n - 1; i++) {
		drawtriangle (&temp[s], &temp[i], &temp[i + 1], 0x000000ff);
	}

	drawstats (n, n - 2);
}

int main (void)
{
	printhelp();
	init ();
	initgraphics ();
	do {
		bgndraw ();

		maketriangle (0, 1, 2);
		xformtriangle(&vert[0]);
		xformtriangle(&vert[1]);
		xformtriangle(&vert[2]);
		dividevertex (&vert[0]);
		dividevertex (&vert[1]);
		dividevertex (&vert[2]);
		drawtriangle (&vert[0], &vert[1], &vert[2], 0x0000ff00);

		maketriangle (0, 1, 2);
		xformtriangle(&vert[0]);
		xformtriangle(&vert[1]);
		xformtriangle(&vert[2]);
		vert[0].cc = gen_clip_codes (&vert[0]);
		vert[1].cc = gen_clip_codes (&vert[1]);
		vert[2].cc = gen_clip_codes (&vert[2]);
		cliptriangle (0, 1, 2);

		maketriangle (0, 1, 2);
		xformtriangle(&vert[0]);
		xformtriangle(&vert[1]);
		xformtriangle(&vert[2]);

		enddraw ();
	} while (getinput ());
}
