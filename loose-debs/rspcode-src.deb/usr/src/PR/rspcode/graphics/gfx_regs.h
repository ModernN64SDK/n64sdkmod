
#ifndef _gfx_regs_h_
#define _gfx_regs_h_ 1

	
 ############################################################################	
 #
 # Scalar Register Usage Conventions:
 #
 # Starting from $31 growing down, we allocate 'permanent' registers.
 # These should only be re-used carefully, possibly saved/restored.
 # (during development we might re-shuffle these so the more crucial
 # or stable ones remain higher)
 #
 # Register $0 is always 0, as per the MIPS R4000 spec.
 #
 # Starting from $1 growing up, we use 'temporary' registers which
 # are free to be used by procedures or small blocks of code. These
 # registers are not named (or they are .name'd and .unname'd in small
 # code blocks).
 #
 # Function parameters are passed and returned in $1, $2, $3, etc.
 #
	
.name	return,		$31	# MIPS R4000 convention for JAL op
.name	return_save,	$30	# used for return addresses not in return
.name	rsp_state,	$29	# pointer to RSP state in DMEM
.name	dlcount,	$28	# curr counter of DL buffer
.name	dinp, 		$27	# curr pointer into DL buffer
.name	inp,		$26	# DRAM ptr of current DL location (for stack)
.name	gfx0, 		$25	# holds first word of DL command
.name	gfx1, 		$24	# holds second word of DL command
.name	outp,		$23	
.name	in_bufp,	$22
.name	zero,		$0
	
 ############################################################################	
 #
 # Vector Register Usage Conventions:
 #
 # Similar to scalar registers, named registers start at $v31 and grow down.
 # These should only be re-used carefully, possibly saved/restored.
 # (during development we might re-shuffle these so the more crucial
 # or stable ones remain higher)
 #
 # Register $v0 is NOT always 0, like in the MIPS R4000 spec.
 #
 # Starting from $v1 growing up, we use 'temporary' registers which
 # are free to be used by procedures or small blocks of code. These
 # registers are not named (or they are .name'd and .unname'd in small
 # code blocks).
 #
 # Function parameters are passed and returned in $v1, $v2, $v3, etc.
 #
.name   vconst,		$v31
.name   vconst1,	$v30


#endif /* _gfx_regs_h_ */
