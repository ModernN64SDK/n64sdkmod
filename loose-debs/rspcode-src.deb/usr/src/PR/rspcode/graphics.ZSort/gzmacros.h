/*---------------------------------------------------------------------
  $Id: gzmacros.h,v 1.2 2002/05/03 19:22:00 blythe Exp $
  
  File : gzmacros.h

  Coded     by Yoshitaka Yasumoto.   Jan 23, 1997.
  Copyright by Nintendo, Co., Ltd.           1997.
  ---------------------------------------------------------------------*/

#define	_lw(reg,ptr)	lw	reg, ptr($0)
#define	_sw(reg,ptr)	sw	reg, ptr($0)

#define	_li(r, x)	addi	r, $0, x
#define	_liu(r, x)	addiu	r, $0, x
#define	_mov(r, s)	ori	r,  s, 0

#define	_set_c0_regR(reg, x)			mtc0	x,    reg
#define	_set_c0_regI(reg, x)	_li(sys0, x)	mtc0	sys0, reg
#define	_set_sp_status(x)	_set_c0_regI(SP_STATUS, x)

#define	_flag_c0_nz_goto(flag, mask, label)	\
	mfc0	sys0, flag			\
	andi	sys0, sys0, mask		\
	bne	sys0, zero, label

#define	_flag_c0_z_goto(flag, mask, label)	\
	mfc0	sys0, flag			\
	andi	sys0, sys0, mask		\
	bne	sys0, zero, label

#define	_flag_nz_goto(flag, mask, label)	\
	lw	sys0, flag($0)		\
	andi	sys0, sys0, mask	\
	bne	sys0, zero, label

#define	_flag_z_goto(flag, mask, label)	\
	lw	sys0, flag($0)		\
	andi	sys0, sys0, mask	\
	beq	sys0, zero, label

#define	_if_gotoR(regA, cond, regB, label)	\
	sub		sys0, regA, regB	\
	b##cond##z	sys0, label

#define	_if_gotoI(regA, cond, immB, label)	\
	addi		sys0, regA, -(immB)	\
	b##cond##z	sys0, label

#define	_if_eq_gotoR(regA, regB, label)	\
	beq	regA, regB, label

#define	_if_eq_gotoI(regA, immB, label)	\
	addi	sys0, regA, -(immB)	\
	beq	sys0, $0, label

#define	_if_ne_gotoR(regA, regB, label)	\
	bne	regA, regB, label

#define	_if_ne_gotoI(regA, immB, label)	\
	addi	sys0, regA, -(immB)	\
	bne	sys0, $0, label

#define	_byte4(b0,b1,b2,b3)	.byte b0 .byte b1 .byte b2 .byte b3
#define	_byte8(b0,b1,b2,b3,b4,b5,b6,b7)	_byte4(b0,b1,b2,b3) _byte4(b4,b5,b6,b7)
#define	_half4(h0,h1,h2,h3)	.half h0 .half h1 .half h2 .half h3
#define	_half8(h0,h1,h2,h3,h4,h5,h6,h7)	_half4(h0,h1,h2,h3) _half4(h4,h5,h6,h7)
#define	_word4(w0,w1,w2,w3)	.word w0 .word w1 .word w2 .word w3
#define	_word8(w0,w1,w2,w3,w4,w5,w6,w7)	_word4(w0,w1,w2,w3) _word4(w4,w5,w6,w7)

#define	_forward_adrs(x,c)	here##x##:		\
				.symbol	dummy##x##, 0	\
				.symbol	x, here##x##+(c)*4

#define	AssignForDMAproc	Assign(iswrite,   17)	\
				Assign(dma_len,   18)	\
				Assign(dram_adrs, 19)	\
				Assign(dmem_adrs, 20)

#define	EndAssignForDMAproc	EndAssign(iswrite,   17)	\
				EndAssign(dma_len,   18)	\
				EndAssign(dram_adrs, 19)	\
				EndAssign(dmem_adrs, 20)
#ifdef	ASSERT
#define	Assert_geI(reg,  imm)	addi	sys0, reg, -(imm)	\
				bgezal	sys0, AssertHandler
#define	Assert_geR(reg1, reg2)	sub	sys0, reg1, reg2	\
				bgezal	sys0, AssertHandler
#define	Assert_ltI(reg,  imm)	addi	sys0, reg, -(imm)	\
				bltzal	sys0, AssertHandler
#define	Assert_ltR(reg1, reg2)	sub	sys0, reg1, reg2	\
				bltzal	sys0, AssertHandler
#define	AID			0x12345678
#else
#define	Assert_geI(reg,  imm)
#define	Assert_geR(reg1, reg2)
#define	Assert_ltI(reg,  imm)
#define	Assert_ltR(reg1, reg2)	
#define	AID			0x00000000
#endif

/*======== End of gzmacros.h ========*/
