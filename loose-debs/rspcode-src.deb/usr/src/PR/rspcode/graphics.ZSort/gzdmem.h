/*---------------------------------------------------------------------
  $Id: gzdmem.h,v 1.1.1.1 2002/05/02 03:29:12 blythe Exp $
  
  File : gzdmem.h

  Coded     by Yoshitaka Yasumoto.   Jun 17, 1997.
  Copyright by Nintendo, Co., Ltd.           1997.
  ---------------------------------------------------------------------*/
	.align	16
	.bound	16

/*---------------------------------------------------------------------------*
 *	グローバルステート
 *	LOADABLE なマイクロコード間で共通に使用するステータス領域
 *	
 *	TASK 起動時に初期化される. gSPLoadUcode の前後で値を保持する.
 *	ベクトルレジスタでの lqv 可能領域は +63 までなので注意が必要
 *---------------------------------------------------------------------------*/
RSP_STATE_OFFSET:	

	#---------------------------------------------------------------------
	# 4x4 Matrix データ領域
	#  3D 系のマイクロコードで M,P,MP の各行列に使用する.
	#---------------------------------------------------------------------
			.bound	16	
RSP_STATEP_MMTX:	.space	64	# M  行列
RSP_STATEP_PMTX:	.space	64	# P  行列
RSP_STATEP_MPMTX:	.space	64	# MP 行列

	#---------------------------------------------------------------------
	# シザリングパラメータ保存エリア (llv でアクセス可能な位置 +252)
	#---------------------------------------------------------------------
			.bound	4
			.dmax	63*4
RSP_STATEP_SCISSOR_XL:	.half	0
RSP_STATEP_SCISSOR_XH:	.half	320<<2
RSP_STATEP_SCISSOR_YL:	.half	0
RSP_STATEP_SCISSOR_YH:	.half	240<<2
	
	#---------------------------------------------------------------------
	# SetOtherMode パラメータ保存領域
	#   初期値
	#	0xef:	G_RDPSETOTHERMODE
	#	0x08	テクスチャパース補正 ON
	#	0x0c	Cycle0,1 のテクスチャ Bilerp ON
	#	0xff	rgb dither = no dither / alpha_dither = no dither
	#---------------------------------------------------------------------
			.bound	8
RSP_STATEP_OTHER_H:	.word	0xef080cff
RSP_STATEP_OTHER_L:	.word	0x00000000
	
	#---------------------------------------------------------------------
	# PerspNormalize の値 (llv でアクセス可能な位置 +252)
	#---------------------------------------------------------------------
			.bound	4
			.dmax	63*4
RSP_STATEP_PERSPNORM:	.word	0	# 有効なのは下位 16 bitのみ

	#---------------------------------------------------------------------
	# RDPHALF_0, RDPHALF_1 コマンドの保存領域
	#---------------------------------------------------------------------
RSP_STATEP_RDPHALF_0H:	.word	0x0
RSP_STATEP_RDPHALF_0L:	.word	0x0
RSP_STATEP_RDPHALF_1L:	.word	0x0
	#
	# RSP_STATEP_RDPHALF_0L と RSP_STATEP_RDPHALF_1L のアドレスの差が
	# 4Bytes = 1inst であることを利用して, gzrdp.s で命令を節約している.
	# このためここに手を加えるときは, その部分を修正する必要がある.
	# (rdp_G_RDPHALF_0/rdp_G_RDPHALF_1 の実装部)
	
	#---------------------------------------------------------------------
	# View Port パラメータ (ldv でアクセス可能な位置 +504)
	#---------------------------------------------------------------------
			.bound	8
			.dmax	63*8
RSP_STATEP_VIEWPORT_SC:	.word	0
			.word	0
RSP_STATEP_VIEWPORT_TX:	.word	0
			.word	0	
	
	#---------------------------------------------------------------------
	# セーブした DL の数
	#---------------------------------------------------------------------
RSP_STATEP_DL_N:	.byte	0		# Main DL
			.byte	18*4		# Sub  DL

	#---------------------------------------------------------------------
	# 現在の RDP の状態
	#   Sync を管理するために導入. 以下の条件で Sync コマンドを発行する
	#
	#	(A) プリミティブの作画前に RDP_STAT_LOADTILE なら PipeSync を
	#	    送信し, RDP_STAT_PRIM_TILE(n) に変更.
	#	(B) レンダーモードの変更時に RDP_STAT_PRIMITIVE なら PipeSync
	#	    を送信し, RDP_STAT_NON に変更.
	#	(C) LoadTile/LoadBlock/LoadTLUT 時に RDP_STAT_PRIM_TILE(n) な
	#	    ら LoadSync を送信し, RDP_STAT_LOADTILE に変更.
	#	(D) SetTile で TILE n 変更時に RDP_STAT_PRIM_TILE(n) なら
	#	    TileSync を送信し, RDP_STAT_NON に変更.
	#	(E) SetTile で LOADTILE の変更時に RDP_STAT_LOADTILE なら
	#	    TileSync を送信し, RDP_STAT_NON に変更.
	#	(F) ユーザが発行した sync があれば全て RSP_STAT_NON にする
	#   
	#	実際は ユーザが直接 RDP の LOAD コマンドを発行したときに
	#	それに応じたモードに切り替える必要があるがそれによるオーバー
	#	ヘッドがイヤなのでやめる. そのため (F) も手を抜いている.
	#---------------------------------------------------------------------
#define	RDP_STAT_NON		0x80
#define	RDP_STAT_LOADTILE	0x81		         /* TMEM ロード中 */
#define	RDP_STAT_PRIMITIVE	0x00		    /* プリミティブ作画中 */
#define	RDP_STAT_PRIM_TILE(n)	(RDP_STAT_PRIMITIVE+(n)) /* TILE n 使用中 */

RSP_STATEP_RDP_STAT:	.byte	RDP_STAT_NON	
	#---------------------------------------------------------------------
	# 現在のプリミティブで使用している Tile 記述子
	#	0<->2 と変化する
	#---------------------------------------------------------------------
RSP_STATEP_RENDERTILE:	.byte	2	# 初期値は 2			

	#---------------------------------------------------------------------
	# 現在の FIFO 空き領域の先頭
	#---------------------------------------------------------------------
RSP_STATEP_FIFO_OUTP:	.word	0x0

	#---------------------------------------------------------------------
	# セグメントテーブル
	#   Segment 0 のみ 0 に初期化しておく
	#   Assert 処理のために未初期化データには AID を代入しておく.
	#---------------------------------------------------------------------
RSP_SEG_OFFSET:		_word4	(0x0, AID, AID, AID)
			_word4	(AID, AID, AID, AID)
			_word4	(AID, AID, AID, AID)
			_word4	(AID, AID, AID, AID)

	#---------------------------------------------------------------------
	# DISPLAY LIST スタック (F3DEX と同じで 18 段)
	#	通常は .space 18*4 とするのだが, 
	#	この位置にバージョン記述子を入れておく 
	#---------------------------------------------------------------------
RSP_DLSTACK_OFFSET:
	_word4	(AID, AID, AID, AID)
	#
	# '\nRSP Gfx ucode ZSort  0.32 Yoshitaka Yasumoto Nintendo.\n'
	#
	#----------\nR S P     _ G f x     _ u c o     d e _ Z
	_word4	(0x0a525350, 0x20476678, 0x2075636f, 0x6465205a)
#ifdef	SUBDLNICE
	#----------S o r t     _ _ 0 .     3 4 _ Y     o s h i 
	_word4	(0x536f7274, 0x2020302e, 0x33342059, 0x6f736869)
#else
	#----------S o r t     p _ 0 .     3 4 _ Y     o s h i 
	_word4	(0x536f7274, 0x7020302e, 0x33342059, 0x6f736869)
#endif
	#----------t a k a     _ Y a s     u m o t     o _ N i 
	_word4	(0x74616b61, 0x20596173, 0x756d6f74, 0x6f204e69)
	#----------n t e n 
	.word	 0x6e74656e
	#----------d o . \n
	.word	 0x646f2e0a

/*---------------------------------------------------------------------------*
 *	ローカルステート
 *	マイクロコードにおいて固有に使用するステータス領域
 *	
 *	TASK 起動時および gSPLoadUcode で初期化される. 
 *---------------------------------------------------------------------------*/
RSP_LSTATE_OFFSET:

    #---------------------------------------------------------------------
    #  Sub Gfx 用の DL スタック   (18 段)
    #---------------------------------------------------------------------
			.bound	16
RSP_SUBDLSTACK_OFFSET:	.space	18*4
	
    #---------------------------------------------------------------------
    #  G_WAITSIGNAL 処理時における DMA バッファ
    #---------------------------------------------------------------------
			.bound	8
RSP_WAITSIGNAL_STATUS:	.word	0x00000000	
			.word	0x00000000	# ここは破壊される

    #-------------------------------------------------------------------------
    # 非ベクトルレジスタ用エリア (vecptr でのアクセスをしない)
    #-------------------------------------------------------------------------
	#---------------------------------------------------------------------
	#  Gfx Cmd のロード状態フラグ
	#---------------------------------------------------------------------
			.bound	4
RSP_STATUS_RDPCMD_1:	.word	0xffffffff
RSP_STATUS_RDPCMD_2:	.word	0xffffffff
RSP_STATUS_RDPCMD_3:	.word	0xffffffff

	#---------------------------------------------------------------------
	#  Jump テーブル (Gfx 処理用 Part1)
	#---------------------------------------------------------------------
		.bound	2
		#------ Gfx 処理用 1
RSP_JTBL_A1:	.half	case_G_ZOBJ		# 0x80	G_ZOBJ
		.half	case_G_RDPCHUNK		# 0x81	G_RDPCHUNK

    #---------------------------------------------------------------------
    # ベクトルレジスタ用エリア (vecptr でのアクセスが可能)
    #---------------------------------------------------------------------
	#---------------------------------------------------------------------
	# ベクトルレジスタ定数 (lqv でアクセス可能な位置)
	#---------------------------------------------------------------------
			.bound	16
#define	______	0x0000
			#---- vconst  = $v30 の値 ----
RSPZS_VCONST:		_half4	(0x0004, ______, 0x0008, ______)
			_half4	(0x4000, 0x0200, ______, 0x0001)
			.symbol	RSPZS_VPTR,	RSPZS_VCONST+64
			.symbol	oRSPZS_VCONST,	RSPZS_VCONST-RSPZS_VPTR
			#---- vconst1 = $v29 の値 ----
RSPZS_VCONST1:		_half4	(0xfffc, 0x7fff, 0x571d, 0x3a0c)
			_half4	(0x0040, 0x0400, 0x8000, RSP_USER_SCRATCH_0)
			.symbol	oRSPZS_VCONST1,	RSPZS_VCONST1-RSPZS_VPTR
	#---- ベクトル演算に使用する ----#
#define	_0x0000			vzero[0]
#define	_0x01cc			vconst[0]
 #define _0x0800		vconst[1]	/* UNUSED? */
#define	_0x0008			vconst[2]
 #define _0x0004		vconst[3]	/* UNUSED? */
#define	_0x4000			vconst[4]
#define	_0x0200			vconst[5]
 #define _0x0002		vconst[6]	/* UNUSED? */
#define	_0x0001			vconst[7]
#define	_0xfffc			vconst1[0]
#define	_0x7fff			vconst1[1]
#define	_ArcSin0		_0x7fff
#define	_ArcSin1		vconst1[2]
#define	_ArcSin2		vconst1[3]
#define	_0x0040			vconst1[4]
#define	_0x0400			vconst1[5]
#define	_0x8000			vconst1[6]

#define	_RSP_USER_SCRATCH	vconst1[7]
		.symbol	oRSPZS_0x7fff,	RSPZS_VCONST1+2-RSPZS_VPTR

	#---------------------------------------------------------------------
	# Texture Triangle 用 カラー値の桁合わせ係数
	#---------------------------------------------------------------------
		.bound	16
RSPZS_INVWI:	_half4	(0x0000, 0x0000, 0x0000, 0x0000)
RSPZS_INVWF:	_half4	(0x0200, 0x0200, 0x0200, 0x0200)
		.symbol	oRSPZS_INVWI,	RSPZS_INVWI-RSPZS_VPTR
		.symbol	oRSPZS_INVWF,	RSPZS_INVWF-RSPZS_VPTR

	#---------------------------------------------------------------------
	# スクラッチバッファおよび Yield 時のレジスタ保存エリア
	#---------------------------------------------------------------------
		.bound	16
RSPZS_VSCRATCH:	.space	16
		.symbol	oRSPZS_VSCRATCH, RSPZS_VSCRATCH-RSPZS_VPTR
		.symbol	RSP_YIELD_SAVE_MODE, RSPZS_VSCRATCH+0
		.symbol	RSP_YIELD_SAVE_OBJP, RSPZS_VSCRATCH+4
		.symbol	RSP_YIELD_SAVE_INP,  RSPZS_VSCRATCH+8

	#---------------------------------------------------------------------
	# 変数待避エリア
	#---------------------------------------------------------------------
	#------ zobj で DL の gfx1 を保存するのに使用 ------
			.bound	4		
RSPZS_ZOBJ_SAVE_GFX1:	.word	0
	
	#------ outfifo で return を保存するのに使用 ------
			.bound	4
RSPZS_OUTFIFO_RETURN:	.word	0

	#---------------------------------------------------------------------
        #  Light パラメータ保存エリア
	#---------------------------------------------------------------------
RSPZS_LPTR_SAVE:	.word	0

    #-------------------------------------------------------------------------
    # 非ベクトルレジスタ用エリア (vecptr でのアクセスをしない)
    #-------------------------------------------------------------------------
	#---------------------------------------------------------------------
	#  Overlay パラメータ (現在使用せず)
	#---------------------------------------------------------------------
#if 0
#define	OVERLAY_OFFSET	0
#define	OVERLAY_SIZE	4
#define	OVERLAY_DEST	6
OVERLAY_0_OFFSET:	.bound	4
			.word	OVERLAY_P0_OFFSET
			.half	OVERLAY_P0_SIZE
			.half	0x1000
#endif	
        #---------------------------------------------------------------------
        #  プリミティブのデータサイズ (DMA 用に -1 している)
        #---------------------------------------------------------------------
		.bound	2
RSP_ZOBJ_SIZE:	.byte   16-1    #  0:   Header Type
		.byte   32-1    #  1:   テクスチャなし 3 角形
		.byte   64-1    #  2:   テクスチャあり 3 角形
		.byte   40-1    #  3:   テクスチャなし 4 角形
		.byte   80-1    #  4:   テクスチャあり 4 角形
		.byte   0       #  Padding
			
        #---------------------------------------------------------------------
        #  プリミティブの処理ルーチン Jump テーブル
        #---------------------------------------------------------------------
		.bound	2
RSP_ZOBJ_TABLE:	.half   ZObj_Null		#  0:   Header Type
		.half	ZObj_ShTri		#  1:   テクスチャなし 3 角形
		.half	ZObj_TxTri		#  2:   テクスチャあり 3 角形
		.half	adrs_ZObj_ShQuad	#  3:   テクスチャなし 4 角形
		.half	adrs_ZObj_TxQuad	#  4:   テクスチャあり 4 角形

	#---------------------------------------------------------------------
	#  SUB DISPLAY LIST パラメータ保存エリア
	#---------------------------------------------------------------------
			.bound	4
RSP_SUBDL_INP:		.word	0
RSP_SUBDL_INP_DUMMY:	.word	0	# 常に 0 を代入する SUBDL 制御に使用
RSP_SUBDL_DINP:		.half	0

	#---------------------------------------------------------------------
	#  定数値テーブル
	#---------------------------------------------------------------------
		
	#------ DLSTACK の底の位置 ------
RSP_DLSTACK_BOTTOM:	.byte	0
			.byte	18*4				

	#------ ZObj への Pointer 計算用のマスク値 ------
			.bound	4
RSP_ZOBJ_MASK:		.word	0x00fffff8

	#------ RDPCHUNK 処理時における subDL 処理制御のマスク値 ------
			.bound	4
RSP_RETURN_MASK:	.word	0x0004fffc

	#------ StartDLload におけるロード位置パラメータ ------
			.half	RSP_SUBDLINPUT_OFFSET	# -2
RSP_DLLOAD_DMEM_ADRS:	.half	RSP_DLINPUT_OFFSET	#  0

	#------ ラベルの前方参照に使用 ------
RSP_GFXDONE:		.half	GfxDone
RSP_RSPCONTINUE_B:	.half	RSPcontinue_B
	
	#---------------------------------------------------------------------
	# MOVEMEM_EX offset テーブル
	#---------------------------------------------------------------------
RSP_MOVEMEM_TBL:	.bound	2
			.half	RSP_USER_SCRATCH_0	# User Scratch
			.half	RSP_USER_SCRATCH_1	# User Scratch + 64
			.half	RSP_STATEP_MMTX		# ModelView  Matrix
			.half	RSP_STATEP_PMTX		# Projection Matrix
			.half	RSP_STATEP_MPMTX	# MVP        Matrix
			.half	RSP_STATEP_OTHER_H	# OtherMode
			.half	RSP_STATEP_VIEWPORT_SC	# ViewPort
	
	#---------------------------------------------------------------------
	# MOVEWORD offset テーブル
	#---------------------------------------------------------------------
			.bound	2
RSP_MOVEWORD_TBL:	.half	RSP_SEG_OFFSET		# 06: Segment table
			.half	0			# 08: 
			.half	0			# 0a: 
			.half	0			# 0c: 
			.half	RSP_STATEP_PERSPNORM	# 0e: Persp Normalize
			.symbol	MOVEWORD_TBL_BEGIN, 6	# =G_MW_SEGMENT

	#---------------------------------------------------------------------
	#  Jump テーブル (Gfx 処理用 Part2 および RDPcmd 処理用)
	#---------------------------------------------------------------------
		#------ Gfx 処理用 2
RSP_JTBL_A2:	.bound	2
		.symbol	RSP_JTBL_SPC, (0xd0-0x80)*2+RSP_JTBL_A1-RSP_JTBL_A2
		.space	RSP_JTBL_SPC
		.print  "|\n| RSP_JTBL_SPC_1 = %d\n", RSP_JTBL_SPC
		.half	case_G_INTERPOLATE	# 0xd0  G_ZS_INTERPOLATE
		.half	case_G_XFMLIGHT		# 0xd1	G_ZS_XFMLIGHT
		.half	case_G_LIGHTING		# 0xd2  G_ZS_LIGHTING
		.half	case_G_LIGHTING		# 0xd3	G_ZS_LIGHTING_L	# LINEAR フラグ
		.half	case_G_MTXTRNSP		# 0xd4	G_ZS_MTXTRNSP
		.half	case_G_MTXCAT		# 0xd5	G_ZS_MTXCAT
		.half	case_G_MULT_MPMTX	# 0xd6	G_ZS_MULT_MPMTX
		.half	case_G_LINKSUBDL	# 0xd7	G_ZS_LINKSUBDL
		.half	case_G_SETSUBDL		# 0xd8	G_ZS_SETSUBDL
		.half	case_G_WAITSIGNAL	# 0xd9	G_ZS_WAITSIGNAL
		.half	case_G_SENDSIGNAL	# 0xda	G_ZS_SENDSIGNAL
		.half	case_G_MOVEWORD		# 0xdb	G_MOVEWORD
		.half	case_G_MOVEMEM_EX	# 0xdc	G_ZS_MOVEMEM_EX
		.half	case_G_LOAD_UCODE	# 0xdd	G_LOAD_UCODE
		.half	case_G_DL		# 0xde	G_DL
		.half	case_G_ENDDL		# 0xdf	G_ENDDL
		.half	case_G_SPNOOP		# 0xe0	G_SPNOOP
		.half	case_G_SAVEHALF_1	# 0xe1  G_SAVEHALF_1
		
		.symbol	RSP_JTBL_A_ORG, RSP_JTBL_A1+(0x100-0x80)*2
		#------ Rdp cmd 処理用
RSP_JTBL_B:	.half	rdp_G_ENDDL		# 0xdf !G_ENDDL
		.half	rdp_G_SPNOOP		# 0xe0 !G_SPNOOP
		.half	rdp_G_RDPHALF_1		# 0xe1 !G_RDPHALF_1
		.half	rdp_G_SETOTHERMODE_L	# 0xe2 !G_SETOTHERMODE_L
		.half	rdp_G_SETOTHERMODE_H	# 0xe3 !G_SETOTHERMODE_H
		.half	rdp_G_RDPHALF_0		# 0xe4	G_TEXRECT
		.half	rdp_G_RDPHALF_0		# 0xe5	G_TEXRECTFLIP
		.half	rdp_G_RDP_General	# 0xe6	G_RDPLOADSYNC
		.half	rdp_G_RDP_General	# 0xe7	G_RDPPIPESYNC
		.half	rdp_G_RDP_General	# 0xe8	G_RDPTILESYNC
		.half	rdp_G_RDP_General	# 0xe9	G_RDPFULLSYNC
		.half	rdp_G_RDP_General	# 0xea	G_SETKEYGB
		.half	rdp_G_RDP_General	# 0xeb	G_SETKEYR
		.half	rdp_G_RDP_General	# 0xec	G_SETCONVERT
		.half	rdp_G_SETSCISSOR	# 0xed	G_SETSCISSOR
		.half	rdp_G_RDP_General	# 0xee	G_SETPRIMDEPTH
		.half	rdp_G_RDPSETOTHERMODE	# 0xef	G_RDPSETOTHERMODE
		.half	rdp_G_RDP_General	# 0xf0	G_LOADTLUT
		.half	rdp_G_TEXRECT_DONE	# 0xf1 !G_RDPHALF_2
		.half	rdp_G_RDP_General	# 0xf2	G_SETTILESIZE
		.half	rdp_G_RDP_General	# 0xf3	G_LOADBLOCK
		.half	rdp_G_RDP_General	# 0xf4	G_LOADTILE	
		.half	rdp_G_RDP_General	# 0xf5	G_SETTILE
		.half	rdp_G_RDP_General	# 0xf6	G_FILLRECT
		.half	rdp_G_RDP_General	# 0xf7	G_SETFILLCOLOR
		.half	rdp_G_RDP_General	# 0xf8	G_SETFOGCOLOR
		.half	rdp_G_RDP_General	# 0xf9	G_SETBLENDCOLOR
		.half	rdp_G_RDP_General	# 0xfa	G_SETPRIMCOLOR
		.half	rdp_G_RDP_General	# 0xfb	G_SETENVCOLOR
		.half	rdp_G_RDP_General	# 0xfc	G_SETCOMBINE
		.half	rdp_G_RDP_AdrsFixup	# 0xfd	G_SETTIMG 要 AdrsFixup
		.half	rdp_G_RDP_AdrsFixup	# 0xfe	G_SETZIMG 要 AdrsFixup
		.half	rdp_G_RDP_AdrsFixup	# 0xff	G_SETCIMG 要 AdrsFixup
RSP_JTBL_B_ORG:	.half	rdp_G_RDP_General	# 0x00  G_NOOP

	#---------------------------------------------------------------------
	#  Lighting における cskip テーブル
	#---------------------------------------------------------------------
RSP_LIGHT_CSKIP:
		.byte	0
		.byte	16
		.byte	16
		.byte	0		# Dummy -- Padding

	#---------------------------------------------------------------------
	#  Interpolation における変数型に対する Jump テーブル
	#---------------------------------------------------------------------
RSP_INTRPLT_JUMP_TABLE:
		.half	case_G_INTRPLT_S16_Sub
		.half	case_G_INTRPLT_S8_Sub
		.half	case_G_INTRPLT_U8_Sub
		.half	0		# Dummy -- Padding
    .symbol RSP_INTRPLT_OFFSET, RSP_INTRPLT_JUMP_TABLE+(G_ZS_INTERPOLATE<<8)

		.dmax	0x800-1		

/*---------------------------------------------------------------------------*
 *	Yield セーブ領域
 *	
 *	Yield の前後で保持される.
 *---------------------------------------------------------------------------*/

	#---------------------------------------------------------------------
	#  ZObject データ用の DMA バッファ
	#---------------------------------------------------------------------
			.bound	16
RSP_ZOBJ_BUF_A:		.space	80
			.symbol	oRZ_HEADER,	 0
			.symbol	oRZ_RDPCMD_1,	 4
			.symbol	oRZ_RDPCMD_2,	 8
			.symbol	oRZ_RDPCMD_3,	12
			.symbol	oRZ_SHTRI_VTX0,  8
			.symbol	oRZ_SHTRI_VTX1, 16
			.symbol	oRZ_SHTRI_VTX2, 24
			.symbol	oRZ_SHTRI_VTX3, 32
			.symbol	oRZ_TXTRI_VTX0_X, 16
			.symbol	oRZ_TXTRI_VTX1_X, 32
			.symbol	oRZ_TXTRI_VTX2_X, 48
			.symbol	oRZ_TXTRI_VTX3_X, 64
			.symbol	oRZ_TXTRI_VTX0_S, oRZ_TXTRI_VTX0_X+8
			.symbol	oRZ_TXTRI_VTX1_S, oRZ_TXTRI_VTX1_X+8
			.symbol	oRZ_TXTRI_VTX2_S, oRZ_TXTRI_VTX2_X+8
			.symbol	oRZ_TXTRI_VTX3_S, oRZ_TXTRI_VTX3_X+8
			.symbol	oRZ_TXTRI_VTX0_INVWi, oRZ_TXTRI_VTX0_X+12
			.symbol	oRZ_TXTRI_VTX1_INVWi, oRZ_TXTRI_VTX1_X+12
			.symbol	oRZ_TXTRI_VTX2_INVWi, oRZ_TXTRI_VTX2_X+12
			.symbol	oRZ_TXTRI_VTX3_INVWi, oRZ_TXTRI_VTX3_X+12
			.symbol	oRZ_TXTRI_VTX0_INVWf, oRZ_TXTRI_VTX0_X+14
			.symbol	oRZ_TXTRI_VTX1_INVWf, oRZ_TXTRI_VTX1_X+14
			.symbol	oRZ_TXTRI_VTX2_INVWf, oRZ_TXTRI_VTX2_X+14
			.symbol	oRZ_TXTRI_VTX3_INVWf, oRZ_TXTRI_VTX3_X+14

	#---------------------------------------------------------------------
	#  SUB DISPLAY LIST キャッシュ (20 個分の DL  を保持)
	#---------------------------------------------------------------------
			.bound	8
RSP_SUBDLINPUT_OFFSET:	.symbol	GZ_MAX_SUBDL,	20
			.space	GZ_MAX_SUBDL*8
	.symbol	RSP_SUBDLINPUT_BOTTOM, RSP_SUBDLINPUT_OFFSET+GZ_MAX_SUBDL*8

		.symbol	RSP_JTBL_SPC_2, 0x3f0-RSP_SUBDLINPUT_BOTTOM
		.space	RSP_JTBL_SPC_2
		.print  "| RSP_JTBL_SPC_2 = %d\n|\n", RSP_JTBL_SPC_2

	#---------------------------------------------------------------------
	#  Lighting 計算時のマテリアルを指定しない時に使用するマテリアル値
	#---------------------------------------------------------------------
RSP_DEFAULT_MATERIAL:
		.word	0xffffffff	# (R,G,B,A) = (255,255,255,255)
		.word	0xffffffff	# (R,G,B,A) = (255,255,255,255)
		.word	0xffffffff	# (R,G,B,A) = (255,255,255,255)
		.word	0xffffffff	# (R,G,B,A) = (255,255,255,255)

			.bound	16
END_OF_DMEM_INIT:	.symbol	DummyInit, 0
		
	#---------------------------------------------------------------------
	#  ユーザー用スクラッチエリア
	#	0x400 から 0xbff に固定する
	#---------------------------------------------------------------------
			.bound	16
RSP_USER_SCRATCH_0:	.space	64
RSP_USER_SCRATCH_1:	.space	64
RSP_USER_SCRATCH_2:	.space	2048-64-64

RSP_SAVED_IN_YIELD:
	.symbol	DummyYield, 0	
	.print	"| Yield が必要な領域 [0x%04x] < 0x0c00\n", RSP_SAVED_IN_YIELD
	.dmax	0xc00+1
			
/*---------------------------------------------------------------------------*
 *	一時ワーク領域
 *	
 *	Yield の前後でも保持されない.
 *---------------------------------------------------------------------------*/
	#---------------------------------------------------------------------
	#  RDPCHUNK     キャッシュ (16 個分の Gfx を保持)
	#---------------------------------------------------------------------
			.bound	8
RSP_RDPCHUNK_OFFSET:	.symbol	GZ_MAX_CHUNK,	16
			.space	GZ_MAX_CHUNK*8
	.symbol	RSP_RDPCHUNK_BOTTOM,   RSP_RDPCHUNK_OFFSET+GZ_MAX_CHUNK*8

	#---------------------------------------------------------------------
	#  DISPLAY LIST キャッシュ (20 個分の DL を保持)
	#---------------------------------------------------------------------
			.bound	8
RSP_DLINPUT_OFFSET:	.symbol	GZ_MAX_DL, 20
			.space	GZ_MAX_DL*8
			.symbol	RSP_DLINPUT_BOTTOM, RSP_DLINPUT_OFFSET+GZ_MAX_DL*8

	#---------------------------------------------------------------------
	#  Sub Main 処理時におけるレジスタ保存エリア
	#     RDPCHUNK と同じ位置を使用する
	#---------------------------------------------------------------------
			.symbol	RSP_SUBDL_SAVE_INP,  RSP_DLINPUT_OFFSET-4
			.symbol	RSP_SUBDL_SAVE_DINP, RSP_DLINPUT_OFFSET-8

	#---------------------------------------------------------------------
	# RDP コマンドの一時保存領域
	#---------------------------------------------------------------------
			.bound	8
			.symbol	RSP_OUTPUT_BUFSZ, (32+64+64)*4+16
RSP_OUTPUT_OFFSET:	.space	RSP_OUTPUT_BUFSZ

			.symbol	RSP_OUTPUT_END,     RSP_OUTPUT_BUFSZ+RSP_OUTPUT_OFFSET
			.symbol	RSP_OUTPUT_ENOUGH,  RSP_OUTPUT_END-(32+64+64)*2
			.symbol	RSP_YIELD_SAVE_LEN, 0x0c00	# F3DEX 共通

	.print "| DMEM REMAIN = %d\n|\n", 0x0fb0-RSP_OUTPUT_END
	
/*---------------------------------------------------------------------------*
 *	Task 構造体領域
 *	
 *	OSTask のデータが CPU から渡される
 *---------------------------------------------------------------------------*/
	.symbol  RSP_TASK_OFFSET,	0x1000-OS_TASK_SIZE
	.symbol  GTASK_TYPE,		RSP_TASK_OFFSET+OS_TASK_OFF_TYPE
	.symbol  GTASK_FLAGS,		RSP_TASK_OFFSET+OS_TASK_OFF_FLAGS
	.symbol  GTASK_UCODE,		RSP_TASK_OFFSET+OS_TASK_OFF_UCODE
	.symbol  GTASK_OUTBUFF,		RSP_TASK_OFFSET+OS_TASK_OFF_OUTBUFF
	.symbol  GTASK_OUTBUFF_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_OUTBUFF_SZ
	.symbol  GTASK_DATA,		RSP_TASK_OFFSET+OS_TASK_OFF_DATA
	.symbol  GTASK_DATA_SZ,		RSP_TASK_OFFSET+OS_TASK_OFF_DATA_SZ
	.symbol  GTASK_YIELD,		RSP_TASK_OFFSET+OS_TASK_OFF_YIELD
	.symbol  GTASK_YIELD_SZ,	RSP_TASK_OFFSET+OS_TASK_OFF_YIELD_SZ
	
	.symbol  ASSERT_WORKAREA,	RSP_TASK_OFFSET-0x10
	.symbol  ASSERT_DEBUG0,		ASSERT_WORKAREA+0x00
	.symbol  ASSERT_DEBUG1,		ASSERT_WORKAREA+0x04
	.symbol  ASSERT_DEBUG2,		ASSERT_WORKAREA+0x08
	.symbol  ASSERT_DEBUG3,		ASSERT_WORKAREA+0x0c

/*======== End of gzdmem.h ========*/
