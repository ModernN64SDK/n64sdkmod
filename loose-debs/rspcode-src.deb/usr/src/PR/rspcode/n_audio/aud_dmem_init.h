/*************************************************************************
 *                                                                       *
 *               Copyright (C) 1994, Silicon Graphics, Inc.              *
 *                                                                       *
 *  These coded instructions, statements, and computer programs  contain *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and *
 *  are protected by Federal copyright  law.  They  may not be disclosed *
 *  to  third  parties  or copied or duplicated in any form, in whole or *
 *  in part, without the prior written consent of Silicon Graphics, Inc. *
 *                                                                       *
 ************************************************************************/
	
/*
 * aud_dmem_init.h
 *
 * This file sets up and intializes some data and jump tables in DMEM.
 *
 */

#define	OPTYPE_JMP_OFFSET	(RSP_PDATA_OFFSET + 0)
#define OPTYPE_JMP_SIZE8	(16*2)
        
 	.half	AudDone
	.half	case_A_ADPCM
	.half	case_A_CLEARBUFF
	.half	case_A_ENVMIX
	.half	case_A_LOADBUFF
	.half	case_A_RESAMPLE
	.half	case_A_SAVEBUFF
        .half   0x0000
        .half   0x0000
	.half	case_A_SETVOL
	.half	case_A_DMMOVE
	.half	case_A_LOADADPCM
	.half	case_A_MIXER
	.half	case_A_INTERLEAVE
	.half	case_A_POLEF
        .half   case_A_SETLSTATE

#define DEC_MASK_OFFSET		(OPTYPE_JMP_OFFSET + OPTYPE_JMP_SIZE8)
#define DEC_MASK_SIZE8		(4*4)

	.word	0xf0000f00	# Mask
	.word	0x00f0000f

	.word	0x00010010	# Scale
	.word	0x01001000

#define DEFAULT_FRAC_VOL 0xffff
#define RES_PHASE_COUNT	64
#define RES_PHASE_SIZE 4
#define BYTES_PER_SHORT           2
#define BYTES_PER_VECTOR         16
#define COEF_TAB_SIZE           (RES_PHASE_COUNT * RES_PHASE_SIZE)

#define C_MULINC		(0)
#define C_ONE			(C_MULINC + BYTES_PER_VECTOR)
#define C_SHIFT			(C_ONE + BYTES_PER_VECTOR)
#define C_ZEROFOUR		(C_SHIFT + BYTES_PER_VECTOR)
#define C_ONEFIVE		(C_ZEROFOUR + BYTES_PER_VECTOR)
#define C_TWOSIX		(C_ONEFIVE + BYTES_PER_VECTOR)
#define C_THREESEVEN		(C_TWOSIX + BYTES_PER_VECTOR)
#define C_RAMP			(C_THREESEVEN + BYTES_PER_VECTOR)

#define	RES_CONST_OFFSET	(DEC_MASK_OFFSET + DEC_MASK_SIZE8)
#define RES_CONST_SIZE8		(8 * BYTES_PER_VECTOR )
	.word	0x00020004	# vMULINC
	.word	0x00060008
	.word	0x000a000c
	.word	0x000e0010

	.word	0x00010001	# vONE
	.word	0x00010001
	.word	0x00010001
	.word	0x00010001

	.word	0x00000020	# vSHIFT
	.word	0x00020800
	.word	0x00087fff
	.word	0x01000200

	.word	0x00010000	# vZEROFOUR
	.word	0x00000000
	.word	0x00010000
	.word	0x00000000

	.word	0x00000001	# vONEFIVE
	.word	0x00000000
	.word	0x00000001
	.word	0x00000000

	.word	0x00000000	# vTWOSIX
	.word	0x00010000
	.word	0x00000000
	.word	0x00010000

	.word	0x00000000	# vTHREESEVEN
	.word	0x00000001
	.word	0x00000000
	.word	0x00000001

	.word	0x20004000	# vRAMP for increasing volume
	.word	0x60008000
	.word	0xa000c000
	.word	0xe000ffff

#define	RES_TABLE_OFFSET	(RES_CONST_OFFSET + RES_CONST_SIZE8)
#define RES_TABLE_SIZE8		(COEF_TAB_SIZE * BYTES_PER_SHORT)
#include "coef_tab.h"
#define END_OF_SRC_PDATA	(RES_OFFSET_TABLE + (COEF_TAB_SIZE * BYTES_PER_SHORT))

    .print	"--------------------------------------------------------------------\n"
    .print   __FILE__
    .print   " : Total static program data initialized is %d bytes.\n", (RES_TABLE_OFFSET + RES_TABLE_SIZE8)

    .print   __FILE__
    .print   " : DMEM program data limit is %d bytes.\n", RSP_PDATA_SIZE8
