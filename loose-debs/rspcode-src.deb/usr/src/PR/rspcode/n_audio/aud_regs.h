/*************************************************************************
 *                                                                       *
 *               Copyright (C) 1994, Silicon Graphics, Inc.              *
 *                                                                       *
 *  These coded instructions, statements, and computer programs  contain *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and *
 *  are protected by Federal copyright  law.  They  may not be disclosed *
 *  to  third  parties  or copied or duplicated in any form, in whole or *
 *  in part, without the prior written consent of Silicon Graphics, Inc. *
 *                                                                       *
 ************************************************************************/
	
#ifndef _aud_regs_h_
#define _aud_regs_h_ 1

	
 ############################################################################	
 #
 # Scalar Register Usage Conventions:
 #
 # Starting from $31 growing down, we allocate 'permanent' registers.
 # These should only be re-used carefully, possibly saved/restored.
 # (during development we might re-shuffle these so the more crucial
 # or stable ones remain higher)
 #
 # Register $0 is always 0, as per the MIPS R4000 spec.
 #
 # Starting from $1 growing up, we use 'temporary' registers which
 # are free to be used by procedures or small blocks of code. These
 # registers are not named (or they are .name'd and .unname'd in small
 # code blocks).
 #
 # Function parameters are passed and returned in $1, $2, $3, etc.
 #
	
.name	return,		$31	# MIPS R4000 convention for JAL op
.name	dlcount,	$30	# curr counter of DL buffer
.name	dinp, 		$29	# curr pointer into DL buffer
.name	inp,		$28	# DRAM ptr of current DL location (for stack)
.name	gcount,		$27	# size remaining of DL (not just in DMEM)
.name	aud0, 		$26	# holds first word of DL command
.name	aud1, 		$25	# holds second word of DL command
.name   scrbase,	$24	# holds the base of the scratch area in DMEM
.name	zero,		$0
	
 ############################################################################	
 #
 # Vector Register Usage Conventions:
 #
 # Similar to scalar registers, named registers start at $v31 and grow down.
 # These should only be re-used carefully, possibly saved/restored.
 # (during development we might re-shuffle these so the more crucial
 # or stable ones remain higher)
 #
 # Register $v0 is NOT always 0, like in the MIPS R4000 spec.
 #
 # Starting from $v1 growing up, we use 'temporary' registers which
 # are free to be used by procedures or small blocks of code. These
 # registers are not named (or they are .name'd and .unname'd in small
 # code blocks).
 #
 # Function parameters are passed and returned in $v1, $v2, $v3, etc.
 #

#endif /* _aud_regs_h_ */
