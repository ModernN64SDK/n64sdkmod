/*************************************************************************
 *                                                                       *
 *               Copyright (C) 1994, Silicon Graphics, Inc.              *
 *                                                                       *
 *  These coded instructions, statements, and computer programs  contain *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and *
 *  are protected by Federal copyright  law.  They  may not be disclosed *
 *  to  third  parties  or copied or duplicated in any form, in whole or *
 *  in part, without the prior written consent of Silicon Graphics, Inc. *
 *                                                                       *
 ************************************************************************/
	
#ifndef _aud_dmem_h_
#define _aud_dmem_h_

/*
 * File:		aud_dmem.h
 *
 * This file lays out the DMEM usage for the RSP audio task.
 *
 */

/*
 * Memory layout of DMEM:
 *
 * Our aim is to minimize DMEM use so that we can process as
 * many samples as possible with a single command. 
 * The buffer area is a resource managed by the Host rather than 
 * divided into hard defined regions.
 *
 *      -------------------------------------------------
 *      | Program data from compiler...                 |     (must be first)
 *	|                               688 bytes       |
 *	|	Includes constants 			|
 *	|	coefficient table for resampler		|
 *	|						|
 *	|-----------------------------------------------|
 *	| Input (command list)		320 bytes       |
 *      |    40 cmds, @ 8bytes				|
 *      |               				|
 *	|  (We can make this smaller if nec.		|
 *	|						|
 *	|-----------------------------------------------|
 *      | ADPCM coefficient table                       |
 *      |       Each entry is 32 bytes (16*2)           |
 *      |       so 8 entries is 256 bytes               |
 *      |                                               |
 *      |-----------------------------------------------|
 *	| Buffers available for command	results		|
 *	|  Managed by the Host CPU			|
 *	|						|
 *	|						|
 *	|-----------------------------------------------|
 *	| Scratch space for intermediate results        |
 *	|   Not touched by the Host CPU                 |
 *	|     Whatever is left                          |
 *	|                                        	|
 *	|                                        	|
 *      -------------------------------------------------
 * 
 */

#ifndef DCACHEBASE
#   define DCACHEBASE	0x00000000
#endif

#ifndef DCACHEBASEHI
#   define DCACHEBASEHI	0x0000
#endif
#ifndef DCACHEBASELO
#   define DCACHEBASELO	0x0000
#endif

#define RSP_DMEM_SIZE8         4096

#define RSP_PDATA_SIZE8	        688
#define RSP_DLINPUT_SIZE8       320
#define RSP_ADPCMTABLE_SIZE8    256
#define RSP_BUFFER_SIZE8       2720
#define RSP_YIELD_BUF_SIZE8      16
#define RSP_SCRATCH_SIZE8     (RSP_DMEM_SIZE8 - RSP_YIELD_BUF_SIZE8 - \
                               RSP_BUFFER_SIZE8 - RSP_DLINPUT_SIZE8 - \
			       RSP_ADPCMTABLE_SIZE8 - RSP_PDATA_SIZE8)
				
#define RSP_PDATA_OFFSET	(0)
#define RSP_DLINPUT_OFFSET	(RSP_PDATA_OFFSET + RSP_PDATA_SIZE8)
#define RSP_ADPCMTABLE_OFFSET   (RSP_DLINPUT_OFFSET + RSP_DLINPUT_SIZE8)
#define RSP_BUFFER_OFFSET	(RSP_ADPCMTABLE_OFFSET + RSP_ADPCMTABLE_SIZE8)
#define RSP_YIELD_BUF_OFFSET    (RSP_BUFFER_OFFSET + RSP_BUFFER_SIZE8)
#define RSP_SCRATCH_OFFSET	(RSP_YIELD_BUF_OFFSET + RSP_YIELD_BUF_SIZE8)

#ifdef _LANGUAGE_ASSEMBLY
#   define _DumpDMEMOffset(o,s)  				\
    .print 	#o						\
    .print 	"\t\t : %d\t%d bytes.\n", (DCACHEBASE + (o)), (s)

    .print	"--------------------------------------------------------------------\n"

    .print	__FILE__
    .print	" : Scratch space allocated is %d bytes.\n", RSP_SCRATCH_SIZE8
    .print	__FILE__
    .print	" : Program data segment is at %08x.\n", DCACHEBASE+RSP_PDATA_OFFSET
    .print	__FILE__
    .print	" : DMEM Map:\n"

     _DumpDMEMOffset(RSP_PDATA_OFFSET, RSP_PDATA_SIZE8)
     _DumpDMEMOffset(RSP_DLINPUT_OFFSET, RSP_DLINPUT_SIZE8)
     _DumpDMEMOffset(RSP_ADPCMTABLE_OFFSET, RSP_ADPCMTABLE_SIZE8)
     _DumpDMEMOffset(RSP_BUFFER_OFFSET, RSP_BUFFER_SIZE8)
     _DumpDMEMOffset(RSP_YIELD_BUF_OFFSET, RSP_YIELD_BUF_SIZE8)
     _DumpDMEMOffset(RSP_SCRATCH_OFFSET, RSP_SCRATCH_SIZE8)

    .print	"--------------------------------------------------------------------\n"

#   undef _DumpDMEMOffset
#endif

#endif /* _aud_dmem_h_ */



