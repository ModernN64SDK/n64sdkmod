/*============================================================================

		NINTENDO64 TECHNICAL SUPPORT CENTER 
		
		    NINTENDO64 SAMPLE PROGRAM 1

		Copyright (C) 1997, NINTENDO Co,Ltd.

============================================================================*/
#include <ultra64.h>
#include "def.h"

unsigned short zbuffer[SCREEN_WD*SCREEN_HT];


