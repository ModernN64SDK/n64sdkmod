/*============================================================================

		NINTENDO64 TECHNICAL SUPPORT CENTER 
		
		    NINTENDO64 SAMPLE PROGRAM 1

		Copyright (C) 1997, NINTENDO Co,Ltd.

============================================================================*/

#include <ultra64.h>
#include "def.h"

/* buffer to load static display list */
Gfx gfx_dlist_buf[GFX_DLIST_BUF_NUM][GFX_DLIST_BUF_SIZE];


