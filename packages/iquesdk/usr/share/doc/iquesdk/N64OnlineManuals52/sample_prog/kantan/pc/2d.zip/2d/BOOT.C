

#define __BOOT_C__

/* :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	Boot strap
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */

#include "pack.h"

/* ===========================================================================
	static variables
 =========================================================================== */
static OSThread	idleThread;
static u64 idleThreadStack[STACKSIZE/sizeof(u64)];

static OSThread	mainThread;
static u64 mainThreadStack[STACKSIZE/sizeof(u64)];

static OSThread	rmonThread;
static u64 rmonStack[RMON_STACKSIZE/sizeof(u64)];

#define NUM_PI_MSGS 8

static OSMesg PiMessages[NUM_PI_MSGS];
static OSMesgQueue PiMessageQ;

static OSMesg dmaMessageBuf;
static OSMesgQueue dmaMessageQ;

static int debugflag = 0;
static int draw_buffer = 0;

/* ===========================================================================
	public variables
 =========================================================================== */
/* Boot stack to be used for spec   */
u64 bootStack[STACKSIZE/sizeof(u64)];

/* ===========================================================================
	functions
 =========================================================================== */

/* ----------------------------------------------------------------------------
  Boot strap
---------------------------------------------------------------------------- */
static void idle(void *);
static void mainproc(void *);

void boot(void)
{
    int i;
    char *ap;
    u32 *argp;
    u32 argbuf[16];

    osInitialize();

    argp = (u32 *)RAMROM_APP_WRITE_ADDR;
    for (i=0; i<sizeof(argbuf)/4; i++, argp++) {
	osPiRawReadIo((u32)argp, &argbuf[i]); /* Assume no DMA */
    }

    /* Parse the options */
    ap = (char *)argbuf;
    while (*ap != '\0') {
	while (*ap == ' ')
	    ap++;
	if ( *ap == '-' && *(ap+1) == 'd') {
	    debugflag = 1;
	    ap += 2;
	}
    }

    osCreateThread(&idleThread, 1, idle, (void *)0,
		   idleThreadStack+STACKSIZE/sizeof(u64), 10);
    osStartThread(&idleThread);
}

/* ----------------------------------------------------------------------------
   Idle thread
---------------------------------------------------------------------------- */
static void idle(void *arg)
{
    /* Run VI manager */
    osCreateViManager(OS_PRIORITY_VIMGR);
    osViSetMode(&osViModeTable[OS_VI_NTSC_LAN1]);
    osViBlack(TRUE);

    /* Run PI manager */
    osCreatePiManager((OSPri)OS_PRIORITY_PIMGR, &PiMessageQ, PiMessages, 
		      NUM_PI_MSGS);

    /* RMON thread */
    osCreateThread(&rmonThread, 0, rmonMain, (void *)0,
		   (void *)(rmonStack+RMON_STACKSIZE/8), 
		   (OSPri) OS_PRIORITY_RMON );
    osStartThread(&rmonThread);

    /* Main tread */
    osCreateThread(&mainThread, 3, mainproc, arg,
		   mainThreadStack+STACKSIZE/sizeof(u64), 10);
    if (!debugflag)
	osStartThread(&mainThread);

    /* Keep in the state of idle thread */
    osSetThreadPri(0, 0);
    for (;;);
}

/* ----------------------------------------------------------------------------
   Main thread
---------------------------------------------------------------------------- */
static void mainproc(void *arg)
{
    osCreateMesgQueue(&dmaMessageQ, &dmaMessageBuf, 1);

    /* Initialize memory manager */
    minit();

    /*Initialize graphic module */
    gfxInit();

    /* Initialize controller */
    expadInitControllers( 4, 20, 4 );

    /* Call user routine */
    entry();
}

